# FOUNDATION_EVIDENCE

Do not claim execution that did not happen.

## Platforms

| Platform | Role | Executed |
|---|---|---|
| QEMU `virt,gic-version=3` cortex-a57 | validation instrument | yes |
| ARM FVP Base | validation instrument | **no** — FVP binary absent |
| Real ARM64 hardware | architectural target | **no** |

QEMU addresses are board facts (`board/qemu-virt/facts.c`). They are not architecture.

## Build

- Toolchain: `probe/host/zig/zig cc -target aarch64-freestanding-none`
- Include roots: `-Iinclude -I.`
- Header deps: `-MMD -MP`
- Images: `build-qemu/nxu.img`, `build-fvp/nxu.img`, `build-debug/nxu.img`
- Static checks: `probe/check.sh`

## QEMU virt, smp=4, 128M

Log: `probe/evidence/qemu-virt.log`.

Live console includes `[NXU][S14] Foundation frozen @ 0x...`.
Capture requires that line. It does not accept a hex dump substitute.

## Negative tests

| Test | Method | Result |
|---|---|---|
| Bad image magic | `probe/cases/neg-header.sh` | no `[NXU][S14]` |

## FVP

`make fvp` produces `build-fvp/nxu.img`.

**NOT EXECUTED.** No FVP binary.

## Real hardware

**NOT EXECUTED.**
