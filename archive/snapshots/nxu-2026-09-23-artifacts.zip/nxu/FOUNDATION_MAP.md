# Foundation map

Genesis v2 + closure. S0–S14 frozen. No research names in TCB.

Maps live in source files. This file is an index.

```
Hardware
   │
   ▼
silicon/aarch64          operations, addresses as parameters
   │
   ▼
board/*                  candidate facts only
   │
   ▼
foundation/enter.c       S0 → S14 then halt
   │
   ├── intake/           S0 S1
   ├── contract/         S2
   ├── facts/            S3 S4
   ├── space/            S5 S6
   ├── exception/        S7
   ├── context/          nxu_cpu_exec_context
   ├── cpu/              S8 S9 S12
   ├── signal/           S10 S13
   ├── time/             S11
   └── observe/          chronicle, Black Box, console, S14
```

`probe/` executes artifacts. `research/` is not linked.

Artifacts: `build-qemu/`, `build-fvp/`, `build-debug/`.
