# Foundation status

S0–S14 frozen. Genesis v2 + closure unchanged.

| Stage | Status | Evidence |
|---|---|---|
| S0–S14 | implemented | QEMU virt, smp=4, live `[NXU][S14]` |
| QEMU | EXECUTED | `make qemu` requires `[NXU][S14]` |
| Debug | EXECUTED | `make debug` same freeze, extra `[NXU][DBG]` |
| FVP | built, NOT EXECUTED | `build-fvp/nxu.img`; no FVP binary |
| Real SoC | NOT EXECUTED | `board/soc/` facts present=0 |

S14 wait-loop failure: IRQ 30 was delivered; `timer_fired` was not compiler-visible and headers did not rebuild waiters. Volatile field, pointer-to-volatile wait, DSB after IRQ store, `-MMD -MP`. Capture looks for the live `[NXU][S14]` line. Not hidden.
