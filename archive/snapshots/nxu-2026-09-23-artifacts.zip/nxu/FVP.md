# FVP Base RevC

Do not run this tree from Trash. Extract to a real directory:

    rm -rf "$HOME/Alex/myOS/nxu"
    mkdir -p "$HOME/Alex/myOS"
    unzip -o nxu-latest.zip -d "$HOME/Alex/myOS"
    cd "$HOME/Alex/myOS/nxu"

    export FVP="$HOME/arm-fvp/Base_RevC_AEMvA_pkg/models/Linux64_GCC-9.3/FVP_Base_RevC-2xAEMvA"
    make clean
    make fvp
    make fvp-run

The model maps BL1 ROM at 0x0. NXU is a VA-0 image, so `-a cluster0.cpu0=nxu.elf`
loads into ROM and the CPU never reaches NXU. The probe loads the raw image with:

    --data cluster0.cpu0=build-fvp/nxu.img@0x80000000
    -C cluster0.cpu0.RVBARADDR=0x80000000
    --start cluster0.cpu0=0x80000000
    -C pctl.startup=0.0.0.0
    -C cluster0.has_el3=0
    -C bp.pl011_uart0.out_file=probe/evidence/fvp-uart.log

UART is FVP PL011 at 0x1C090000 (board fact only). Console is captured in
`probe/evidence/fvp-uart.log`. Telnet "Listening on port 5000" lines from the
model are not NXU output.

`make fvp` builds only. `make fvp-run` builds and launches the model.
