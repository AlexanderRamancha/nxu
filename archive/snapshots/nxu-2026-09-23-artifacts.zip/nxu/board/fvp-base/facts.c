/*
 * NXU MAP
 * Layer: board/fvp-base
 * Owns: candidate RAM/GIC/UART/CPU/PSCI facts for FVP Base
 * Consumes: none
 * Produces: nxu_board candidates
 * Hardware: none (data)
 * Forbidden: behavior; silicon calls; skip-validation
 * Invariant: addresses live only here, not in foundation/silicon
 */
#include <nxu/board.h>

const struct nxu_board_facts nxu_board = {
	.present = 1U,
	.ram_count = 1U,
	.ram = {
		{ 0x80000000ULL, 0x80000000ULL },
	},
	.gicd = { 0x2F000000ULL, 0x10000ULL },
	.gicr = { 0x2F100000ULL, 0x200000ULL },
	.uart = { 0x1C090000ULL, 0x1000ULL },
	.cpu_count = 8U,
	.cpu_mpidr = { 0U, 1U, 2U, 3U, 0x100U, 0x101U, 0x102U, 0x103U },
	.psci_conduit = NXU_PSCI_SMC,
};
