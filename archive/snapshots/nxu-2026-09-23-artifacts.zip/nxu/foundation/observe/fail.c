/*
 * NXU MAP
 *
 *                         EVENT
 *                           │
 *                           ▼
 *                      BLACK BOX
 *                           │
 *                           ▼
 *                   PRESERVED EVIDENCE
 *                           │
 *                           ▼
 *                          HALT
 *
 * Layer: foundation observe
 * Owns: fail-closed transition
 * Consumes: failure code
 * Produces: last-failure slot, optional dump, then halt
 * Hardware: none
 * Forbidden: degraded boot
 * Invariant: broken invariant is halt, not continue
 */

#include <nxu/fail.h>
#include <nxu/chronicle.h>
#include <nxu/bbox.h>
#include <nxu/console.h>
#include <nxu/halt.h>

void
nxu_fail(nxu_u32 code, nxu_u64 a, nxu_u64 b)
{
	nxu_chronicle_fail(code, a, b);
	nxu_console_at("FAIL", "Foundation halted", code);
	nxu_debug("FAIL", "failure captured");
	nxu_debug_u64("code", code);
	nxu_debug_u64("a", a);
	nxu_debug_u64("b", b);
	nxu_bbox_dump();
	nxu_halt();
}
