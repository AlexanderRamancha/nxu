/*
 * NXU MAP
 *
 *                    SIGNAL POLICY
 *                           │
 *                           ▼
 *                    SILICON GIC OPS
 *                           │
 *                           ▼
 *                      IRQ / IPI
 *                           │
 *                           ▼
 *                   timer_fired / ipi_seen
 *
 * Layer: foundation signal (S10 S13)
 * Owns: exclusive single-CPU signal bind; INTID class dispatch
 * Consumes: GIC silicon ops, CPU present set, GICR bases as parameters
 * Produces: timer and IPI signals TCB-owned; rdist corroboration
 * Hardware: GICv3 distributor/redistributor/ICC (adapter)
 * Forbidden: 1-of-N; function-pointer handlers; ITS/LPI
 * Invariant: enabled implies one owner; unbound INTID → halt
 */

#include <nxu/signal.h>
#include <nxu/cpu.h>
#include <nxu/facts.h>
#include <nxu/chronicle.h>
#include <nxu/fail.h>
#include <nxu/time.h>
#include <nxu/intake.h>
#include <nxu/console.h>
#include <silicon/aarch64/gicv3/gicv3.h>
#include <silicon/aarch64/sysreg.h>

struct nxu_signal nxu_sig_timer;
struct nxu_signal nxu_sig_ipi;

void
nxu_irq_dispatch(nxu_u32 intid)
{
	nxu_u32 id;

	id = nxu_this_logical();
	if (id >= NXU_CPU_BOUND)
		id = 0U;
	nxu_chronicle_put(NXU_REC_IRQ, intid, id);

	if (intid == nxu_sig_timer.intid && nxu_sig_timer.enabled) {
		nxu_cpu[id].timer_fired++;
		nxu_dsb();
		nxu_timer_ack();
		return;
	}
	if (intid == nxu_sig_ipi.intid && nxu_sig_ipi.enabled) {
		nxu_cpu[id].ipi_seen++;
		nxu_dsb();
		nxu_chronicle_put(NXU_REC_S13_RECV, intid, id);
		return;
	}
	nxu_fail(NXU_FAIL_UNBOUND_IRQ, intid, id);
}

void
nxu_s10_gic(void)
{
	nxu_u64 gicd;
	nxu_u64 gicr_base;
	nxu_u64 gicr;
	nxu_u32 last;
	nxu_u32 nrd;
	nxu_u32 i;
	nxu_u32 el;
	nxu_u32 iidr;
	nxu_u32 typer;

	gicd = nxu_facts.gicd.range.base;
	gicr_base = nxu_facts.gicr.range.base;
	iidr = nxu_gicd_iidr(gicd);
	typer = nxu_gicd_typer(gicd);
	nxu_chronicle_put(NXU_REC_S10_GIC, iidr, typer);
	nxu_console_at("GIC", "GIC discovered", gicd);
	nxu_debug("GIC", "distributor");
	nxu_debug_u64("gicd", gicd);
	nxu_debug_u64("gicr", gicr_base);
	nxu_debug_u64("iidr", iidr);

	/* IIDR/TYPER observation after the MMIO region is owned and mapped. */
	if (nxu_facts.gicd.grade == NXU_GRADE_SINGLE)
		nxu_facts.gicd.grade = NXU_GRADE_CORROBORATED;
	nxu_facts.gicd.source |= NXU_SRC_OBS;

	nrd = 0U;
	gicr = gicr_base;
	last = 0U;
	while (last == 0U) {
		nxu_u64 t = nxu_gicr_typer(gicr);
		nxu_u64 aff = (t >> 32) & 0xFFFFFFFFULL;
		nxu_u32 found = 0U;

		last = (nxu_u32)((t >> 4) & 1ULL);
		for (i = 0U; i < nxu_cpu_present_count; i++) {
			nxu_u64 cpu_aff;

			cpu_aff = (nxu_cpu[i].mpidr & 0x00FFFFFFULL) |
			    (((nxu_cpu[i].mpidr >> 32) & 0xFFULL) << 24);
			if (cpu_aff == aff) {
				nxu_cpu[i].gicr = gicr;
				found = 1U;
			}
		}
		nxu_chronicle_put(NXU_REC_S10_RDIST, aff, found);
		nrd++;
		if (nrd > NXU_CPU_BOUND)
			nxu_fail(NXU_FAIL_GIC, nrd, 0U);
		gicr += NXU_GICR_STRIDE;
	}
	if (nrd != nxu_cpu_present_count)
		nxu_fail(NXU_FAIL_GIC, nrd, nxu_cpu_present_count);
	for (i = 0U; i < nxu_cpu_present_count; i++) {
		if (nxu_cpu[i].gicr == 0U)
			nxu_fail(NXU_FAIL_GIC, nxu_cpu[i].mpidr, 2U);
	}

	el = nxu_control_el();
	nxu_gic_icc_enable(el);
	nxu_gicd_enable(gicd);
	nxu_gicr_wake(nxu_cpu[0].gicr);
	nxu_cpu_present_frozen = 1U;
	nxu_chronicle_put(NXU_REC_S10_FREEZE, nrd, nxu_cpu[0].gicr);
}

void
nxu_s13_ipi(void)
{
	nxu_u32 spins;
	nxu_u32 seen0;
	volatile nxu_u32 *seen;

	nxu_sig_ipi.intid = NXU_SGI_IPI;
	nxu_sig_ipi.owner = NXU_SIG_OWNER_TCB;
	nxu_sig_ipi.route_cpu = 0U;
	nxu_sig_ipi.enabled = 1U;
	nxu_gicr_enable_sgi(nxu_cpu[0].gicr, NXU_SGI_IPI);
	nxu_cpu[0].ipi_seen = 0U;
	seen = &nxu_cpu[0].ipi_seen;
	nxu_dsb();
	nxu_daif_unmask_irq();
	nxu_gic_sgi(NXU_SGI_IPI, nxu_cpu[0].mpidr);
	spins = 0U;
	while (*seen == 0U) {
		spins++;
		asm volatile("" ::: "memory");
		if (spins > 1000000U)
			nxu_fail(NXU_FAIL_TIMEOUT, NXU_SGI_IPI, 0U);
	}
	nxu_chronicle_put(NXU_REC_S13_IPI, NXU_SGI_IPI, nxu_cpu[0].ipi_seen);

	if (nxu_cpu_present_count > 1U) {
		seen0 = nxu_cpu[0].ipi_seen;
		nxu_sig_ipi.route_cpu = 1U;
		nxu_gic_sgi(NXU_SGI_IPI, nxu_cpu[1].mpidr);
		seen = &nxu_cpu[1].ipi_seen;
		spins = 0U;
		while (*seen == 0U) {
			spins++;
			asm volatile("" ::: "memory");
			if (spins > 1000000U)
				nxu_fail(NXU_FAIL_TIMEOUT, NXU_SGI_IPI, 1U);
		}
		if (nxu_cpu[0].ipi_seen != seen0)
			nxu_fail(NXU_FAIL_WRONG_TARGET, nxu_cpu[0].ipi_seen, seen0);
		nxu_chronicle_put(NXU_REC_S13_TARGET, 1U, nxu_cpu[1].ipi_seen);
		nxu_console_at("SMP", "IPI reached CPU", 1U);
		nxu_sig_ipi.route_cpu = 0U;
	}
}
