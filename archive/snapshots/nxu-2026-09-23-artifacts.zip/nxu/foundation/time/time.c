/*
 * NXU MAP
 *
 *                    NXU FOUNDATION
 *                           │
 *                           ▼
 *                     TIMER POLICY
 *                           │
 *                           ▼
 *                  SILICON TIMER ACCESS
 *                           │
 *                           ▼
 *                      TIMER IRQ
 *                           │
 *                           ▼
 *                    NXU OBSERVATION
 *                           │
 *                 ┌─────────┴─────────┐
 *                 ▼                   ▼
 *             CHRONICLE            BLACK BOX
 *                 │
 *                 ▼
 *              CONSOLE
 *
 * Layer: foundation time (S11)
 * Owns: per-CPU one-shot deadline as a TCB signal
 * Consumes: observed CNTFRQ, ISA PPI from control_el, GIC PPI bind
 * Produces: deadline fire via timer PPI; timer_fired visible to S11
 * Hardware: ARM generic timer CNTP/CNTHP
 * Forbidden: HZ tick; UART tick; jiffies; board addresses
 * Invariant: PPI is ISA(control_el); wait observes IRQ store
 */

#include <nxu/time.h>
#include <nxu/facts.h>
#include <nxu/signal.h>
#include <nxu/cpu.h>
#include <nxu/intake.h>
#include <nxu/chronicle.h>
#include <nxu/fail.h>
#include <nxu/console.h>
#include <silicon/aarch64/timer/timer.h>
#include <silicon/aarch64/gicv3/gicv3.h>
#include <silicon/aarch64/sysreg.h>

nxu_u64
nxu_cntpct(void)
{
	return nxu_timer_cntpct();
}

nxu_u64
nxu_cntfrq(void)
{
	return nxu_timer_cntfrq();
}

void
nxu_timer_program(nxu_u64 ticks)
{
	if (nxu_control_el() == NXU_EL2)
		nxu_timer_enable_el2((nxu_u32)ticks);
	else
		nxu_timer_enable_el1((nxu_u32)ticks);
}

nxu_u32
nxu_timer_istatus(void)
{
	if (nxu_control_el() == NXU_EL2)
		return nxu_timer_istatus_el2();
	return nxu_timer_istatus_el1();
}

void
nxu_timer_ack(void)
{
	if (nxu_control_el() == NXU_EL2)
		nxu_timer_mask_el2();
	else
		nxu_timer_mask_el1();
}

void
nxu_s11_time(void)
{
	volatile nxu_u32 *fired;
	nxu_u32 spins;

	nxu_sig_timer.intid = nxu_facts.timer_ppi;
	nxu_sig_timer.owner = NXU_SIG_OWNER_TCB;
	nxu_sig_timer.route_cpu = 0U;
	nxu_sig_timer.enabled = 1U;
	nxu_cpu[0].timer_fired = 0U;
	fired = &nxu_cpu[0].timer_fired;
	nxu_dsb();
	nxu_chronicle_put(NXU_REC_S11_FREQ, nxu_facts.timer_freq, 0U);
	nxu_chronicle_put(NXU_REC_S11_PPI, nxu_facts.timer_ppi, 0U);
	nxu_console_at("TIME", "Timer configured", nxu_facts.timer_ppi);
	nxu_debug("TIME", "one-shot deadline");
	nxu_debug_u64("freq", nxu_facts.timer_freq);
	nxu_debug_u64("ppi", nxu_facts.timer_ppi);

	nxu_gicr_enable_ppi(nxu_cpu[0].gicr, nxu_facts.timer_ppi);
	nxu_timer_program(nxu_facts.timer_freq / 100ULL);
	nxu_daif_unmask_irq();
	spins = 0U;
	while (*fired == 0U) {
		spins++;
		asm volatile("" ::: "memory");
		if (spins > 10000000U) {
			if (nxu_timer_istatus() != 0U)
				nxu_fail(NXU_FAIL_TIMER, nxu_facts.timer_ppi, 2U);
			nxu_fail(NXU_FAIL_TIMER, nxu_facts.timer_ppi, 1U);
		}
	}
	nxu_daif_mask();
	nxu_chronicle_put(NXU_REC_S11_FIRE, spins, nxu_cntpct());
	nxu_console_at("TIME", "Timer fired", nxu_cntpct());
	nxu_debug("TIME", "deadline observed");
	nxu_debug_u64("spins", spins);
}
