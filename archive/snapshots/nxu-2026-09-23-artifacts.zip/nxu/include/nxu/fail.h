/*
 * NXU MAP
 * Layer: foundation observe
 * Owns: nxu_fail prototype
 * Invariant: fail is halt
 */
#ifndef NXU_FAIL_H
#define NXU_FAIL_H

#include <nxu/types.h>

void nxu_fail(nxu_u32 code, nxu_u64 a, nxu_u64 b);

#endif
