#!/bin/sh
# FVP_Base_RevC-2xAEMvA probe.
# AEMvA reset vector is clusterN.cpuM.RVBAR.
# semihosting-enable is global; cluster0.cpu0.semihosting-enable does not exist on cpu0-3.
# Load raw bytes into DRAM and also -a the DRAM-linked ELF so PC = e_entry.
set -e
root=$(CDPATH= cd -- "$(dirname "$0")/../.." && pwd)
img="$root/build-fvp/nxu.img"
elf="$root/build-fvp/nxu.fvp.elf"
model_log="$root/probe/evidence/fvp-base.log"
uart_log="$root/probe/evidence/fvp-uart.log"
load=0x80000000

echo "tree: $root"

case "$root" in
	*Trash*|*trash*)
		echo "FVP refuse: tree is inside Trash: $root" >&2
		exit 1
		;;
esac

if [ ! -f "$img" ]; then
	echo "missing $img (run: make fvp)" >&2
	exit 1
fi

find_fvp() {
	if [ -n "$FVP" ] && [ -x "$FVP" ]; then echo "$FVP"; return 0; fi
	if [ -n "$FVP_BIN" ] && [ -x "$FVP_BIN" ]; then echo "$FVP_BIN"; return 0; fi
	for c in \
		"$root/probe/host/fvp/FVP_Base_RevC-2xAEMvA" \
		FVP_Base_RevC-2xAEMvA
	do
		if [ -x "$c" ]; then echo "$c"; return 0; fi
		w=$(command -v "$c" 2>/dev/null || true)
		[ -n "$w" ] && { echo "$w"; return 0; }
	done
	return 1
}

if ! fvp=$(find_fvp); then
	echo "FVP: NOT EXECUTED"
	echo "reason: FVP binary unavailable"
	exit 0
fi

mkdir -p "$root/probe/evidence"
: > "$model_log"
: > "$uart_log"

echo "FVP binary available: yes"
echo "FVP: $fvp"
echo "image: $img"
echo "elf: $elf"
echo "load: $load"
echo "uart: $uart_log"

# Names confirmed on GCC-9.3 RevC: RVBAR, clusterN.has_el3, global semihosting-enable.
run_one() {
	rc=0
	timeout 25 "$fvp" "$@" > "$model_log" 2>&1 || rc=$?
}

# Prefer DRAM ELF -a (sets PC from e_entry) plus raw --data.
if [ -f "$elf" ]; then
	set -- \
		-C bp.secure_memory=0 \
		-C cache_state_modelled=0 \
		-C bp.refcounter.non_arch_start_at_default=1 \
		-C bp.vis.disable_visualisation=1 \
		-C pctl.startup=0.0.0.0 \
		-C cluster0.NUM_CORES=4 \
		-C cluster1.NUM_CORES=4 \
		-C cluster0.has_el3=0 \
		-C cluster1.has_el3=0 \
		-C cluster0.cpu0.RVBAR="$load" \
		-C cluster0.cpu1.RVBAR="$load" \
		-C cluster0.cpu2.RVBAR="$load" \
		-C cluster0.cpu3.RVBAR="$load" \
		-C cluster1.cpu0.RVBAR="$load" \
		-C cluster1.cpu1.RVBAR="$load" \
		-C cluster1.cpu2.RVBAR="$load" \
		-C cluster1.cpu3.RVBAR="$load" \
		-C semihosting-enable=0 \
		-C bp.pl011_uart0.untimed_fifos=1 \
		-C bp.pl011_uart0.unbuffered_output=1 \
		-C "bp.pl011_uart0.out_file=${uart_log}" \
		-C bp.terminal_0.start_telnet=0 \
		-C bp.terminal_1.start_telnet=0 \
		-C bp.terminal_2.start_telnet=0 \
		-C bp.terminal_3.start_telnet=0 \
		--data "cluster0.cpu0=${img}@${load}" \
		-a "cluster0.cpu0=${elf}"
	echo "FVP argv:"
	printf '  %s\n' "$fvp" "$@"
	run_one "$@"
else
	echo "missing $elf; raw --data only"
	set -- \
		-C bp.secure_memory=0 \
		-C cache_state_modelled=0 \
		-C bp.vis.disable_visualisation=1 \
		-C pctl.startup=0.0.0.0 \
		-C cluster0.has_el3=0 \
		-C cluster0.cpu0.RVBAR="$load" \
		-C semihosting-enable=0 \
		-C bp.pl011_uart0.untimed_fifos=1 \
		-C bp.pl011_uart0.unbuffered_output=1 \
		-C "bp.pl011_uart0.out_file=${uart_log}" \
		-C bp.terminal_0.start_telnet=0 \
		--data "cluster0.cpu0=${img}@${load}"
	run_one "$@"
fi

# If the model rejected a name, print it and stop guessing silently.
if grep -qiE 'does not have a parameter|is not a parameter|Unknown parameter|parameter not found|parameter error' "$model_log"; then
	echo "FVP rejected a parameter. Names on this package:"
	echo "  $FVP --list-params | grep -iE 'RVBAR|has_el3|semihosting'"
	echo "---- model ----"
	sed -n '1,60p' "$model_log"
	exit 1
fi

echo "FVP process started: yes (rc=$rc)"
echo "---- model ----"
sed -n '1,50p' "$model_log"
echo "---- uart ----"
if [ -s "$uart_log" ]; then sed -n '1,80p' "$uart_log"; else echo "(empty)"; fi

if grep -q '\[NXU\]\[S14\]' "$uart_log" "$model_log" 2>/dev/null; then
	echo "S14 observed: yes"
	echo "FVP capture ok: S14 freeze observed"
	exit 0
fi
if grep -q '\[NXU\]' "$uart_log" "$model_log" 2>/dev/null; then
	echo "NXU boot observed: yes (no S14)"
	exit 1
fi
echo "NXU boot observed: no"
echo "FVP capture FAIL: model ran but NXU console was not observed" >&2
echo "next: $fvp --list-params | grep -iE 'RVBAR|has_el3'" >&2
exit 1
