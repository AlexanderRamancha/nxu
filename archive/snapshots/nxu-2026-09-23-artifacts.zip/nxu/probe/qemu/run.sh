#!/bin/sh
# QEMU virt probe. Board knowledge lives here, not in foundation.
# Requires live [NXU][S14] evidence. Do not weaken this check.
set -e
root=$(CDPATH= cd -- "$(dirname "$0")/../.." && pwd)
img="${NXU_IMG:-$root/build-qemu/nxu.img}"
qemu="$root/probe/host/qemu/bin/qemu-system-aarch64"
out="${NXU_LOG:-$root/probe/evidence/qemu-virt.log}"
smp="${NXU_SMP:-4}"

if [ ! -f "$img" ]; then
	echo "missing $img (build first)" >&2
	exit 1
fi
if [ ! -x "$qemu" ]; then
	qemu=qemu-system-aarch64
fi
mkdir -p "$root/probe/evidence"

timeout 8 "$qemu" \
	-machine virt,gic-version=3 \
	-cpu cortex-a57 \
	-smp "$smp" \
	-m 128M \
	-nographic \
	-kernel "$img" \
	> "$out" 2>&1 || true

if ! grep -q '\[NXU\]\[S14\]' "$out"; then
	echo "QEMU capture FAIL: no S14 freeze record" >&2
	tail -n 60 "$out" >&2
	exit 1
fi
if grep -q '\[NXU\]\[FAIL\]' "$out"; then
	echo "QEMU capture FAIL: FAIL record present" >&2
	grep '\[NXU\]\[FAIL\]' "$out" >&2
	exit 1
fi
echo "QEMU capture ok: S14 freeze observed (smp=$smp)"
echo "log: $out"
