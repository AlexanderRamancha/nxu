# research/

Not TCB. Not foundation. Not silicon. Not board.

This directory is hypotheses, experiments, measurements, evidence, and history.
It has **no architectural authority**. Promotion into foundation requires an explicit
amendment of Genesis, not a compile flag, not an include, not a quiet link.

## TCB firewall (non-negotiable)

1. Foundation, silicon, board, and the TCB image allow-list must not include
   `research/` sources, headers, or objects.
2. A probe image that links research is not the TCB image. Two artifacts, never one.
3. `NXU_RUN_*` and kin live in probe/research images only.
4. History under `research/history/` is evidence of evolution. It must not be cited
   as a reason to add a foundation mechanism.
5. Room / Wall / Edge / Fabric / Pulse are names in this tree. They are not
   subsystems until Genesis is amended after evidence.

If a change would make research reachable from the TCB path, the change is rejected.
