| H7 | 2026-09-22 | [H7 structural correction](H7-structural-correction.md) |
| H8 | 2026-09-22 | [H8 S14 observe](H8-s14-observe.md) |
