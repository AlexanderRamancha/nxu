# FOUNDATION_EVIDENCE

Do not claim execution that did not happen.

## Platforms

| Platform | Role | Executed |
|---|---|---|
| QEMU `virt,gic-version=3` cortex-a57 | validation instrument | yes |
| ARM FVP Base | validation instrument | **no** — no FVP binary in this environment |
| Real ARM64 hardware | architectural target | **no** |

QEMU addresses are board facts (`board/qemu-virt/facts.c`). They are not architecture.

## Build

- Toolchain: repository-local `probe/host/zig/zig cc -target aarch64-freestanding-none`, else PATH `aarch64-*-gcc`
- Include roots: `-Iinclude -I.`
- Header deps: `-MMD -MP`
- Image contract: linked at VA 0, `-fno-jump-tables` (a raw binary is not relocated)
- Images: `build-qemu/nxu.img`, `build-debug/nxu.img`, `build-fvp/nxu.elf`, `build-fvp/nxu.img`
- Static checks: `probe/check.sh`

## QEMU virt, smp=4, 128M

Log: `probe/evidence/qemu-virt.log`.

`make qemu` printed the console and `QEMU capture ok: S14 freeze observed (smp=4)`.

Observed normal lines include timer deadline, CPU bring-up complete, inter-processor signal delivered, and `[NXU][S14] NXU foundation is frozen`. No `[NXU][FAIL]`.

## Debug

Log: `probe/evidence/qemu-debug.log`.

Same freeze. Detail uses compact values (`pc=0x40200000`, not a 16-digit pad). Normal lines stay sentences.

## Negative tests

| Test | Method | Result |
|---|---|---|
| Bad image magic | `probe/cases/neg-header.sh` | no `[NXU][S14]` (prior run; re-run not repeated this pass) |

## FVP

`make fvp` built `build-fvp/nxu.elf` (the format FVP loads) and `build-fvp/nxu.img`.

`make fvp-run` reported, including after `make clean` in the same suite:

```
FVP: NOT EXECUTED
FVP binary available: no
FVP process started: no
NXU image loaded: no
NXU boot observed: no
S14 observed: no
```

Resolution order is `$FVP`, `$FVP_BIN`, `probe/host/fvp/`, then PATH. No home directory is compiled in. A search of this machine found no `FVP_Base*` binary. That is not PASS. The launcher loads `build-fvp/nxu.elf` when a model is present. Whether that model's DTB ranges match `board/fvp-base/facts.c` exactly is NOT VERIFIED, because the model never started.

## Real hardware

**NOT EXECUTED.**
