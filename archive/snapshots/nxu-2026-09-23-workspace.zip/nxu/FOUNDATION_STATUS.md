# Foundation status

S0–S14 frozen. Genesis v2 + closure unchanged. Architecture changes this pass: NONE.

| Stage | Status | Evidence |
|---|---|---|
| S0–S14 | implemented | QEMU virt, smp=4, live `[NXU][S14] NXU foundation is frozen` |
| QEMU | EXECUTED | `make qemu` requires that line and shows the console |
| Debug | EXECUTED | `make debug` same freeze, compact `[NXU][DBG]` values |
| FVP build | BUILT | `build-fvp/nxu.elf` and `build-fvp/nxu.img` |
| FVP run | NOT EXECUTED | no FVP binary via `$FVP`, `$FVP_BIN`, repository-local, or PATH |
| Real SoC | NOT EXECUTED | `board/soc/` facts present=0 |

Probe boundary, not architecture: QEMU is captured on a PTY so a non-terminal `make qemu` still sees serial. FVP loads the ELF. The image is linked at VA 0, so the build passes `-fno-jump-tables`.
