# NXU

Machine-control and isolation substrate. Not Linux. Genesis v2 plus closure is the authority. S0–S14 are frozen.

## Workflow

```
make clean
make
make qemu
make debug
make fvp
make fvp-run
```

`make` builds `build-qemu/nxu.img`.
`make qemu` executes QEMU virt GICv3 and requires a live `[NXU][S14]` line. It does not hide the console.
`make debug` builds `build-debug/nxu.img` with `[NXU][DBG]` evidence and runs the same QEMU check.
`make fvp` builds the FVP image and runs it. The model loads the image at DRAM `0x80000000`, not at `0x0` (BL1). UART0 is written to `probe/evidence/fvp-uart.log` and shown on the console. If no model is installed it reports `FVP: NOT EXECUTED`. That is not PASS.

QEMU and FVP are validation instruments. Real ARM64 hardware is the target. Neither model is architectural authority.

## Include model

Every compilation uses `-Iinclude -I.` from the Makefile.

- `<nxu/...>` public TCB types and prototypes
- `<silicon/...>` hardware operation headers

Do not add per-file relative include paths. The image is linked at VA 0 and loaded elsewhere, so the build passes `-fno-jump-tables`.

## Tree

```
foundation/     Genesis policy and S0–S14
silicon/        ARM64 hardware operations (addresses as parameters)
board/          platform candidate facts only
image/          image format and linker layout
include/nxu/    public interfaces
probe/          host-side build, run, check
research/       history only; never linked
```

## Layers

```
Hardware
   │
   ▼
silicon/aarch64
   │
   ▼
board facts
   │
   ▼
foundation policy
   │
   ▼
S0–S14
   │
   ▼
observe / chronicle / Black Box / console
```
