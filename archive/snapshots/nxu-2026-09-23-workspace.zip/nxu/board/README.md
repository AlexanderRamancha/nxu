# board/

## Why

A platform is a set of candidate facts. It is not a second architecture and not a behavior fork.

## Layer

Board. Candidates only.

## Ownership

RAM, GIC, UART, CPU affinities, and PSCI conduit suggestions for one platform.

## Dependencies

Included only as data (`nxu_board`). No silicon calls. Foundation may reject every candidate.

## Direction

```
board facts → foundation facts (corroboration) → accept or halt
```

## Files

| Directory | Owns | Consumes | Produces |
|---|---|---|---|
| `qemu-virt/` | QEMU virt candidates | none | `nxu_board` |
| `fvp-base/` | FVP Base candidates | none | `nxu_board` |
| `soc/` | real-SoC placeholder | none | present = 0 |

## Hardware

None. Numbers here describe hardware. They do not touch it.

## Forbidden

Behavior. Silicon calls. Skip-validation. `if (qemu)` in foundation.

## Invariants

The same foundation and silicon link against each board file. Addresses do not appear in foundation or silicon sources.

## Evidence

`build-qemu` and `build-fvp` are separate artifacts. QEMU executed. FVP did not, in the latest environment.

## History

Hardcoded QEMU addresses inside architectural C were the historical failure this directory exists to contain.

## Status

QEMU facts BUILT and used. FVP facts BUILT. Real SoC NOT DESCRIBED.
