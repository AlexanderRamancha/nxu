# board/fvp-base/

## Why

FVP Base is a second validation instrument. It must not create a second kernel.

## Layer

Board facts.

## Ownership

Candidate RAM, GICD, GICR, UART, eight affinities, PSCI SMC.

## Dependencies

None. Same foundation and silicon as QEMU.

## Direction

```
this file → nxu_board → foundation/facts
```

## Files

| File | Owns | Consumes | Produces |
|---|---|---|---|
| `facts.c` | FVP Base candidates | none | `nxu_board` |

## Hardware

None in this file. The described machine is FVP Base RevC.

## Forbidden

Behavior. An FVP-only code path in foundation. Loading a different image format from foundation.

## Invariants

Artifact format differs at the probe: FVP loads `build-fvp/nxu.elf`. QEMU loads `build-qemu/nxu.img`. Same TCB.

## Evidence

`make fvp` BUILT the ELF and the image. `make fvp-run` was NOT EXECUTED here: no FVP binary on PATH, in `$FVP`, in `$FVP_BIN`, or under `probe/host/fvp/`.

## History

An earlier launcher passed `nxu.img` to `-a cluster0.cpu0=`. Fast Models reject that format. The ELF is the probe fix, not a new image architecture.

## Status

Facts BUILT. Execution NOT EXECUTED in the latest environment.
