# board/qemu-virt/

## Why

QEMU virt is a validation instrument. Its addresses are candidates, not the architecture.

## Layer

Board facts.

## Ownership

Candidate RAM, GICD, GICR, UART, four affinities, PSCI HVC.

## Dependencies

None. Foundation corroborates against the DTB and observations.

## Direction

```
this file → nxu_board → foundation/facts
```

## Files

| File | Owns | Consumes | Produces |
|---|---|---|---|
| `facts.c` | QEMU virt candidates | none | `nxu_board` |

## Hardware

None in this file. The described machine is QEMU `virt` GICv3.

## Forbidden

Behavior. Calls. Being included from silicon.

## Invariants

If the DTB disagrees, boot halts. Extra candidate CPUs are not present unless named.

## Evidence

QEMU smp=4 corroborated these candidates and froze. smp=2 previously showed present count 2.

## History

These constants used to live in architectural C. They were moved here so a different board does not fork policy.

## Status

BUILT. Used by `make qemu`. Not authority.
