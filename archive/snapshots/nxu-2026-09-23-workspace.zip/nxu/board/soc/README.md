# board/soc/

## Why

Real ARM64 hardware is the target. It is not described yet. An empty candidate table must fail closed rather than pretend to be QEMU.

## Layer

Board facts.

## Ownership

A placeholder. `present` is 0.

## Dependencies

None.

## Direction

```
future SoC notes → this file → foundation facts → halt until facts exist
```

## Files

| File | Owns | Consumes | Produces |
|---|---|---|---|
| `facts.c` | empty candidates | none | `present = 0` |

## Hardware

None yet.

## Forbidden

Copying QEMU addresses into this file to "make it boot".

## Invariants

Architecture stays identical. Only facts change, and they are still candidates.

## Evidence

NOT EXECUTED on hardware.

## History

Genesis: QEMU and FVP are instruments. A real SoC is not validated by either.

## Status

NOT DESCRIBED. NOT EXECUTED.
