/*
 * NXU MAP
 *
 *                      REAL SOC
 *                           │
 *                           ▼
 *                   CANDIDATE FACTS
 *                    (present = 0)
 * Layer: board/soc (candidate facts)
 * Owns: placeholder SoC fact table; present=0 until a real SoC is described
 * Consumes: none
 * Produces: empty candidates (boot with this board fails closed at facts)
 * Hardware: none until filled from a real SoC
 * Forbidden: behavior, silicon calls, skip-validation
 * Invariant: architecture is identical; only facts would change
 * Architectural role: Placeholder candidates with present clear. A real SoC is not described here yet.
 */

#include <nxu/board.h>

const struct nxu_board_facts nxu_board = {
	.present = 0U,
	.ram_count = 0U,
	.cpu_count = 0U,
	.psci_conduit = NXU_PSCI_NONE,
};
