# foundation/

## Why this directory exists

Foundation is the trusted computing base: the policy that decides what the machine may do. It is not a Unix kernel and it is not a driver tree.

## Layer

Foundation. It sits above silicon operations and board candidate facts, and it sequences S0–S14.

## Ownership

Stage order, acceptance and rejection, CPU lifecycle policy, signal ownership, translation policy, and the decision to halt.

## Dependencies

Consumes silicon operations (addresses as parameters), the image footprint, and board candidates. Does not read `research/`.

## Dependency direction

```
board candidates + silicon observations
        │
        ▼
   foundation policy
        │
        ▼
   silicon operations
```

## Files

| File | Owns | Consumes | Produces |
|---|---|---|---|
| `enter.c` | S0–S14 order | every stage | freeze then halt |
| `intake/` | residue and footprint | entry record | S0 S1 records |
| `contract/` | header shape | image base | accept or halt |
| `facts/` | corroboration | DTB, board, observations | accepted facts |
| `space/` | ownership and map policy | facts, image | armed translation |
| `exception/` | vector and fault policy | context, GIC ops | halt or INTID record |
| `context/` | `nxu_cpu_exec_context` bind | stack, TTBR | one bound context |
| `cpu/` | present set and bring-up | facts, PSCI | online or halt |
| `signal/` | exclusive signals | GIC ops | TCB-owned timer and IPI |
| `time/` | one-shot deadline | timer ops, PPI | observed fire |
| `observe/` | chronicle, Black Box, console | events | evidence and halt |

## Hardware

None directly. Hardware is reached only through silicon.

## Forbidden

Board addresses. Research names as types. Handler function pointers. A scheduler. Skipping a stage.

## Invariants

Ownership-phase order. Fail closed. One bound context per online CPU. Research is not linked.

## Validation

QEMU virt smp=4 reaches `[NXU][S14] NXU foundation is frozen`. FVP execution is not claimed from this tree's last run.

## History

Genesis v2 made foundation the solid layer, not a small stub around Linux-shaped code. See `research/history/`.

## Status

BUILT. S0–S14 TESTED on QEMU. FVP NOT EXECUTED in the environment that produced the latest evidence file.
