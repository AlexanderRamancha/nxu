# foundation/context/

## Why

Each online CPU needs exactly one bound execution record. The type name is `nxu_cpu_exec_context`. It was not renamed.

## Layer

Foundation. Used from S7 onward and from CPU init.

## Ownership

Binding identity, life, translation regime, and stack bounds into the CPU slot.

## Dependencies

Consumes the CPU slot, control EL, and the TCB TTBR/TCR/MAIR. Produces a context whose translate fields are the TCB regime.

## Direction

```
CPU slot + TCB tables → nxu_cpu_exec_context
```

## Files

| File | Owns | Consumes | Produces |
|---|---|---|---|
| `context.c` | bind of the canonical context | stack bounds, MMU regime, EL | life armed, running, or waiting |

## Hardware

None. Register values are copied from silicon helpers.

## Forbidden

A second translation regime. Scheduling. Renaming the type. A thread, process, or task object.

## Invariants

One bound context per online CPU. Life at freeze is running or waiting. Translate fields match the TCB tables.

## Evidence

S14 checks those fields before it prints the freeze line. QEMU reached that line.

## History

Closure C16 dropped the informal name "atom". C14 keeps translate equal to the TCB regime.

## Status

BUILT. Checked on the QEMU freeze path.
