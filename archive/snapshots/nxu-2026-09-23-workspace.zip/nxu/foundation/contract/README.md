# foundation/contract/

## Why

The ARM64 image header is a structural boot contract. It is not a signature and not a trust root.

## Layer

Foundation. S2.

## Ownership

Magic, flags, and size checks against the PC-relative footprint.

## Dependencies

Consumes `nxu_image`. Produces accept or halt. No silicon calls.

## Direction

```
intake footprint → contract → facts
```

## Files

| File | Owns | Consumes | Produces |
|---|---|---|---|
| `contract.c` | header shape check | image base | accept or halt |

## Hardware

None.

## Forbidden

Treating the Linux boot header as a trust model. Skipping the check because QEMU loaded the file.

## Invariants

Bad magic, flags, or size halt before UART ownership. A corrupted header must not reach S14.

## Evidence

Negative header case: no S14 line. See `probe/cases/neg-header.sh`.

## History

Genesis put the boot contract in foundation and left cryptographic boot in research.

## Status

BUILT. Negative case previously OBSERVED. Not re-run in the latest full `make` pass.
