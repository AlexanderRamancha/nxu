# foundation/cpu/

## Why

Topology is a lifecycle, not a pair of symbols for CPU 0 and CPU 1.

## Layer

Foundation. S8 present. S9 initialize. S12 bring-up.

## Ownership

Present, initialized, available, starting, online, failed. One stack per present CPU. Secondary occupy path. Timeout after CPU_ON.

## Dependencies

Consumes accepted CPU facts and the boot MPIDR. S12 calls the PSCI adapter and requires tables already frozen. Secondaries do not discover.

## Direction

```
facts → present set → init → (signal freeze) → CPU_ON → online or halt
```

## Files

| File | Owns | Consumes | Produces |
|---|---|---|---|
| `cpu.c` | present set, logical ids, stacks, boot context | CPU facts, boot MPIDR | initialized then available slots |
| `smp.c` | occupy path and bring-up | available set, PSCI | N online or halt |

## Hardware

TPIDR holds the logical id. PSCI is an adapter. MPIDR is an observation.

## Forbidden

`cpu_start(1)`. A single secondary stack symbol. Treating present as online. Treating CPU_ON success as online. Secondaries walking the DTB.

## Invariants

Boot MPIDR is in the present set. At freeze every present CPU is online. N comes from facts.

## Evidence

QEMU smp=4: `Four CPUs were discovered`, then `CPU bring-up is complete`, then S14. An earlier smp=2 capture showed N follow the DTB.

## History

The historical tree started one secondary and kept one stack symbol. Genesis replaced that with the four-state model plus failed.

## Status

BUILT. TESTED on QEMU virt. Heterogeneous CPUs NOT TESTED.
