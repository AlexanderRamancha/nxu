/*
 * NXU MAP
 *
 *                     AVAILABLE SET
 *                           │
 *                           ▼
 *                    PSCI CPU_ON
 *                           │
 *                           ▼
 *                    TIMEOUT WAIT
 *                           │
 *                           ▼
 *                     ONLINE OR HALT
 * Layer: foundation cpu (S12)
 * Owns: secondary occupy path; CPU_ON + timeout; freeze tables before CPU_ON
 * Consumes: available set, PSCI adapter, already-built tables
 * Produces: N present → N online or halt
 * Hardware: PSCI CPU_ON as adapter only
 * Forbidden: CPU_ON success as online; secondaries discovering
 * Invariant: A12; N from facts
 * Architectural role: Brings every present CPU online. CPU_ON success is not online.
 */
#include <nxu/cpu.h>
#include <nxu/facts.h>
#include <nxu/space.h>
#include <nxu/intake.h>
#include <nxu/chronicle.h>
#include <nxu/fail.h>
#include <nxu/time.h>
#include <nxu/signal.h>
#include <nxu/console.h>
#include <silicon/aarch64/psci/psci.h>
#include <silicon/aarch64/sysreg.h>
#include <silicon/aarch64/translate/mmu.h>
#include <silicon/aarch64/gicv3/gicv3.h>
#include <silicon/aarch64/timer/timer.h>

void
nxu_secondary(nxu_u64 logical)
{
	nxu_u32 id;
	nxu_u32 el;
	extern char nxu_vec_full[];
	nxu_u64 vbar;

	id = (nxu_u32)logical;
	if (id == 0U || id >= nxu_cpu_present_count)
		nxu_fail(NXU_FAIL_CPU, id, 4U);

	el = nxu_current_el();
	if (el != nxu_control_el())
		nxu_fail(NXU_FAIL_BAD_EL, el, 1U);

	nxu_mmu_enable(el);
	vbar = (nxu_u64)(nxu_uptr)nxu_vec_full;
	if (el == 2U)
		nxu_msr_s3_4_c12_c0_0(vbar);
	else
		nxu_msr(vbar_el1, vbar);
	nxu_isb();
	nxu_gic_icc_enable(el);
	nxu_gicr_wake(nxu_cpu[id].gicr);
	nxu_gicr_enable_ppi(nxu_cpu[id].gicr, nxu_facts.timer_ppi);
	nxu_gicr_enable_sgi(nxu_cpu[id].gicr, NXU_SGI_IPI);
	if (el == NXU_EL2)
		nxu_timer_mask_el2();
	else
		nxu_timer_mask_el1();
	nxu_cpu[id].ctx.life = NXU_CTX_WAITING;
	nxu_dsb();
	nxu_cpu[id].state = NXU_CPU_ONLINE;
	nxu_dsb();
	nxu_chronicle_put(NXU_REC_SEC_ENTER, id, nxu_cpu[id].mpidr);
	nxu_daif_unmask_irq();
	for (;;) {
		asm volatile("wfi" ::: "memory");
	}
}

void
nxu_s12_smp(void)
{
	nxu_u32 i;
	nxu_u64 entry;
	nxu_u64 deadline;
	nxu_u64 ret;

	nxu_facts.frozen = 1U;
	nxu_space.frozen = 1U;
	nxu_console("SMP", "NXU is bringing CPUs online");

	if (nxu_cpu_present_count <= 1U) {
		nxu_cpu[0].state = NXU_CPU_ONLINE;
		nxu_chronicle_put(NXU_REC_S12_ONLINE, 1U, 0U);
		nxu_console("SMP", "CPU bring-up is complete");
		return;
	}
	if (nxu_facts.psci_conduit == NXU_PSCI_NONE)
		nxu_fail(NXU_FAIL_PSCI, 0U, 0U);

	asm volatile("adr %0, nxu_secondary_entry" : "=r"(entry));
	nxu_cpu[0].state = NXU_CPU_ONLINE;

	for (i = 1U; i < nxu_cpu_present_count; i++) {
		nxu_cpu[i].state = NXU_CPU_STARTING;
		nxu_chronicle_put(NXU_REC_S12_ON, i, nxu_cpu[i].mpidr);
		ret = nxu_psci_cpu_on(nxu_facts.psci_conduit, nxu_cpu[i].mpidr,
		    entry, (nxu_u64)i);
		if (ret != 0U)
			nxu_fail(NXU_FAIL_PSCI, ret, i);
		nxu_debug("SMP", "CPU_ON issued");
		nxu_debug_u64("cpu", i);
		nxu_debug_u64("mpidr", nxu_cpu[i].mpidr);
	}

	deadline = nxu_cntpct() + nxu_cntfrq() * 2ULL;
	for (;;) {
		nxu_u32 done = 1U;
		for (i = 1U; i < nxu_cpu_present_count; i++) {
			if (nxu_cpu[i].state != NXU_CPU_ONLINE)
				done = 0U;
		}
		if (done)
			break;
		if (nxu_cntpct() > deadline)
			nxu_fail(NXU_FAIL_TIMEOUT, nxu_cpu_present_count, 0U);
		asm volatile("" ::: "memory");
	}
	nxu_chronicle_put(NXU_REC_S12_ONLINE, nxu_cpu_present_count, 0U);
	for (i = 1U; i < nxu_cpu_present_count; i++) {
		nxu_debug("SMP", "CPU online");
		nxu_debug_u64("cpu", i);
		nxu_debug_u64("mpidr", nxu_cpu[i].mpidr);
		nxu_debug_u64("state", nxu_cpu[i].state);
	}
	nxu_console("SMP", "CPU bring-up is complete");
}
