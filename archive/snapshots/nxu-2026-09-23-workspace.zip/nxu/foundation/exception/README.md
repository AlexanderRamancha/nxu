# foundation/exception/

## Why

Vectors must be NXU's before any unmask. An unexpected class is a halt, not a callback table.

## Layer

Foundation. S7, plus the C path entered from silicon vectors.

## Ownership

VBAR install. Saving ESR, FAR, and INTID into the bound `nxu_cpu_exec_context`. Halt on an unexpected class.

## Dependencies

Consumes the boot context bind, GIC acknowledge and end operations, and sysreg reads. Does not own redistributor discovery.

## Direction

```
silicon vectors → exception policy → context fields → halt or return
```

## Files

| File | Owns | Consumes | Produces |
|---|---|---|---|
| `exception.c` | S7 and C entry | context, ESR/FAR, IAR | fault record or INTID dispatch by number |

## Hardware

VBAR, ESR, FAR, ICC_IAR, ICC_EOIR. Operations only.

## Forbidden

Function-pointer handlers. Continuing after an unexpected class.

## Invariants

VBAR is NXU's before unmask. ESR and FAR are recorded before halt.

## Evidence

QEMU prints `Exception handling is installed` before CPU discovery. A dedicated unmapped-access probe image was NOT EXECUTED.

## History

Historical IRQ paths stored a handler function. Genesis rejected that. Dispatch is by INTID class inside this file.

## Status

BUILT. VBAR install TESTED. Sync-fault path BUILT, not separately MEASURED.
