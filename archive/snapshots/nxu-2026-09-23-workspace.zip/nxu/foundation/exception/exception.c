/*
 * NXU MAP
 *
 *                    SILICON VECTORS
 *                           │
 *                           ▼
 *                   EXCEPTION POLICY
 *                           │
 *                           ▼
 *                  nxu_cpu_exec_context
 * Layer: foundation exception
 * Owns: S7 VBAR; C path from silicon vectors; save into bound context
 * Consumes: nxu_cpu_exec_context, GIC IAR/EOI, ESR/FAR via silicon
 * Produces: faulted context + halt on unexpected class; IRQ dispatch by INTID
 * Hardware: VBAR, ESR, FAR, ICC_IAR/EOI (ops only)
 * Forbidden: function-pointer handlers; continue after unexpected class
 * Invariant: VBAR is NXU's before unmask; ESR/FAR recorded before halt
 * Architectural role: Installs NXU vectors and records fault or INTID into the bound context.
 */

#include <nxu/exception.h>
#include <nxu/context.h>
#include <nxu/cpu.h>
#include <nxu/intake.h>
#include <nxu/chronicle.h>
#include <nxu/fail.h>
#include <nxu/signal.h>
#include <nxu/console.h>
#include <silicon/aarch64/sysreg.h>
#include <silicon/aarch64/gicv3/gicv3.h>

void
nxu_exception(nxu_u32 kind)
{
	nxu_u64 esr;
	nxu_u64 far;
	nxu_u32 el;
	nxu_u32 id;
	nxu_cpu_exec_context *ctx;

	el = nxu_control_el();
	if (el == NXU_EL2) {
		esr = nxu_mrs_s3_4_c5_c2_0();
		far = nxu_mrs_s3_4_c6_c0_0();
	} else {
		esr = nxu_mrs(esr_el1);
		far = nxu_mrs(far_el1);
	}

	id = nxu_this_logical();
	if (id >= NXU_CPU_BOUND)
		id = 0U;
	ctx = &nxu_cpu[id].ctx;
	ctx->esr = esr;
	ctx->far = far;
	ctx->el = el;
	ctx->life = NXU_CTX_FAULTED;
	ctx->intid = 0U;
	nxu_chronicle_put(NXU_REC_S7_FAULT, esr, far);

	if (kind == 4U)
		nxu_fail(NXU_FAIL_SERROR, esr, far);
	nxu_fail(NXU_FAIL_SYNC, esr, far);
}

void
nxu_irq_c(void)
{
	nxu_u32 intid;
	nxu_u32 id;
	nxu_cpu_exec_context *ctx;

	intid = nxu_gic_iar();
	id = nxu_this_logical();
	if (id >= NXU_CPU_BOUND)
		id = 0U;
	ctx = &nxu_cpu[id].ctx;
	ctx->intid = intid;
	ctx->daif = 0U;

	if (intid >= 1020U && intid <= 1023U) {
		nxu_gic_eoi(intid);
		ctx->intid = 0U;
		return;
	}
	nxu_irq_dispatch(intid);
	nxu_gic_eoi(intid);
	ctx->intid = 0U;
}

void
nxu_s7_exception(void)
{
	nxu_u32 el;
	extern char nxu_vec_full[];
	nxu_u64 vbar;

	nxu_context_bind_boot();

	el = nxu_control_el();
	vbar = (nxu_u64)(nxu_uptr)nxu_vec_full;
	if (el == NXU_EL2)
		nxu_msr_s3_4_c12_c0_0(vbar);
	else
		nxu_msr(vbar_el1, vbar);
	nxu_isb();
	nxu_chronicle_put(NXU_REC_S7_CTX, 0U, nxu_cpu[0].ctx.life);
	nxu_chronicle_put(NXU_REC_S7_VBAR, vbar, el);
	nxu_console("EXC", "Exception handling is installed");
	nxu_debug("EXC", "VBAR programmed");
	nxu_debug_u64("vbar", vbar);
	nxu_debug_u64("el", el);
}
