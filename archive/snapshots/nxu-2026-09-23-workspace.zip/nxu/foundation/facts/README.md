# foundation/facts/

## Why

Hardware description is a candidate. Facts are what remains after corroboration.

## Layer

Foundation. S3 decodes. S4 accepts.

## Ownership

Bounded DTB probe. Source mask and grade. Load-bearing acceptance: RAM containing the image, boot MPIDR, control EL, timer frequency, enable method when more than one CPU is present.

## Dependencies

Consumes intake, image footprint, board candidates, and CNTFRQ via silicon. Produces `nxu_facts` for space, CPU, signal, and time.

## Direction

```
DTB + board + observation → decoder → corroboration → accepted facts
```

The decoder has no policy. It is not a fifth layer.

## Files

| File | Owns | Consumes | Produces |
|---|---|---|---|
| `fdt.c` | bounded untrusted parse | x0, image range | `nxu_dtb_cand` |
| `facts.c` | accept or halt | candidates and CNTFRQ | graded facts |

## Hardware

CNTFRQ is observed. DTB bytes are an untrusted read in the bootstrap window, not MMIO ownership.

## Forbidden

Board addresses in this directory. Treating DTB as truth. Using platform RAM size as the probe cap. Skipping a mismatch.

## Invariants

Disagreeing sources halt. Image is inside accepted RAM. DTB does not overlap the image. PSCI method is recorded even if the property order differs.

## Evidence

QEMU smp=4 and an earlier smp=2 run showed N from the DTB, not a compiled CPU count. Grades were corroborated where board and DTB agreed.

## History

Historical code validated a DTB header and then ignored it while addresses stayed hardcoded. Facts exist to make that mistake fail closed.

## Status

BUILT. TESTED on QEMU virt.
