# foundation/intake/

## Why

Entry residue is untrusted. Intake records it and rejects states NXU will not inherit.

## Layer

Foundation. S0 and S1.

## Ownership

Image footprint from the program counter. Control EL. MMU-on rejection. Chronicle of EL, MPIDR, SCTLR, PC, DAIF.

## Dependencies

Depends on silicon entry having filled `nxu_intake`, and on image symbols. Used by later stages as observation, not as authority.

## Direction

```
silicon/aarch64/entry → intake → contract / facts
```

## Files

| File | Owns | Consumes | Produces |
|---|---|---|---|
| `s0.c` | footprint and MMU-on reject | residue, linker symbols | `nxu_image` base/size |
| `intake.c` | S1 record | `nxu_intake` | chronicle of entry state |

## Hardware

None. Values were sampled at entry.

## Forbidden

Using the incoming stack. Taking over firmware page tables. Treating a non-zero DTB pointer as validation.

## Invariants

SCTLR.M set means halt. EL is 1 or 2. DAIF is masked. NXU SP is not the incoming SP.

## Evidence

QEMU entry was observed with MMU off and EL1. A dedicated MMU-on injection was NOT EXECUTED as its own image.

## History

Historical trees treated a DTB pointer as success and kept the firmware stack. Intake exists so those are records, not inheritance.

## Status

BUILT. TESTED as part of the QEMU freeze path.
