# foundation/observe/

## Why

Failure and freeze must leave evidence. Printing is not architecture. A log framework is not a Black Box.

## Layer

Foundation. Used throughout, and S14 lives here.

## Ownership

Per-CPU chronicle. Bounded Black Box with an immortal last-failure slot. Optional UART console. Halt.

## Dependencies

Chronicle may run before the UART exists. Console and sink run only after space arms and a UART is accepted. Halt does not require either.

## Direction

```
event → chronicle → Black Box
                 → console (optional, after ownership)
failure → last-failure slot → halt
```

## Files

| File | Owns | Consumes | Produces |
|---|---|---|---|
| `chronicle.c` | per-CPU records | event code and two values | ring plus Black Box copy |
| `bbox.c` | bounded ring and last failure | those records | preserved evidence |
| `console.c` | human sentences and debug lines | sink, tag, text | `[NXU][TAG]` lines |
| `sink.c` | UART bind and byte helpers | accepted UART PA | characters |
| `fail.c` | fail-closed transition | failure code | halt |
| `freeze.c` | S14 invariant check | space, CPUs, signals, contexts | freeze record and S14 line |
| `halt.c` | final wait | none | masked DAIF and WFI |

## Hardware

PL011 only as an optional sink. DAIF and WFI in halt.

## Forbidden

Printing from IRQ context. Printing before ownership. Quoted slogans. Replacing the Black Box with printf. Fail-open on chronicle overflow.

## Invariants

No sink means silence. CPU0 prints. Overflow never fail-opens. The last-failure slot is not overwritten by ordinary records. Halt does not need the UART.

## Evidence

Normal QEMU console is sentences without padded addresses. Debug adds compact `key=0x...` lines. S14 is a sentence: `NXU foundation is frozen`.

## History

H8 split a hex dump at halt into chronicle, Black Box, and a live console line so a timeout cannot clip the only freeze evidence.

## Status

BUILT. TESTED on QEMU, normal and debug.
