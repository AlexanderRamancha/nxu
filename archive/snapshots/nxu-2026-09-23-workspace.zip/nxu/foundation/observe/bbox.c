/*
 * NXU MAP
 *
 *                    FOUNDATION OBSERVE
 *                           │
 *                 ┌─────────┴─────────┐
 *                 ▼                   ▼
 *             CHRONICLE            BLACK BOX
 *                                     │
 *                                     ▼
 *                              PRESERVED RING
 *                                     │
 *                                     ▼
 *                                 FAIL DUMP
 *
 * Layer: foundation observe
 * Owns: per-CPU bounded ring; immortal last-failure
 * Consumes: code, a, b from observe path
 * Produces: dumpable evidence at fail
 * Hardware: none
 * Forbidden: allocation; pointers retained; policy decisions
 * Invariant: overflow overwrites oldest non-failure; fail slot stays
 * Architectural role: Keeps a bounded per-CPU ring and an immortal last-failure slot.
 */

#include <nxu/bbox.h>
#include <nxu/config.h>
#include <nxu/cpu.h>
#include <nxu/sink.h>
#include <nxu/console.h>

struct nxu_bbox_rec {
	nxu_u32 code;
	nxu_u32 cpu;
	nxu_u64 a;
	nxu_u64 b;
};

struct nxu_bbox {
	nxu_u32 next;
	nxu_u32 count;
	nxu_u32 fail_code;
	nxu_u8  fail_valid;
	nxu_u64 fail_a;
	nxu_u64 fail_b;
	struct nxu_bbox_rec rec[NXU_BBOX_CAP];
};

static struct nxu_bbox nxu_bbox_cpu[NXU_CPU_BOUND];

void
nxu_bbox_init(void)
{
	nxu_u32 cpu;
	nxu_u32 i;

	for (cpu = 0U; cpu < NXU_CPU_BOUND; cpu++) {
		nxu_bbox_cpu[cpu].next = 0U;
		nxu_bbox_cpu[cpu].count = 0U;
		nxu_bbox_cpu[cpu].fail_code = 0U;
		nxu_bbox_cpu[cpu].fail_valid = 0U;
		nxu_bbox_cpu[cpu].fail_a = 0U;
		nxu_bbox_cpu[cpu].fail_b = 0U;
		for (i = 0U; i < NXU_BBOX_CAP; i++) {
			nxu_bbox_cpu[cpu].rec[i].code = 0U;
			nxu_bbox_cpu[cpu].rec[i].cpu = cpu;
			nxu_bbox_cpu[cpu].rec[i].a = 0U;
			nxu_bbox_cpu[cpu].rec[i].b = 0U;
		}
	}
}

static struct nxu_bbox *
bbox_this(void)
{
	nxu_u32 id;

	id = nxu_this_logical();
	if (id >= NXU_CPU_BOUND)
		id = 0U;
	return &nxu_bbox_cpu[id];
}

void
nxu_bbox_put(nxu_u32 code, nxu_u64 va, nxu_u64 vb)
{
	struct nxu_bbox *box;
	struct nxu_bbox_rec *r;
	nxu_u32 i;
	nxu_u32 id;

	box = bbox_this();
	id = nxu_this_logical();
	if (id >= NXU_CPU_BOUND)
		id = 0U;
	i = box->next % NXU_BBOX_CAP;
	r = &box->rec[i];
	r->code = code;
	r->cpu = id;
	r->a = va;
	r->b = vb;
	box->next = i + 1U;
	box->count++;
}

void
nxu_bbox_fail(nxu_u32 code, nxu_u64 va, nxu_u64 vb)
{
	struct nxu_bbox *box;

	nxu_bbox_put(code, va, vb);
	box = bbox_this();
	box->fail_code = code;
	box->fail_a = va;
	box->fail_b = vb;
	box->fail_valid = 1U;
}

void
nxu_bbox_dump(void)
{
	nxu_u32 cpu;
	nxu_u32 n;
	nxu_u32 i;
	nxu_u32 idx;
	struct nxu_bbox *box;

	if (!nxu_sink_ready)
		return;

	for (cpu = 0U; cpu < NXU_CPU_BOUND; cpu++) {
		box = &nxu_bbox_cpu[cpu];
		if (box->count == 0U && box->fail_valid == 0U)
			continue;
		nxu_console("BBOX", "Black Box retained failure evidence");
#ifdef NXU_DEBUG
		n = box->count;
		if (n > NXU_BBOX_CAP)
			n = NXU_BBOX_CAP;
		for (i = 0U; i < n; i++) {
			if (box->count > NXU_BBOX_CAP)
				idx = (box->next + i) % NXU_BBOX_CAP;
			else
				idx = i;
			nxu_debug_u64("code", box->rec[idx].code);
			nxu_debug_u64("a", box->rec[idx].a);
			nxu_debug_u64("b", box->rec[idx].b);
		}
		if (box->fail_valid) {
			nxu_debug_u64("fail", box->fail_code);
			nxu_debug_u64("fail_a", box->fail_a);
			nxu_debug_u64("fail_b", box->fail_b);
		}
#else
		(void)n;
		(void)i;
		(void)idx;
#endif
	}
}
