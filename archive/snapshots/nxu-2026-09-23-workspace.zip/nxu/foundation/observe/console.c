/*
 * NXU MAP
 *
 *                    FOUNDATION OBSERVE
 *                           │
 *                           ▼
 *                        CONSOLE
 *                           │
 *                           ▼
 *                     UART SINK (optional)
 *
 * Layer: foundation observe
 * Owns: [NXU][TAG] live text; debug key/value lines
 * Consumes: sink bind; tag; sentence; address
 * Produces: compact UART lines after ownership
 * Hardware: none (sink holds the UART PA)
 * Forbidden: print from IRQ; print before bind; quoted output
 * Invariant: no sink → silent; CPU0 only
 * Architectural role: Prints human sentences after the UART is owned. Debug detail stays behind NXU_DEBUG.
 */

#include <nxu/console.h>
#include <nxu/sink.h>
#include <nxu/cpu.h>
#include <nxu/config.h>

static int
console_ok(void)
{
	if (!nxu_sink_ready)
		return 0;
	if (nxu_this_logical() != 0U)
		return 0;
	return 1;
}

void
nxu_console(const char *tag, const char *msg)
{
	if (!console_ok())
		return;
	nxu_sink_write("[NXU][");
	nxu_sink_write(tag);
	nxu_sink_write("] ");
	nxu_sink_write(msg);
	nxu_sink_nl();
}

void
nxu_console_discovered(nxu_u32 ncpus)
{
	/* String literals only. A pointer table would need load-time relocation
	 * and this image is a raw binary. */
	switch (ncpus) {
	case 1U:
		nxu_console("CPU", "One CPU was discovered");
		break;
	case 2U:
		nxu_console("CPU", "Two CPUs were discovered");
		break;
	case 3U:
		nxu_console("CPU", "Three CPUs were discovered");
		break;
	case 4U:
		nxu_console("CPU", "Four CPUs were discovered");
		break;
	case 5U:
		nxu_console("CPU", "Five CPUs were discovered");
		break;
	case 6U:
		nxu_console("CPU", "Six CPUs were discovered");
		break;
	case 7U:
		nxu_console("CPU", "Seven CPUs were discovered");
		break;
	case 8U:
		nxu_console("CPU", "Eight CPUs were discovered");
		break;
	default:
		nxu_console("CPU", "CPUs were discovered");
		break;
	}
}

void
nxu_console_at(const char *tag, const char *msg, nxu_u64 addr)
{
	if (!console_ok())
		return;
	nxu_sink_write("[NXU][");
	nxu_sink_write(tag);
	nxu_sink_write("] ");
	nxu_sink_write(msg);
	nxu_sink_write(" @ 0x");
	nxu_sink_hex_compact(addr);
	nxu_sink_nl();
}

void
nxu_debug(const char *tag, const char *msg)
{
#ifndef NXU_DEBUG
	(void)tag;
	(void)msg;
	return;
#else
	if (!console_ok())
		return;
	nxu_sink_write("[NXU][DBG][");
	nxu_sink_write(tag);
	nxu_sink_write("] ");
	nxu_sink_write(msg);
	nxu_sink_nl();
#endif
}

void
nxu_debug_u64(const char *key, nxu_u64 v)
{
#ifndef NXU_DEBUG
	(void)key;
	(void)v;
	return;
#else
	if (!console_ok())
		return;
	nxu_sink_write("    ");
	nxu_sink_write(key);
	nxu_sink_write("=0x");
	nxu_sink_hex_compact(v);
	nxu_sink_nl();
#endif
}
