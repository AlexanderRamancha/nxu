# foundation/signal/

## Why

An interrupt is not a callback slot. A signal has one owner and one destination CPU, or it is not enabled.

## Layer

Foundation. S10 controller corroboration. S13 targeted SGI proof.

## Ownership

Exclusive bind of the timer PPI and the IPI SGI. Redistributor association. INTID class handling for those TCB signals.

## Dependencies

Consumes GIC operations and the provisional present set. Produces a frozen present set and TCB-owned signals. Time and SMP consume that result.

## Direction

```
facts (candidate addresses) → owned MMIO → GIC ops → signal bind
```

## Files

| File | Owns | Consumes | Produces |
|---|---|---|---|
| `signal.c` | S10 and S13 policy | GIC ops, present CPUs | redistributor match, timer and IPI signals |

## Hardware

GICv3 distributor, redistributor, and CPU interface, through silicon. ITS and LPIs are not used.

## Forbidden

1-of-N delivery. Function-pointer handlers. Treating the GIC as the architecture.

## Invariants

Enabled implies one owner. Route is one CPU. Unbound INTID halts. Redistributor count must match the present set or the boot halts.

## Evidence

QEMU: interrupt controller initialization complete, then a timer deadline, then `Inter-processor signal was delivered`.

## History

Closure removed a "bring-up poke" IPI. CPU_ON starts secondaries. S13 remains as proof of a targeted SGI.

## Status

BUILT. TESTED on QEMU GICv3. GICv3 security model NOT CLOSED.
