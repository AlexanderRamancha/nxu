# foundation/space/

## Why

Unknown physical memory must become inaccessible once NXU owns translation. Mapping everything is not isolation.

## Layer

Foundation. S5 ownership. S6 translation policy.

## Ownership

Owner classes for accepted ranges. Which ranges are mapped, and with what permission. The decision to turn translation on.

## Dependencies

Consumes accepted facts and the image split. Calls silicon translate operations. After arm, the UART sink may bind.

## Direction

```
facts → ownership table → map policy → silicon MMU
```

## Files

| File | Owns | Consumes | Produces |
|---|---|---|---|
| `ownership.c` | physical owner classes | RAM, image, DTB, MMIO facts | ownership table |
| `mmu_policy.c` | map and enable policy | ownership, image splits | identity map of image and accepted MMIO |

## Hardware

TTBR, TCR, MAIR, SCTLR through silicon. This directory does not program registers itself except by calling those operations.

## Forbidden

Write and execute on the same mapping. Mapping all RAM. Mapping unknown memory. Default allow.

## Invariants

After arm, the MMU is on and unknown physical memory is inaccessible. Ranges are wrap-safe.

## Evidence

QEMU console: `NXU is enabling address translation`, then later S14, which rechecks `nxu_space.armed`.

## History

Closure C1 scopes "unknown inaccessible" to after space is armed. The bootstrap window is the image plus a bounded DTB probe.

## Status

BUILT. TESTED on QEMU. Cache and TLB completeness on secondary CPUs is NOT MEASURED on hardware.
