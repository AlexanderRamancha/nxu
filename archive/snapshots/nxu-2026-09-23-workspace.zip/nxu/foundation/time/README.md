# foundation/time/

## Why

Time is the ARM generic timer, not a UART bit-bang and not a tick.

## Layer

Foundation. S11.

## Ownership

One TCB-owned one-shot deadline on the boot CPU. The PPI number comes from the ISA for `control_el` (EL1 physical 30, EL2 physical 26) and must not contradict facts.

## Dependencies

Consumes observed CNTFRQ, the signal bind, and silicon timer operations. Produces a visible `timer_fired` store.

## Direction

```
facts + ISA PPI → silicon timer → PPI IRQ → S11 observes the store
```

## Files

| File | Owns | Consumes | Produces |
|---|---|---|---|
| `time.c` | deadline policy and the wait | frequency, PPI, GIC enable | observed fire or halt |

## Hardware

CNTPCT, CNTFRQ, CNTP or CNTHP.

## Forbidden

HZ. Jiffies. UART as a clock. A board constant for the PPI.

## Invariants

The wait must observe the IRQ store. The flag is volatile. A compiler barrier and a DSB keep the store visible. Frequency zero fails the freeze check.

## Evidence

QEMU: `The timer deadline was observed` before SMP and S14. An earlier failure mode was a hoisted non-volatile load while the IRQ had already been recorded.

## History

Closure X4/C4 replaced "typically PPI 30" with the ISA PPI for the control EL.

## Status

BUILT. TESTED on QEMU at EL1 (PPI 30). EL2 timer path BUILT, NOT EXECUTED.
