# image/

## Why

The loaded image has a footprint. That footprint is computed from the program counter, not from a board load address.

## Layer

Image. Layout and descriptor. Not policy.

## Ownership

Linker layout. ARM64 header at offset 0. RX / read-only / RW split. Runtime `nxu_image`.

## Dependencies

Foundation intake reads the symbols. The linker script is an input to every board build.

## Direction

```
objects → nxu.ld → ELF and raw image → intake footprint
```

## Files

| File | Owns | Consumes | Produces |
|---|---|---|---|
| `nxu.ld` | section layout | TCB objects | image linked at VA 0 |
| `image.c` | footprint helper | linker symbols, intake PC | `nxu_image`, `nxu_pa_of` |

## Hardware

None.

## Forbidden

A compiled load address. Board RAM size as image size.

## Invariants

VA 0. PC-relative size. Because the raw image is not relocated, absolute pointer tables and jump tables are not safe. The Makefile passes `-fno-jump-tables`.

## Evidence

QEMU loaded the image at an observed PA (`0x40200000` in one debug run). The header check accepts `build-qemu/nxu.img` and `build-fvp/nxu.img`.

## History

The header exists so firmware can branch to the first instruction. It is not a signature.

## Status

BUILT. Header TESTED. Both board images BUILT.
