# include/nxu/

## Why

Public types and prototypes have one include root. Per-file relative includes drift into private copies of the same contract.

## Layer

Interfaces for the TCB. Not a subsystem and not a policy owner.

## Ownership

Type layouts and function declarations: context, CPU, facts, space, signals, time, observe.

## Dependencies

Included as `<nxu/name.h>` via `-Iinclude`. Silicon headers are not in this directory.

## Direction

```
headers → included by foundation and, where an operation needs a type, by silicon
```

## Files

| File | Owns |
|---|---|
| `types.h` | integer and pointer aliases |
| `config.h` | compile-time bounds, not topology truth |
| `context.h` | `nxu_cpu_exec_context` |
| `cpu.h` | CPU slot and lifecycle prototypes |
| `facts.h` `fdt.h` `board.h` | fact and candidate shapes |
| `space.h` | ownership and map policy prototypes |
| `signal.h` `time.h` | signal and timer prototypes |
| `exception.h` | S7 and C entry prototypes |
| `intake.h` `s0.h` `image.h` | residue, S0, footprint |
| `chronicle.h` `bbox.h` `console.h` `sink.h` `fail.h` `halt.h` | observe interfaces |
| `range.h` | wrap-safe range helpers |

## Hardware

None.

## Forbidden

`exec.h` (removed; the type stayed `nxu_cpu_exec_context`). Board addresses. Inline policy that bypasses the `.c` file which owns it.

## Invariants

`NXU_CPU_BOUND` is a capacity, not the number of CPUs present. `NXU_DTB_PROBE_CAP` is not platform RAM size.

## Evidence

`probe/check.sh` rejects a leftover `include/nxu/exec.h`.

## History

The type lived briefly behind `exec.h` during the structural correction and was split into `context.h` and `exception.h` without a rename.

## Status

BUILT. Matches the current sources.
