#ifndef NXU_CONSOLE_H
#define NXU_CONSOLE_H

/*
 * NXU MAP
 *
 *                    FOUNDATION OBSERVE
 *                           │
 *                           ▼
 *                        CONSOLE
 *                           │
 *                           ▼
 *                     UART SINK
 *
 * Layer: foundation observe
 * Owns: compact live text after UART is owned and mapped
 * Consumes: tag, sentence, optional address; debug key/value
 * Produces: [NXU][TAG] lines on the optional sink
 * Hardware: PL011 via silicon, address as parameter
 * Forbidden: print before ownership; IRQ print; quotes in output
 * Invariant: printing is not architecture; halt does not require it
 */

#include <nxu/types.h>

void nxu_console(const char *tag, const char *msg);
void nxu_console_discovered(nxu_u32 ncpus);
void nxu_console_at(const char *tag, const char *msg, nxu_u64 addr);
void nxu_debug(const char *tag, const char *msg);
void nxu_debug_u64(const char *key, nxu_u64 v);

#endif
