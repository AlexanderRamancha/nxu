# probe/

## Why

Validation is host-side. If probe logic is compiled into the image, the instrument becomes the architecture.

## Layer

Host. Not TCB.

## Ownership

Static checks, QEMU launch, FVP launch, negative cases, captured logs.

## Dependencies

Reads build artifacts. Does not export symbols to foundation.

## Direction

```
make → artifact → probe launcher → model → evidence log
```

## Files

| Path | Owns | Consumes | Produces |
|---|---|---|---|
| `check.sh` | source and header rules | tree, images | pass or fail |
| `qemu/run.sh` | QEMU virt launch | `nxu.img` | console and `qemu-virt.log` |
| `fvp/run.sh` | FVP launch | `nxu.img` at DRAM, not VA 0 | status lines and optional log |
| `cases/` | negative tests | an image | must not freeze |
| `evidence/` | captured logs | launches | the record of what ran |
| `host/` | local zig and QEMU binaries | none | tools, if present |

## Hardware

The host's QEMU or FVP process. Not described as NXU hardware.

## Forbidden

Hard-coded developer home directories. Weakening the S14 check. Claiming PASS when a model did not run. Treating QEMU output as architectural authority.

## Invariants

`make qemu` requires `[NXU][S14]` and rejects `[NXU][FAIL]`. `make fvp` builds. `make fvp-run` executes only when a model is discovered. QEMU prefers a repository-local binary that actually runs `--version`, otherwise PATH.

## Evidence

Latest run: QEMU and debug EXECUTED to S14. FVP NOT EXECUTED (binary absent).

## History

A file redirect hid or dropped serial on some hosts. Capture now uses a PTY and flushes as bytes arrive. FVP loads the raw image at the Base DRAM base and sets RVBARADDR there. Address 0 is BL1 and is not used.

## Status

QEMU path TESTED here. FVP path BUILT, NOT EXECUTED here.
