# probe/fvp/

## Why

FVP is a second instrument. Address 0 on Base is BL1 Trusted ROM. An ELF linked at VA 0 must not be loaded there.

## Layer

Host probe.

## Ownership

Finding the model, placing `build-fvp/nxu.img` at the DRAM base, and setting the boot CPU reset vector to that address.

## Dependencies

Discovery order: `$FVP`, `$FVP_BIN`, `probe/host/fvp/`, then PATH. No home directory is written into the script. The load address matches `board/fvp-base` RAM base (`0x80000000`). It is not a link address.

## Direction

```
nxu.img --data @ DRAM → RVBARADDR → evidence or NOT EXECUTED
```

## Files

| File | Owns | Consumes | Produces |
|---|---|---|---|
| `run.sh` | discovery, DRAM load, reset vector, status lines | FVP binary, raw image | executed evidence or an explicit not-executed report |

## Hardware

FVP Base, when the binary exists. Not authority.

## Forbidden

`-a` of the VA-0 ELF (that write targets BL1). Claiming PASS when the model was absent. A second NXU kernel for FVP. A board address in the linker script.

## Invariants

The report distinguishes binary available, process started, image loaded, boot observed, and S14 observed. Reset is DRAM, not 0.

## Evidence

The launcher was changed because a VA-0 `-a` load is the BL1 restriction. Execution still requires a model binary. Absence is NOT EXECUTED, not PASS.

## History

An earlier launcher passed the raw image to `-a`, which Fast Models reject. The next launcher passed the ELF, whose program headers are VA 0. That is BL1. The image stays linked at 0 because it is PC-relative; only the probe chooses the physical load.

## Status

Launcher BUILT. Execution follows whatever this host's model does.
