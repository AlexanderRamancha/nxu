#!/bin/sh
# FVP probe. Address 0 is BL1 Trusted ROM.
# make builds build-fvp/nxu.fvp.elf linked at the FVP Base DRAM base.
# FVP -a uses that ELF. UART0 is raw on this process, not a telnet port.
# Resolution: $FVP, $FVP_BIN, repository-local, PATH. No home-directory path.
set -e
root=$(CDPATH= cd -- "$(dirname "$0")/../.." && pwd)
elf="${NXU_FVP_ELF:-$root/build-fvp/nxu.elf}"
img="${NXU_FVP_IMG:-$root/build-fvp/nxu.img}"
loadelf="${NXU_FVP_LOADELF:-$root/build-fvp/nxu.fvp.elf}"
out="${NXU_FVP_LOG:-$root/probe/evidence/fvp-base.log}"
uart="${NXU_FVP_UART:-$root/probe/evidence/fvp-uart.log}"
# Must match board/fvp-base RAM base. Not a link address. Not architecture.
load="${NXU_FVP_LOAD:-0x80000000}"

report_absent() {
	echo "FVP: NOT EXECUTED"
	echo "FVP binary available: no"
	echo "FVP process started: no"
	echo "NXU image loaded: no"
	echo "NXU boot observed: no"
	echo "S14 observed: no"
	echo "reason: $1"
	echo "artifact: $img"
	echo "load: $load"
}

if [ ! -f "$elf" ]; then
	echo "FVP capture FAIL: missing ELF $elf" >&2
	exit 1
fi

find_fvp() {
	if [ -n "${FVP:-}" ] && [ -x "$FVP" ]; then
		printf '%s\n' "$FVP"
		return 0
	fi
	if [ -n "${FVP_BIN:-}" ] && [ -x "$FVP_BIN" ]; then
		printf '%s\n' "$FVP_BIN"
		return 0
	fi
	for c in \
		"$root/probe/host/fvp/FVP_Base_RevC-2xAEMvA" \
		"$root/probe/host/fvp/FVP_Base_AEMvA" \
		"$root/probe/host/fvp/FVP_Base_AEMv8A" \
		FVP_Base_RevC-2xAEMvA \
		FVP_Base_AEMvA \
		FVP_Base_AEMv8A
	do
		if [ -x "$c" ]; then
			printf '%s\n' "$c"
			return 0
		fi
		w=$(command -v "$c" 2>/dev/null || true)
		if [ -n "$w" ] && [ -x "$w" ]; then
			printf '%s\n' "$w"
			return 0
		fi
	done
	return 1
}

if ! fvp=$(find_fvp); then
	report_absent "FVP executable not found via FVP, FVP_BIN, repository-local probe/host/fvp, or PATH"
	exit 0
fi

if [ ! -f "$loadelf" ]; then
	echo "FVP capture FAIL: missing DRAM ELF $loadelf (build with make fvp-run)" >&2
	exit 1
fi

python3 - "$loadelf" "$load" <<'PY'
import struct, sys
path, load_s = sys.argv[1:3]
load = int(load_s, 0)
b = open(path, "rb").read(64)
if b[:4] != b"\x7fELF":
    raise SystemExit("FVP ELF: not an ELF")
entry = struct.unpack_from("<Q", b, 24)[0]
print("FVP ELF entry: 0x%x" % entry)
if entry != load:
    raise SystemExit(
        "FVP ELF entry 0x%x is not DRAM 0x%x; refusing to load BL1 at 0" % (entry, load)
    )
PY

mkdir -p "$(dirname "$out")"
: > "$uart"
echo "FVP binary available: yes"
echo "FVP: $fvp"
echo "image: $img"
echo "load ELF: $loadelf"
echo "load: $load (DRAM; not BL1 at 0x0)"
echo "uart: $uart"

python3 - "$fvp" "$loadelf" "$img" "$load" "$out" "$uart" <<'PY'
import os, sys, pty, select, time, subprocess
fvp, elf, img, load, outp, uart = sys.argv[1:7]
# Telnet is why the run only printed "Listening for serial connection".
# mode=raw connects UART0 to this process. pctl.startup releases cpu0;
# without it the terminals come up and the core stays in reset.
cmd = [
    fvp,
    "-C", "bp.secure_memory=0",
    "-C", "bp.refcounter.non_arch_start_at_default=1",
    "-C", "pctl.startup=0.0.0.0",
    "-C", "cluster0.has_el3=0",
    "-C", "cluster0.has_el2=1",
    "-C", "cluster0.NUM_CORES=1",
    "-C", "cluster0.cpu0.RVBARADDR=%s" % load,
    "-C", "bp.pl011_uart0.untimed_fifos=1",
    "-C", "bp.pl011_uart0.unbuffered_output=1",
    "-C", "bp.pl011_uart0.out_file=%s" % uart,
    "-C", "bp.terminal_0.mode=raw",
    "-C", "bp.terminal_1.mode=raw",
    "-C", "bp.terminal_2.mode=raw",
    "-C", "bp.terminal_3.mode=raw",
    "-C", "bp.terminal_0.start_telnet=false",
    "-C", "bp.terminal_1.start_telnet=false",
    "-C", "bp.terminal_2.start_telnet=false",
    "-C", "bp.terminal_3.start_telnet=false",
    "-C", "bp.vis.disable_visualisation=1",
    "-a", "cluster0.cpu0=%s" % elf,
]
if "2x" in os.path.basename(fvp) or "RevC" in os.path.basename(fvp):
    cmd[1:1] = ["-C", "cluster1.NUM_CORES=0"]
print("FVP command:")
for i in range(0, len(cmd), 2):
    print(" ", " ".join(cmd[i:i+2]))
sys.stdout.flush()
master, slave = pty.openpty()
proc = subprocess.Popen(cmd, stdin=slave, stdout=slave, stderr=slave, close_fds=True)
os.close(slave)
deadline = time.time() + 45
log = open(outp, "wb")
seen = b""
uart_pos = 0
rc = 1

def drain_uart():
    global uart_pos, seen
    try:
        f = open(uart, "rb")
    except OSError:
        return
    try:
        f.seek(uart_pos)
        data = f.read()
        uart_pos = f.tell()
    finally:
        f.close()
    if not data:
        return
    log.write(data)
    log.flush()
    sys.stdout.buffer.write(data)
    sys.stdout.buffer.flush()
    seen += data

try:
    while True:
        if time.time() > deadline:
            proc.terminate()
            break
        ready, _, _ = select.select([master], [], [], 0.2)
        drain_uart()
        if b"[NXU][S14]" in seen:
            time.sleep(0.3)
            drain_uart()
            proc.terminate()
            break
        if master in ready:
            try:
                data = os.read(master, 4096)
            except OSError:
                data = b""
            if not data:
                if proc.poll() is not None:
                    break
                continue
            log.write(data)
            log.flush()
            sys.stdout.buffer.write(data)
            sys.stdout.buffer.flush()
            seen += data
            if b"[NXU][S14]" in seen:
                time.sleep(0.3)
                drain_uart()
                proc.terminate()
                break
        elif proc.poll() is not None:
            drain_uart()
            break
finally:
    drain_uart()
    log.close()
    try:
        rc = proc.wait(timeout=3)
    except subprocess.TimeoutExpired:
        proc.kill()
        rc = proc.wait(timeout=2)
print("FVP process started: yes (rc=%s)" % rc)
print("FVP load address: %s" % load)
PY

if [ ! -s "$out" ] && [ ! -s "$uart" ]; then
	echo "NXU image loaded: unknown"
	echo "NXU boot observed: no"
	echo "S14 observed: no"
	echo "FVP capture FAIL: empty evidence log" >&2
	exit 1
fi

if grep -q 'file format not recognized\|unknown parameter\|Failed to load\|unrecognized parameter' "$out"; then
	echo "NXU image loaded: no"
	echo "NXU boot observed: no"
	echo "S14 observed: no"
	echo "FVP capture FAIL: model rejected the load or a parameter" >&2
	tail -n 40 "$out" >&2
	exit 1
fi

if grep -q '\[NXU\]\[BOOT\]\|\[NXU\]\[FACT\]\|\[NXU\]\[S14\]' "$out" "$uart"; then
	echo "NXU image loaded: yes"
	echo "NXU boot observed: yes"
else
	echo "NXU image loaded: not observed"
	echo "NXU boot observed: no"
	echo "S14 observed: no"
	echo "FVP capture FAIL: model ran but NXU console was not observed" >&2
	echo "---- model ----" >&2
	tail -n 40 "$out" >&2
	echo "---- uart ----" >&2
	tail -n 40 "$uart" >&2
	exit 1
fi

if ! grep -q '\[NXU\]\[S14\]' "$out" "$uart"; then
	echo "S14 observed: no"
	echo "FVP capture FAIL: no S14 freeze record" >&2
	tail -n 60 "$uart" >&2
	tail -n 40 "$out" >&2
	exit 1
fi
if grep -q '\[NXU\]\[FAIL\]' "$out" "$uart"; then
	echo "S14 observed: yes"
	echo "FVP capture FAIL: FAIL record present" >&2
	grep '\[NXU\]\[FAIL\]' "$out" "$uart" >&2
	exit 1
fi
echo "S14 observed: yes"
echo "FVP capture ok: S14 freeze observed"
echo "log: $out"
echo "uart log: $uart"
