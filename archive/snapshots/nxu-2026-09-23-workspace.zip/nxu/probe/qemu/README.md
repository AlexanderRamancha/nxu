# probe/qemu/

## Why

`make qemu` must behave like a direct QEMU run: show the console, keep the log, and still require S14.

## Layer

Host probe.

## Ownership

Locating `qemu-system-aarch64` and launching virt GICv3.

## Dependencies

`build-qemu/nxu.img` unless `NXU_IMG` is set. Discovery order: `NXU_QEMU` if it runs, repository-local `probe/host/qemu/bin/qemu-system-aarch64` if it runs, else PATH.

## Direction

```
image → PTY → qemu-system-aarch64 -kernel nxu.img → evidence
```

## Files

| File | Owns | Consumes | Produces |
|---|---|---|---|
| `run.sh` | the launch and the S14 check | image, QEMU binary | live console and log |

## Hardware

QEMU `virt`, GICv3, cortex-a57, 128M. Instrument only.

## Forbidden

Hard-coded `/workspace` paths. Dropping the S14 check. Hiding NXU lines.

## Invariants

Empty log is failure. `[NXU][FAIL]` is failure. `[NXU][S14]` is required. A PTY is used so serial is not lost when stdout is not a terminal.

## Evidence

`QEMU capture ok: S14 freeze observed (smp=4)`.

## History

`script(1)` without a terminal recorded "not executed" and an empty body. The PTY is the replacement.

## Status

TESTED.
