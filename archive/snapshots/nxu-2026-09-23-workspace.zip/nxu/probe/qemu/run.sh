#!/bin/sh
# QEMU virt probe. Board knowledge lives here, not in foundation.
# Requires live [NXU][S14] evidence. Do not weaken this check.
# Direct interactive QEMU writes a terminal. This launcher gives QEMU a PTY
# and flushes every write so a timeout cannot drop the freeze line.
set -e
root=$(CDPATH= cd -- "$(dirname "$0")/../.." && pwd)
img="${NXU_IMG:-$root/build-qemu/nxu.img}"
out="${NXU_LOG:-$root/probe/evidence/qemu-virt.log}"
smp="${NXU_SMP:-4}"

if [ ! -f "$img" ]; then
	echo "QEMU capture FAIL: missing image $img" >&2
	exit 1
fi

qemu_runs() {
	"$1" --version >/dev/null 2>&1
}

pick_qemu() {
	if [ -n "${NXU_QEMU:-}" ] && [ -x "$NXU_QEMU" ] && qemu_runs "$NXU_QEMU"; then
		printf '%s\n' "$NXU_QEMU"
		return 0
	fi
	local_q="$root/probe/host/qemu/bin/qemu-system-aarch64"
	if [ -x "$local_q" ] && qemu_runs "$local_q"; then
		printf '%s\n' "$local_q"
		return 0
	fi
	path_q=$(command -v qemu-system-aarch64 2>/dev/null || true)
	if [ -n "$path_q" ] && qemu_runs "$path_q"; then
		printf '%s\n' "$path_q"
		return 0
	fi
	return 1
}

if ! qemu=$(pick_qemu); then
	echo "QEMU capture FAIL: qemu-system-aarch64 not usable" >&2
	echo "tried NXU_QEMU, repository-local probe/host/qemu, then PATH" >&2
	exit 1
fi

mkdir -p "$(dirname "$out")"
echo "QEMU: $qemu"
echo "image: $img"

# PTY, not a plain pipe: some QEMU builds emit serial only when stdout is a
# terminal, and a timeout can drop a block-buffered pipe. Flush every read.
python3 - "$qemu" "$img" "$smp" "$out" <<'PY'
import os, sys, pty, select, time, subprocess
qemu, img, smp, outp = sys.argv[1:5]
cmd = [
    qemu, "-machine", "virt,gic-version=3", "-cpu", "cortex-a57",
    "-smp", smp, "-m", "128M", "-nographic", "-kernel", img,
]
master, slave = pty.openpty()
proc = subprocess.Popen(cmd, stdin=slave, stdout=slave, stderr=slave, close_fds=True)
os.close(slave)
deadline = time.time() + 20
log = open(outp, "wb")
seen = b""
try:
    while True:
        if time.time() > deadline:
            proc.terminate()
            break
        ready, _, _ = select.select([master], [], [], 0.2)
        if master in ready:
            try:
                data = os.read(master, 4096)
            except OSError:
                data = b""
            if not data:
                if proc.poll() is not None:
                    break
                continue
            log.write(data)
            log.flush()
            sys.stdout.buffer.write(data)
            sys.stdout.buffer.flush()
            seen += data
            tail = seen.split(b"[NXU][S14]", 1)
            if len(tail) == 2 and b"\n" in tail[1]:
                time.sleep(0.3)
                proc.terminate()
                break
        elif proc.poll() is not None:
            break
finally:
    log.close()
    try:
        proc.wait(timeout=2)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(timeout=2)
PY

if [ ! -s "$out" ]; then
	echo "QEMU capture FAIL: empty evidence log" >&2
	exit 1
fi

if ! grep -q '\[NXU\]\[S14\]' "$out"; then
	echo "QEMU capture FAIL: no S14 freeze record" >&2
	tail -n 80 "$out" >&2
	exit 1
fi
if grep -q '\[NXU\]\[FAIL\]' "$out"; then
	echo "QEMU capture FAIL: FAIL record present" >&2
	grep '\[NXU\]\[FAIL\]' "$out" >&2
	exit 1
fi
echo "QEMU capture ok: S14 freeze observed (smp=$smp)"
echo "log: $out"
