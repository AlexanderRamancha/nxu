# Chronology

History is evidence. It is not architectural authority. `research/` is not linked.

| ID | Date | Record |
|---|---|---|
| H1 | historical tree | [Historical NXU tree](H1-historical-nxu-tree.md) |
| H2 | 2026-09-22 | [Genesis v1](H2-genesis-v1.md) |
| H3 | 2026-09-22 | [Genesis v2](H3-genesis-v2.md) |
| H4 | 2026-09-22 | [Genesis v2 closure](H4-genesis-v2-closure.md) |
| H5 | 2026-09-22 | [Genesis v2 accepted](H5-genesis-v2-accepted.md) |
| H6 | 2026-09-22 | [S1–S14 foundation](H6-s1-s14-foundation.md) |
| H7 | 2026-09-22 | [Structural correction](H7-structural-correction.md) |
| H8 | 2026-09-22 | [S14 observe](H8-s14-observe.md) |
| H9 | 2026-09-22 | [Reconstruction](H9-reconstruction.md) |
| H10 | 2026-09-23 | [Origin reading and closure remainder](H10-origin-and-closure.md) |

H1–H8 are the short contemporaneous notes. H9 is the first long reading of those notes against the sources. H10 corrects H9 where it said closure stopped at invariant 25, and it records a reading of the public origin tree plus the clean QEMU/FVP suite from this pass. Where a detail was not in those sources, the reconstruction says so.
