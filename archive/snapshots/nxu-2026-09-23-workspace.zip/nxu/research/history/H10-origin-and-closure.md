# H10 — Origin reading, closure remainder, and this pass

**Status of this file:** research. Not linked. Not authority.

**What it is.** The long reading that H9 could not finish. H9 reconstructed S0–S14 from the notes already in this tree. It also said, wrongly, that closure's invariant list stopped at 25. Closure section C continues through 28. H9's opening also said the public origin tree had not been re-read. This file is that reading, plus the mechanism-by-mechanism map from Genesis onto the current sources, plus the clean-suite measurement from this pass.

**Sources actually opened.**

- This tree: `genesis.md`, `genesis v2.md` (byte-identical; `diff` was empty), `GENESIS_V2_CLOSURE.md`, H1–H9, the current `.c` / `.S` / headers, `Makefile`, `probe/qemu/run.sh`, `probe/fvp/run.sh`, and the evidence logs after `make clean`.
- Public origin: `https://github.com/AlexanderRamancha/nxu` at `main`, commit `fb02f5f` ("Rewrite README as NXU origin page", 2026-09-22). The Git tree API returned `truncated: false` and 48 blobs. Files quoted below were fetched from `raw.githubusercontent.com` in this pass. They were not copied into the TCB.

**Rule.** A sentence that is not in those sources is not written here. If the origin file was not opened, the detail is `[HISTORICAL DETAIL NOT RECOVERED]`. QEMU success is not hardware validation. FVP was not executed.

Labels keep the meanings in H9 section 1: BUILT, TESTED, OBSERVED, MEASURED, EXECUTED, NOT EXECUTED, NOT VERIFIED, ASSUMED, OPEN, REJECTED.

## 1. What this pass measured

The instruction was to repair execution, not to redesign S0–S14. The image that already existed reached S14 under a direct QEMU line. The question was whether `make qemu` and `make fvp-run` told the truth about that.

### 1.1 Three launch paths

A. Direct QEMU. The known-good command is `qemu-system-aarch64 -machine virt,gic-version=3 -cpu cortex-a57 -smp 4 -m 128M -nographic -kernel build-qemu/nxu.img`. It is a validation instrument. It is not a board fact and not a foundation stage.

B. `probe/qemu/run.sh`. It resolves the emulator as `$NXU_QEMU` if that binary runs `--version`, else `probe/host/qemu/bin/qemu-system-aarch64` if that runs `--version`, else `qemu-system-aarch64` on `PATH`. It does not embed a workspace path. It gives QEMU a PTY, flushes every read into `probe/evidence/qemu-virt.log` and to the parent, and exits only after a newline following `[NXU][S14]`, or after 20 seconds, or when the process dies. Empty log is failure. `[NXU][FAIL]` is failure. Missing S14 is failure. The check was not removed.

C. `make qemu`. The target depends on `build-qemu/nxu.img`, runs `probe/check.sh`, then `probe/qemu/run.sh`. `make` itself only builds the QEMU image. `make debug` rebuilds with `-DNXU_DEBUG=1` into `build-debug/` and points the same launcher at that image and at `probe/evidence/qemu-debug.log`.

The earlier failure mode, recorded in H8 and H9, was a capture that could drop the freeze line: a pipe, or `script(1)` on a host with no terminal, so the S14 check correctly reported "no S14 freeze record" against an empty or clipped log. That was a probe bug. It was not an S0–S14 bug. The PTY launcher is the repair. This pass did not weaken the check to make the script pass.

### 1.2 Clean suite, this environment

Command, in `/workspace/nxu`, after the invariant correction in H9 and before this file existed:

```
make clean
make
make qemu
make debug
make fvp
make fvp-run
```

Result: the shell ended `SUITE_EXIT:0`.

`make` compiled the TCB allow-list with repository-local `probe/host/zig/zig cc -target aarch64-freestanding-none`, `-Iinclude -I.`, `-MMD -MP`, `-fno-jump-tables`, and produced `build-qemu/nxu.img`. `probe/check.sh` then reported source rules ok and an ARM64 header of 28672 bytes on the QEMU, FVP, and debug images.

`make qemu` EXECUTED. The console, also stored in `probe/evidence/qemu-virt.log`, was:

```
[NXU][BOOT] NXU is loading the kernel image
[NXU][FACT] NXU is validating boot information
[NXU][FACT] Device tree validation is complete
[NXU][FACT] Boot information has been accepted
[NXU][MMU] NXU is enabling address translation
[NXU][EXC] Exception handling is installed
[NXU][CPU] CPU discovery is initializing
[NXU][CPU] Four CPUs were discovered
[NXU][CPU] CPU initialization is complete
[NXU][GIC] NXU is initializing interrupt control
[NXU][GIC] Interrupt controller initialization is complete
[NXU][TIME] NXU is configuring the timer
[NXU][TIME] Timer initialization is complete
[NXU][TIME] The timer deadline was observed
[NXU][SMP] NXU is bringing CPUs online
[NXU][SMP] CPU bring-up is complete
[NXU][SMP] Inter-processor signal was delivered
[NXU][S14] NXU foundation is frozen
```

Launcher line: `QEMU capture ok: S14 freeze observed (smp=4)`. No `[NXU][FAIL]`. Timer event: OBSERVED. CPUs online: OBSERVED as the bring-up sentence after discovery of four. IPI: OBSERVED as the inter-processor sentence. S14: OBSERVED. This is QEMU. It is not a real-hardware result.

`make debug` EXECUTED the same freeze with compact debug values. From `probe/evidence/qemu-debug.log` this pass: `pc=0x40200000`, `dtb=0x44000000`, `ram=0x40000000`, `ttbr=0x40208000`, `el=0x1`, `vbar=0x40201800`, `present=0x4`, `boot_mpidr=0x0`, `gicd=0x8000000`, `gicr=0x80a0000`, `iidr=0x43b`, `freq=0x3b9aca0`, `ppi=0x1e`, `spins=0x3226dd`, CPU_ON for mpidr 1, 2, and 3, then online with `state=0x5`, IPI `target=0x1`, then S14. `0x5` is `NXU_CPU_ONLINE` in `include/nxu/config.h`. `0x1e` is PPI 30, the EL1 physical timer, which matches closure C4 for `control_el` 1. `freq=0x3b9aca0` is 62500000 Hz. MEASURED from that log, not assumed. Addresses are debug-only and compact. The normal log does not print them.

`make fvp` BUILT `build-fvp/nxu.elf` and `build-fvp/nxu.img` from the same TCB core plus `board/fvp-base/facts.c`. It did not execute.

`make fvp-run` printed:

```
FVP: NOT EXECUTED
FVP binary available: no
FVP process started: no
NXU image loaded: no
NXU boot observed: no
S14 observed: no
reason: FVP executable not found via FVP, FVP_BIN, repository-local probe/host/fvp, or PATH
```

A filesystem search for `FVP_Base*` found nothing. `$HOME` on this machine is `/root`. `$HOME/arm-fvp/...` is not present here. The launcher does not hard-code that path. Absence is NOT EXECUTED. It is not PASS. It is not an architectural failure of S0–S14.

`PATH` has no `qemu-system-aarch64`. The repository-local binary reported `xPack QEMU emulator version 8.2.2`. That is the binary `make qemu` used.

### 1.3 What was not re-run

`probe/cases/neg-header.sh` was not repeated. H6 records an earlier corrupted-magic run that did not freeze. That earlier result is not a new measurement. Mark the negative case NOT RE-RUN this pass.

Real ARM64 silicon: NOT EXECUTED. `board/soc/facts.c` keeps `present` clear so a boot that selected it would fail closed. It was not selected.

## 2. The public origin tree, as read

The GitHub description is: "NXU — A privacy-first mobile OS for ARM64, engineered from first principles around simplicity, isolation, and explicit authority."

The README at `fb02f5f` says, in its own words, that the repository is "the beginning", "the first public snapshot", "early ARM64 bring-up", and "not the kernel we are building now, and it is not the architecture we hold ourselves to." It says the work continues off that tree, and that a reader of that code is looking at "how it started — not at where it is." It says to expect "retired names and claims we took back" and that "the living design is not published here yet."

The same README states the principle that survived: "Unix asked who you are, then what you may touch. NXU asks what physically exists, and what is already wired. No root. No `/dev/uart`. No chmod later. Privacy is not a setting." And: "Hardware first. Then an experiment that could fail. QEMU is the laboratory. ARM is the law. The phone is the destination." And: "Users should own their systems. Systems should not own their users."

It also claims laboratory demos: "untrusted boot, default-deny occupant maps, MMU-denied peer RAM, and a timer path that does not map the GIC into the occupant." Those phrases are the README's claim about a laboratory, not a claim this file can verify from the blobs that are actually linked. The linked Makefile, quoted below, does not build an MMU, does not build `kernel/mm/memory.c`, and does not build `kernel/dtb/dtb.c`. Whether an unpublished laboratory produced those demos is `[HISTORICAL DETAIL NOT RECOVERED]`. The current TCB does not contain an "occupant". That word is not a foundation type.

The same-day date (2026-09-22) appears on the README rewrite and on H2–H9. Whether those were one conversation is `[HISTORICAL DETAIL NOT RECOVERED]`. The shared date is the evidence. It is not a proof they were one edit.

### 2.1 Commit subjects recovered from the commits page

The page listed 26 commits. Subjects, oldest first as grouped on that page:

- 2026-08-16 `4079b6e` Initial Foundation for NXU
- 2026-08-18 `626abf4` add project README
- 2026-08-25 `c451a80` Add NXU core types and MMIO abstraction
- 2026-08-25 `fec04cc` Implement ARM64 CPU topology and SMP startup
- 2026-08-25 `64d5a26` Implement PSCI CPU startup support
- 2026-08-25 `c6341ae` Add ARM64 platform layer
- 2026-08-25 `2ff7cf6` Implement ARM64 GICV3 Interrupt Controller
- 2026-08-25 `6729b34` Implement ARM64 IRQ exception handling
- 2026-08-25 `a5672e5` Implement NXU interrupt manager
- 2026-08-25 `1716c9c` Add NXU interrupt regression tests
- 2026-08-25 `44bfeb4` Integrate interrupt subsystem initialization
- 2026-08-25 `635a090` Improve ARM64 build and debug tooling
- 2026-08-25 `307356d` Add VS Code development configuration
- 2026-09-03 `427b17e` timer: add minimal timer interface
- 2026-09-03 `269d952` timer: implement minimal ARM generic timer
- 2026-09-03 `9880fe9` Add Generic Timer source to build
- 2026-09-03 `4059300` Initialize Generic Timer during kernel startup
- 2026-09-06 `44b2227` Log: add NXU logging subsystem
- 2026-09-06 `490dc2e` CPU: implement topology and SMP startup
- 2026-09-06 `21b120d` Implement NXU interrupt subsystem
- 2026-09-06 `311d5fc` Implement NXU early physical memory map
- 2026-09-06 `bc78bd9` Implement NXU platform hardware description
- 2026-09-06 `225b36e` Implement NXU early DTB validation
- 2026-09-06 `2224a97` Init: integrate NXU kernel startup
- 2026-09-06 `e7e39cf` Docs: update NXU project progress
- 2026-09-22 `fb02f5f` Rewrite README as NXU origin page

Commit bodies were not fetched. `[HISTORICAL DETAIL NOT RECOVERED]` for anything that lived only in a commit message body or in a force-push that the page no longer shows.

### 2.2 Shape of that tree

Top-level blobs and directories from the recursive tree:

```
arch/arm64/boot/          start.S, link.ld
arch/arm64/exception/     entry.S, exceptions.c
arch/arm64/gic/           gic.c, gic.h, gic_interrupt.c, gic_reg.h
arch/arm64/include/       exceptions.h, regs.h
arch/arm64/platform/      platform.c, platform.h
arch/arm64/psci/          psci.c
drivers/uart/             pl011.c, pl011.h
kernel/boot/              boot.c
kernel/cpu/               cpu.c
kernel/dtb/               dtb.c
kernel/include/nxu/       boot, cpu, dtb, interrupt, interrupt_backend,
                          interrupt_manager, log, memory, mmio, psci, timer, types
kernel/init/              main.c, interrupt_test.c
kernel/interrupt/         interrupt_backend.c, interrupt_manager.c
kernel/mm/                memory.c
kernel/                   mmio.c, timer.c
log/                      log.c, log_cpu.c, log_event.c, log_policy.c, log_storage.c
Makefile
README.md
.vscode/c_cpp_properties.json
```

There is no `foundation/`, no `silicon/`, no `board/`, no `research/`, no `probe/`. Genesis later refused to migrate this shape. The current tree's `probe/check.sh` fails if `kernel/`, `arch/`, or `drivers/` exist. That check is the fence. It is not a claim that those words are illegal English. It is a claim that those directories must not return as the architecture.

### 2.3 What the origin Makefile actually links

`Makefile` sets `CC := aarch64-linux-gnu-gcc` and `LD := aarch64-linux-gnu-ld`. One `BUILD_DIR := build`. The C list is:

```
arch/arm64/exception/exceptions.c
kernel/init/main.c
kernel/mmio.c
kernel/timer.c
drivers/uart/pl011.c
arch/arm64/gic/gic.c
kernel/interrupt/interrupt_manager.c
arch/arm64/gic/gic_interrupt.c
kernel/interrupt/interrupt_backend.c
arch/arm64/psci/psci.c
kernel/cpu/cpu.c
arch/arm64/platform/platform.c
kernel/init/interrupt_test.c
```

Not in that list, though the files exist: `kernel/dtb/dtb.c`, `kernel/mm/memory.c`, `kernel/boot/boot.c`, and every `log/*.c`. `platform.c` calls `nxu_memory_init` and `nxu_memory_add_region` from `nxu_platform_memory_init`. Whether a link of this Makefile succeeds was NOT EXECUTED here. The omission is OBSERVED in the file. H1's "DTB validated then unused" matches the tree: a DTB decoder exists, and the linked image's source list does not include it.

`make qemu` in that Makefile is:

```
qemu-system-aarch64 -M virt,gic-version=3 -cpu cortex-a57 -smp 2 -m 512M \
    -nographic -serial mon:stdio -kernel $(BUILD_DIR)/nxu.bin
```

`-smp 2` is in the recipe. H1 called a claim of 4-CPU validation against `-smp 2` a measurement hygiene failure. The recipe, as read, is smp 2 and 512M. No evidence log from that command was in this workspace. That QEMU line is NOT RE-EXECUTED here. The current launcher uses smp 4 and 128M, and the freeze log says four CPUs. Those are different measurements.

Debug adds `-O0 -g3 -DDEBUG -DNXU_RUN_INTERRUPT_TEST`. The interrupt regression test is compiled into the debug image of the origin tree. Closure later forbids `NXU_RUN_*` on the TCB path. The current Makefile has no such flag. The negative case lives under `probe/`.

### 2.4 Properties the origin entry already had

`arch/arm64/boot/start.S` `_start`:

- `msr daifset, #0xf` before other work. KEPT. Current `silicon/aarch64/entry/start.S` still masks DAIF first.
- Reads `mpidr_el1`, packs affinity, then sets SP from `__stack_top`.
- Clears BSS with a byte loop of stores.
- Loads `vectors` into `vbar_el1` before `nxu_kernel_main`. KEPT as a property: VBAR is NXU's before unmask. The current tree installs a halt VBAR at entry and the real VBAR at S7, because unmask is later. The origin tree installs VBAR immediately and the EL is hard-coded as EL1 (`vbar_el1` only).
- Stores affinity and `x0` into `nxu_boot_info`. The current intake records a wider residue and then refuses the incoming stack and tables.

`nxu_secondary_entry` in the same file masks DAIF, loads `__secondary_stack_cpu1_top`, sets `vbar_el1`, and calls `nxu_secondary_cpu_main`. One stack symbol. One secondary. REJECTED as architecture. Current S9 creates a stack for every present CPU. Current S12 iterates the available set. `probe/check.sh` rejects `cpu_start(1)` and `secondary_stack_cpu1`.

The origin secondary path, from this file alone, does not program SCTLR, TTBR, or a timer, and does not bind an `nxu_cpu_exec_context`. Those types do not exist in that tree. H1's "secondary without MMU, timer, or context" matches what this entry does. A fuller secondary C file was not the one opened beyond the entry stub. `[HISTORICAL DETAIL NOT RECOVERED]` for `nxu_secondary_cpu_main`'s body.

### 2.5 Boot "validation" was a non-zero DTB pointer

`kernel/boot/boot.c` `nxu_boot_validate` returns -1 if `boot_info` is null or if `dtb_address == 0`. Otherwise it logs `NXU_LOG_EVENT_BOOT_VALIDATED` and returns 0. That is the whole check in the file that was read. REJECTED. Current S2 checks ARM64 magic, flags `0xA`, and image size. S3 bounds the blob. S4 corroborates. A pointer is not acceptance. `boot.c` is also absent from the origin link list, so even this weak check may not have been in the linked image. NOT VERIFIED by an origin build.

### 2.6 Three CPU states, then `cpu_start(1)`

`kernel/include/nxu/cpu.h` defines `NXU_CPU_OFFLINE`, `NXU_CPU_STARTING`, `NXU_CPU_ONLINE`. No `present`, no `initialized`, no `available`, no `failed`. The comment says "Hardware affinity is discovered, not assumed" and "CPU objects are owned by the kernel."

`kernel/init/main.c` after timer init does `nxu_cpu_start(1U)` and prints `cpu1 start... ok` when the call returns 0. `kernel/cpu/cpu.c` `nxu_cpu_start` sets STARTING, issues PSCI `CPU_ON`, and on a zero return prints `PSCI CPU_ON returned SUCCESS` and returns 0 without waiting for the secondary to store ONLINE. The ONLINE store is a different function, `nxu_cpu_online`, which also tries to write a log event. So a success return from `CPU_ON` is treated as "cpu1 start... ok" by `main`. REJECTED. Current invariant 18: `CPU_ON` success is not online. Online is a self-publish with a timeout. `state=0x5` in the debug log is that later store, not the PSCI return.

`NXU_MAX_CPUS` is 16 in that header. Current `NXU_CPU_BOUND` is 8. The bound is a compile-time ceiling, not the present set. Genesis: N comes from facts.

### 2.7 Interrupt manager, backend, and handler pointers

`kernel/include/nxu/interrupt_manager.h` describes register/configure/enable, an interrupt object table, dispatch, then "handler + nesting frame". `nxu_interrupt_set_handler` takes `void (*handler)(struct nxu_interrupt *)`. `kernel/include/nxu/interrupt.h` stores that pointer and a `handler_context` on the interrupt object.

`kernel/timer.c` registers `nxu_timer_interrupt_handler` through `nxu_interrupt_set_handler`. `kernel/init/interrupt_test.c` registers `nxu_test_spi32_handler`, `nxu_test_spi33_handler`, and `nxu_test_sgi1_handler` the same way. Those tests sit on the debug image via `NXU_RUN_INTERRUPT_TEST`.

REJECTED for the TCB. Closure A8 and invariant 20: no function-pointer dispatch, no 1-of-N, no caller-supplied TCB handlers. Current signal path branches on INTID class inside foundation. A search of `foundation/` for handler pointers finds only volatile flag loads (`*fired`, `*seen`) and FDT character walks. No `nxu_interrupt_set_handler`.

The manager/backend split is the shape Genesis section 5.2 item 18 refuses: GICv3 is an adapter, not the architecture. Current silicon `gicv3.c` programs registers at caller-supplied addresses. Current `foundation/signal/signal.c` owns which INTIDs the TCB enables.

### 2.8 Timer as a demo wait on the counter

After `cpu_start(1)`, origin `main.c` clears DAIF bit 1 (`msr daifclr, #2`) and spins until `nxu_timer_now() - start >= frequency + frequency/2`, then prints `timer test complete`. That wait is a polled counter delta of 1.5 seconds of `CNTFRQ`, not a proof that the PPI was delivered. The handler exists separately. Whether the PPI path was what completed that loop was NOT MEASURED from an origin log in this workspace. Current S11 waits on `timer_fired`, set from the IRQ path, with the flag volatile, a compiler barrier, and a DSB before the wait. The normal sentence is `The timer deadline was observed`. The debug log's `spins=0x3226dd` is the wait count from this pass, not a UART tick.

`uart_puthex` in origin `drivers/uart/pl011.c` prints 16 nibbles (`for (int i = 60; i >= 0; i -= 4)`). That is the padded form the current console refuses in normal mode. Current `nxu_sink_hex_compact` is debug-only.

### 2.9 Addresses that were architecture in the origin files

`arch/arm64/platform/platform.c` says "This is PLATFORM knowledge" and "It must NOT be used directly by generic NXU memory or DTB code", then defines:

- RAM base `0x40000000`, size `0x20000000` (end comment `0x60000000`)
- GICD `0x08000000`
- GICR `0x080A0000`
- redistributor stride `0x20000`

The comment already wanted a platform boundary. The constants still lived in `arch/`, which Genesis treats as architectural code, and the RAM size is compiled in rather than corroborated. Current QEMU candidates live only in `board/qemu-virt/facts.c`: RAM `0x40000000` size `0x8000000` (128M, matching the launcher's `-m 128M`, not the origin's 512M), GICD `0x08000000` size `0x10000`, GICR `0x080A0000` size `0xF60000`, UART `0x09000000` size `0x1000`, four MPIDRs, PSCI HVC. `probe/check.sh` rejects those constants if they appear under `foundation/`, `silicon/`, `image/`, `include/`, or the Makefile.

`drivers/uart/pl011.c` defines `UART_BASE 0x9000000ULL` in the driver itself. The driver knows QEMU's UART. REJECTED. Current `pl011.c` takes a base parameter. The address is a board candidate, accepted or not at S4, bound after S6.

### 2.10 Logging as a subsystem

`log/` splits policy, storage, events, and per-CPU log. `log_policy.h` exposes allow-emergency and allow-normal decisions. `cpu.c` treats a failed `CPU_ONLINE` log record as a console warning, not as a halt. Genesis item 21 rejects printk, a logging framework, and earlycon-as-architecture. Current chronicle is per-CPU, fixed capacity, with an immortal last-failure slot. Overflow does not fail open and does not fail the boot by itself. The console is optional and silent until a UART is owned. Halt does not need it.

The origin files are evidence. They are not migrated. Genesis says so. The README at `fb02f5f` says so.

## 3. From that tree to the current one

```
public origin (arch/ kernel/ drivers/ log/)
    ↓
privacy and explicit-authority sentences kept
    ↓
Linux-shaped directories rejected as the architecture
    ↓
Genesis v1 proposed (H2; full v1 text not in this tree)
    ↓
Genesis v2 text (genesis.md, identical to genesis v2.md)
    ↓
closure C1–C18
    ↓
ACCEPT GENESIS V2 (H5)
    ↓
S0–S14 on a new tree (H6)
    ↓
structural correction: exception, context, two build dirs (H7)
    ↓
observe split: chronicle, Black Box, live console (H8)
    ↓
probe repair: PTY capture, FVP loads ELF, VA-0 image contract (H9)
    ↓
this pass: clean suite re-measured; invariant 26–28 restored to the history
```

No arrow adds a stage. No arrow renames `nxu_cpu_exec_context`. No arrow imports Room, Wall, Edge, Fabric, or Pulse.

H2 is the only record of v1's full outline in this tree. A separate v1 manuscript was not found beside `genesis.md`. `[HISTORICAL DETAIL NOT RECOVERED]` for v1's unpublished wording beyond H2. H2's gaps (atom as a type name, PPI 30 versus EL2, MMU-on takeover, shared chronicle, present set closed before GIC) are the gaps closure then closed. That match is why H2 is treated as the v1 note and not as authority.

`genesis.md` and `genesis v2.md` are the same bytes. Calling one of them a different architecture would be an invention. Closure is the delta. H4 says implementation waited for `ACCEPT GENESIS V2`. H5 says that command was given and the new tree started at S0. The current `foundation/enter.c` calls S0 through S14 and then halt. That sequence is the implementation of the accepted order.

## 4. Closure invariants 26–28

H9 section 8 originally stopped at 25 and said closure stopped there. That sentence was removed. The three further rules, and what the sources do, are:

26. After space is armed, TCB translation is the only regime. Every bound context's translate fields equal it. `nxu_s14_freeze` compares `nxu_cpu[i].ctx.ttbr` with `nxu_mmu_ttbr()` and calls `nxu_fail(NXU_FAIL_INVARIANT, 26U, i)` on a mismatch. BUILT. A second regime was NOT INJECTED. Debug showed one `ttbr=0x40208000`.

27. After the first secondary `CPU_ON`, the fact table, ownership map, and page tables are read-only. Life-state fields have exclusive writers. S12 sets `nxu_facts.frozen` and `nxu_space.frozen` before `CPU_ON`. BUILT. A proof that no later writer remains was NOT PRODUCED.

28. At freeze, no present CPU is still `available` or `starting`. S14 fails with invariant 28 if either remains, then requires `NXU_CPU_ONLINE`. BUILT. This pass's debug log showed `state=0x5` for the secondaries that printed online lines, then S14. The timeout path was NOT EXECUTED.

These numbers are closure's numbers. They are already the numbers `freeze.c` passes to `nxu_fail`. History was behind the code. The code was not changed to match the bad sentence.

## 5. Genesis mechanism table, mapped

Genesis section 5.2 asks, for each mechanism: what problem, what usual assumption, can it be removed, can hardware enforce it, what is the simplest strong mechanism, how is it proved. The rows below are that table against the current files. Status is this tree, not a new design.

### 5.1 Entry may be a lie

Usual assumption: the Linux ARM64 boot protocol is the trust contract. Genesis: accept it as one intake shape only. Observe EL, DAIF, SCTLR, MPIDR, PC. Bad header, mixed EL, or an IRQ that cannot be masked halts.

Current: `start.S` writes the 64-byte header (`b nxu_entry`, text offset 0, image size, flags `0xA`, magic `ARM\x64` as `0x644d5241`). `foundation/contract/contract.c` checks that shape at S2. `foundation/intake/intake.c` records the residue at S1. `s0.c` rejects `SCTLR.M=1`. BUILT. Happy path TESTED this pass (the image reached S14, so S2 accepted). Bad-magic path NOT RE-RUN this pass. Crypto boot is not in the TCB. A1 remains: structural contract is foundation boot-trust. Key custody is OPEN (R6).

### 5.2 DTB and topology are claims

Usual assumption: trust the DTB. Genesis: bounded probe, wrap-safe checks, corroboration with board candidates and observation. Disagreement halts.

Current: `foundation/facts/fdt.c` is the decoder. It does not decide policy. `facts.c` merges ranges only when both sides exist and `range_eq` holds, otherwise `NXU_FAIL_FACT_MISMATCH`. CPU records come from the DTB when the DTB lists CPUs; each DTB MPIDR must appear in the board candidate list or the boot halts. Extra board MPIDRs that the DTB does not name do not become present. That is why a board file can list more CPUs than a given boot brings up, and why N is not the board array length. QEMU this pass: four CPUs, DTB accepted. A disagreeing-RAM fixture was NOT EXECUTED.

The DTB cap is `NXU_DTB_PROBE_CAP` (`0x100000`), a contract constant, not the board RAM size. C9. BUILT.

### 5.3 Cryptographic boot

Not foundation. A1. REJECTED as a substitute for the structural contract. No ROM, fuse, or key type exists under `foundation/` or `silicon/`. R6 and R7 remain OPEN. `[HISTORICAL DETAIL NOT RECOVERED]` for any experiment that compared DICE, AVB, and measured boot with a result. None is filed in H1–H8 as EXECUTED.

### 5.4 Platforms differ in addresses

Usual assumption: `#define` QEMU virt in platform code. Genesis: a normalized fact table. Current: board candidates, then S4. Silicon functions take physical addresses as parameters. C11. BUILT. The grep fence in `probe/check.sh` is the host-side proof that the known QEMU and FVP constants are not in architectural files. It is not a proof that some future constant was forgotten. The list in the script is the known set from these two boards.

### 5.5 One lying source

Usual assumption: DTB or the hardcoded board is the single source of truth. Genesis: one source is a recorded weakness (grade `single`), not full corroboration. Two sources that disagree reject. U3: a compiled-in RAM map is not required on every boot, because requiring it would put QEMU RAM back into the architecture as a mandatory second source.

Current grades: `NXU_GRADE_OBSERVED` 1, `NXU_GRADE_SINGLE` 2, `NXU_GRADE_CORROBORATED` 3. Sources: observation bit 0, DTB bit 1, board bit 2. BUILT in `include/nxu/config.h` and written by `facts.c`. The normal console does not print the grade. Debug this pass printed `ram=0x40000000` but not the grade number. Grade itself: NOT MEASURED from the console. The field is BUILT.

### 5.6 What may be touched

Usual assumption: the firmware memory map is correct. Genesis: physical ownership, then stage-1. Current S5 `ownership.c` records RAM as `NXU_OWNER_NXU`, the image footprint as `NXU_OWNER_IMAGE`, the DTB as `NXU_OWNER_RESERVED` when present, and GICD, GICR, and UART as `NXU_OWNER_MMIO` when accepted. Wrap failure is `NXU_FAIL_WRAP`. BUILT. The table is not printed on the normal console. S6 will not map unknown. TESTED only as part of the path that reached S14.

### 5.7 Spatial isolation

Usual assumption: a software convention or the language. Genesis: the MMU. Default deny, never write-and-execute, unknown unmapped. Current `mmu_policy.c` maps the image (split by linker section) and accepted MMIO, then enables SCTLR.M. BUILT. An external page-table dump was NOT PRODUCED this pass. A deliberate write to an execute-only page was NOT EXECUTED. Claim of spatial isolation beyond "this map is what the code asks for": NOT VERIFIED. Rushby spatial separation is a research claim. It is not printed as a result.

### 5.8 Early access

Usual assumption: identity-map all RAM. Genesis: bootstrap window is the image, plus a bounded DTB probe. Current S6 does not map all of the RAM owner class. The RAM owner class exists so the image can be shown to lie inside accepted RAM. Mapping is a later, narrower decision. BUILT. Identity-map-all was REJECTED and is not what `mmu_policy.c` does.

### 5.9 Range checks

Usual assumption: `addr + size` without a wrap check. Genesis A6: wrap-safe membership. Current `nxu_range_ok` is what `add_owner` calls before inserting a region. BUILT. A fixture with `base + size` overflowing was NOT EXECUTED this pass.

### 5.10 Unexpected control transfer

Usual assumption: a pretty panic, then continue. Genesis: NXU's vector table, save into the running context, unexpected class halts. Current `vectors.S` saves and enters foundation C. Unexpected synchronous, FIQ, and SError do not return. `exception.c` records ESR/FAR on the fault path. BUILT. A synchronous fault fixture was NOT EXECUTED this pass. The QEMU success path did not take it. VBAR before unmask: OBSERVED by console order (exception line, then timer).

### 5.11 Several CPUs

Usual assumption: Linux `cpu_possible` / `present` / `online` masks plus `smp_ops` plus `cpu_start(1)`. Genesis: present, initialized, available, starting, online, and failed. Boot CPU iterates the available set.

Current constants: present 1, initialized 2, available 3, starting 4, online 5, failed 6. The origin enum was 0 offline, 1 starting, 2 online. The numbers are not a rename of that enum. Present is not offline. Initialized and available did not exist there. Failed did not exist there. `cpu.c` assigns logical ids after the present set is built. Affinity 0 is not CPU0 until it is matched. BUILT. This pass OBSERVED four present and then bring-up complete.

### 5.12 Bring-up trust

Usual assumption: trust PSCI and treat the return as online. Genesis: adapter, timeout, self-publish. Current `silicon/aarch64/psci/psci.c` issues HVC or SMC and returns the firmware code. `smp.c` does not store online on that return. The secondary stores online. The boot CPU waits. Timeout is `NXU_FAIL_TIMEOUT`. BUILT. This pass OBSERVED CPU_ON lines and later online lines as separate debug records. A failed PSCI return was NOT EXECUTED.

### 5.13 Secondary stack

Usual assumption: `__secondary_stack_cpu1_top`. Genesis: one stack per present CPU, created at initialize. Current `nxu_cpu_stack[NXU_CPU_BOUND][NXU_STACK_SIZE]` with `NXU_STACK_SIZE` 64KiB. Debug printed four stack values. OBSERVED. The symbol `__secondary_stack_cpu1_top` is absent. The check script rejects it.

### 5.14 Shared kernel versus multikernel

Genesis A3: do not silently pick Linux-one-kernel or a multikernel. Share enumerated objects. Keep the rest CPU-local. Multikernel stays research until R16. Current sharing after the freeze point is the fact table, the ownership map, and the page tables, marked frozen, plus topology slots with exclusive writers (C7). Chronicle is per-CPU. There is no per-CPU kernel image. A3's measurement is OPEN. The implementation is the explicit-sharing choice, not a proof that sharing is cheaper.

### 5.15 Restorable execution state

Usual assumption: thread, process, task, or an seL4 TCB. Genesis: `nxu_cpu_exec_context`, save/restore/halt/idle only. Not a scheduler entity. Current struct fields, from `include/nxu/context.h`:

| Genesis map | Current field | Note |
|---|---|---|
| identity cpu_id, context_id, generation | `cpu_id`, `context_id`, `generation` | present |
| life inert, armed, running, waiting, faulted | `life` with `NXU_CTX_*` 0..4 | C2: online life is running or waiting |
| gpr x0–x30 | `gpr[31]` | x0–x30 |
| sp, pc, pstate, el | `sp`, `pc`, `pstate`, `el` | present |
| translate TTBR/TCR/MAIR | `ttbr`, `tcr`, `mair` | C14: must equal the TCB regime |
| exception ESR, FAR | `esr`, `far` | captured on fault |
| signal DAIF, active INTID | `daif`, `intid` | present |
| stack base, limit | `stack_base`, `stack_limit` | guard-page behavior NOT separately MEASURED |
| owner: TCB, later Room id | `owner` | Room id is not a value the TCB writes as a research name |

`include/nxu/exec.h` is absent. `probe/check.sh` fails if it returns. The informal word "atom" is not the type name. C16. BUILT. No scheduler, runqueue, or `current_task` symbol. The check script searches for those names.

### 5.16 Hardware events

Usual assumption: Linux IRQ domain, `request_irq`, 1-of-N. Genesis: a signal is an identity, an exclusive owner, and a single-CPU route. GICv3 can route to one CPU. Current timer signal and IPI signal are TCB-owned and routed to one CPU. S13 checks the non-target did not observe the targeted SGI. Reaching S14 means that check did not halt. OBSERVED indirectly. A stolen-owner fixture was NOT EXECUTED.

### 5.17 Dispatch

Usual assumption: a function-pointer table. Genesis A8: compiled-in paths by INTID class. Current code does that. Origin `nxu_interrupt_set_handler` does not exist here. REJECTED and absent.

### 5.18 GICv3 is not the architecture

Usual assumption: an irqchip object is the design. Genesis: signals are the architecture; GICv3 is an adapter. Current split: `silicon/aarch64/gicv3/gicv3.c` versus `foundation/signal/signal.c`. The silicon file does not know how many CPUs policy wants. The foundation file does not embed `0x08000000`. BUILT. ITS and LPI are not in the TCB. R19 (two-security versus single-security) is OPEN.

S10 reads IIDR after the MMIO region is mapped. Debug `iidr=0x43b`. OBSERVED. Present-set freeze is at the end of S10 (`nxu_cpu_present_frozen`), not at S8. C5. BUILT.

### 5.19 Ordering and timeouts

Usual assumption: HZ, jiffies, `timer_list`. Genesis: observed counter plus a per-CPU one-shot deadline as a TCB signal. Current S11 programs `timer_freq / 100` ticks through the EL1 or EL2 physical timer, enables the PPI, unmasks IRQ, and waits. Not a UNIX tick. Not `uart_puts("tick")`. BUILT. Fire OBSERVED this pass.

### 5.20 Secondary hang

Usual assumption: wait forever. Genesis A12: if a present CPU does not come online, halt. Current S12 times out. BUILT. The success path did not take the timeout. NOT EXECUTED as a failure. M10: `available` is a gate, not a legal freeze state. Heterogeneous or firmware-offline clusters remain R11. OPEN. Do not treat the QEMU virt four-CPU result as an answer to big.LITTLE.

### 5.21 Knowing what NXU did

Usual assumption: printk. Genesis: an append-only chronicle, optional UART sink after the UART is an accepted fact. Current `chronicle.c` plus `bbox.c`. Record codes are stage-scoped constants in `chronicle.h` (`NXU_REC_S0_ENTER` through `NXU_REC_SEC_ENTER`, and `NXU_REC_IRQ`). Failure codes are the `0x80000000` range from `NXU_FAIL_MMU_ON_ENTRY` through `NXU_FAIL_WRONG_TARGET`. The normal console does not dump the ring. `nxu_bbox_dump` exists for debug. Black Box is bounded (`NXU_BBOX_CAP` 32). Chronicle ring is `NXU_CHRONICLE_CAP` 128 per CPU. Last-failure is not overwritten by a non-failure record. BUILT. Overflow NOT INJECTED. The console sentences are not a replacement for the ring. H8 is the decision that split them.

### 5.22 Bad state

Usual assumption: degraded boot. Genesis: halt, DAIF masked, no further `CPU_ON`, WFI. UART optional. Current `halt.c` and `fail.c`. `fail.c` prints `Foundation halted` if a sink exists, then halts. The success log has no FAIL line. BUILT. U4: no distributed abort IPI if the boot CPU fails after secondaries are online. Secondaries stay waiting. No recovery plane. That absence is intentional. It is not an unfinished feature.

## 6. Rejected assumptions, and where the rejection lives

Genesis section 8 says these are not "later". They are out. Each line is the rejection and the evidence that the current tree still refuses it.

- Not a Linux replacement, UNIX clone, or POSIX OS. No filesystem, network stack, driver framework, UI, libc, ELF loader, syscall table, page cache, swap, or overcommit under the TCB allow-list. OBSERVED by the Makefile source list.
- Not `arch/` + `kernel/` + `drivers/` as the architecture. `probe/check.sh` fails if those directories exist. The origin tree has them. This tree does not.
- Not a migration of the origin tree. H5. The origin remains on GitHub as the snapshot the README itself demotes.
- Firmware, DTB, PSCI, bootloader, incoming SP, incoming page tables, and MMIO maps are not trusted. Entry captures SP into the residue (`mov x23, sp` is required by the check script) and then installs `nxu_boot_stack_top`.
- The Linux boot protocol is an intake shape. The header magic is checked. It is not a signature. S2's map says so.
- Do not drop EL2 to EL1 because Linux does. A11. Entry reads `CurrentEL`. EL2 uses EL2 registers. EL1 uses EL1 registers. Mixed or unexpected EL rejects. EL2 boot NOT EXECUTED. The branch is BUILT in `start.S` (`cmp x24, #8`).
- DTB is not source of truth. S4 can reject it.
- No QEMU or FVP address in architectural C. The fence listed in section 5.4.
- UART-first is not architecture. The first console line is in S6, after ownership, inside `mmu_policy.c`. Before that, chronicle records exist without a sink.
- Vendor verified boot is not the authority model. Absent.
- `present == online` is false. Different constants. S8, S9, and S12 are different functions.
- The GIC redistributor walk is a corroboration source, not the topology. S10 can halt on mismatch. A mismatch was NOT INJECTED.
- `CPU_ON` success is not online. Section 5.12.
- No `cpu_start(1)` and no single secondary stack symbol. Absent. The check script searches.
- Linux CPU masks are not the model even where the English word "present" overlaps. The state machine is the six constants above.
- `nxu_cpu_exec_context` is not a thread, process, task, or seL4 TCB. The type name is the whole abstraction. No CSpace, untyped, or endpoint type.
- No scheduler, timeslice, or runqueue. Absent. The check script searches `nxu_sched_`, `runqueue`, `current_task`.
- Multikernel is not the silent default. One image. Explicit shared objects. R16 OPEN.
- No identity-map of all RAM. Section 5.8.
- No WX, no default-allow, no demand paging. Map policy. NOT VERIFIED by an external dump.
- No overflowing `address + size`. `nxu_range_ok`.
- No Linux IRQ domain, no `request_irq`, no handler pointers. Section 5.17.
- No 1-of-N. S13.
- GICv3 is not the interrupt architecture. Section 5.18.
- No ITS/LPI in foundation.
- No HZ tick and no demo UART tick. Section 5.19.
- No ambient authority: no global current-task, no caller-supplied handler, no unbound enabled signal that continues. Unbound pending INTID chronicles, EOIs, and halts. The success path did not take that halt.
- Language does not define isolation. The build is freestanding C and assembly, compiled by Zig's clang or by an `aarch64-*-gcc` if Zig is absent. A10 says that is a vehicle. R20 (a bounded C subset versus Rust) is OPEN. The toolchain choice is not that decision.
- Minimal TCB does not mean skipping the MMU, SMP completeness, timeouts, or fail-closed behavior. S6, S12, and halt are in the sequence. Omitting them would be the origin's shape, which was rejected.
- Room, Wall, Edge, Fabric, Pulse are not foundation because the names sound architectural. They do not appear in TCB sources. The check script searches `foundation/`, `silicon/`, `include/`, and `image/` for those words. Research may discuss them. Research is not linked.
- Rushby properties are not claimed. No measurement of cache interference, speculation, or fault containment was produced this pass.
- seL4 names are not copied in ahead of R17. R17 is "compare after S14". S14 exists on QEMU. The comparison was NOT EXECUTED. The absence is still correct.
- Experiments are not on the TCB boot path. Origin `NXU_RUN_INTERRUPT_TEST` is not a current flag.
- A logging framework is not architecture. Section 2.10 versus section 5.21.

Historical keep-list from Genesis section 8, still kept, with this pass's evidence:

| Property | Origin evidence | Current evidence |
|---|---|---|
| DAIF mask at entry | `start.S` `daifset, #0xf` | same instruction; S14 reached, so entry returned |
| VBAR before unmask | origin sets `vbar_el1` before `main` | halt VBAR at entry, real VBAR at S7, unmask at S11; console order |
| PSCI can start a secondary on virt | origin `cpu_start(1)` recipe; log NOT IN THIS WORKSPACE | debug CPU_ON then online for mpidr 1, 2, 3 |
| Redistributor walk can count | origin GIC files exist; count NOT RE-MEASURED from them | `iidr=0x43b` and four CPUs; mismatch NOT INJECTED |
| Timer PPI can fire | origin also polls the counter; PPI proof NOT IN THAT LOG | `The timer deadline was observed`, `ppi=0x1e` |
| Wrap-safe physical membership | origin DTB converter exists; wrap fixture NOT RE-READ as a test | `nxu_range_ok`; fixture NOT EXECUTED this pass |
| WFI halt | origin idle loop `wfi` | `halt.c` |

## 7. Research questions, still open

Closure section F and Genesis section 6 list the same experiments. None of them is closed by the QEMU freeze. Writing them here is not permission to implement them.

R1. Two contexts, disjoint maps, disjoint signals, disjoint deadlines: does interference remain? NOT EXECUTED. Foundation does not create a second translation regime. C14 forbids it inside the TCB. The experiment would be a research image, which the firewall says must be a different artifact. No such artifact is built.

R2. Does the name Room add a property beyond a second context? NOT EXECUTED. The name stays in research. If a later measurement says no, the name is to be rejected, not implemented hopefully.

R3. Can a non-TCB signal be delivered with no TCB policy beyond ack, EOI, and a context switch? NOT EXECUTED. Current unbound INTIDs halt. That is foundation behavior. It is not a device-ownership result.

R4. Pulse: what is the interference bound on Cortex-A? NOT MEASURED. Do not claim temporal isolation. The timer test is one deadline on CPU 0. It is not a non-interference proof.

R5. Can a non-TCB fault be contained without halt? NOT EXECUTED. Foundation halt-on-fault is the accepted behavior. Containing a foreign fault would be a different claim.

R6. Who holds the root of authority for any verified boot? OPEN. No key type in the TCB.

R7. Rollback storage. OPEN. No RPMB or fuse access.

R8. Is the 64-byte ARM64 header a hidden Linux dependency? The header is the intake shape. A native header was not built. OPEN. The current check treats magic and flags as structure. It does not call Linux.

R9. Compiled-in board facts versus a second blob. Both exist as candidates. The QEMU run corroborated them far enough to freeze. That is not a general answer. A second machine with different addresses was not booted this pass. FVP would have been that second fact source. FVP was NOT EXECUTED. So Genesis's "two fact sources" rule is NOT SATISFIED for this pass. QEMU-only is the evidence. Do not upgrade it.

R10. Cost of staying at EL2, and whether stage-2 is worth it. OPEN. This pass entered at EL1 (`el=0x1`). EL2 code paths are BUILT in entry, timer, and PPI selection (26 versus 30). NOT EXECUTED.

R11. A12 on heterogeneous or firmware-offline CPUs. OPEN. QEMU virt SMP is homogeneous. `board/soc/` does not describe a real SoC.

R12. Spin-table bring-up. REJECTED until a board without PSCI exists. No spin-table code. The FVP and QEMU board files both name a PSCI conduit (SMC and HVC). That is not a discovery of a spin-table board.

R13. Secondary cache and TLB completeness. NOT MEASURED on hardware. The QEMU secondaries came online. That is not a cache-completeness measurement. Do not copy a Linux secondary-MMU sequence to paper over it.

R14. Identity-map of NXU RAM versus a high virtual window. OPEN. The current map is an identity map of the image plus accepted MMIO. The high window was not built. S6's choice is the identity image map. It is not a decision that identity mapping is enough isolation machinery for later research.

R15. How much firmware MMIO must remain after takeover. OPEN. What is mapped is GIC and, if accepted, UART. PSCI itself is a calling convention, not a mapped region in the ownership table. Whether EL3 windows remain reachable some other way was NOT MEASURED.

R16. Shared-memory SMP versus multikernel. OPEN. Section 5.14.

R17. seL4 untyped and capabilities versus Rushby partitions. NOT EXECUTED. S14 on QEMU does not select either.

R18. When an exec context becomes schedulable without becoming a UNIX thread. OPEN. Foundation does not schedule. Idle is wait. That is not Pulse.

R19. GICv3 security model and ITS/LPI cost. OPEN. The adapter used is the path that produced `iidr=0x43b` on QEMU virt GICv3. A two-security FVP configuration was NOT EXECUTED.

R20. Bounded C versus Rust. OPEN. Current language is freestanding C and assembly. Not an isolation result.

R21. Can the freeze chronicle reconstruct a boot on paper without a debugger? PARTIAL. The normal console reconstructs the stage order in sentences. The debug log reconstructs PC, DTB, RAM, TTBR, EL, VBAR, present count, boot MPIDR, stacks, GICD, GICR, IIDR, frequency, PPI, spin count, CNTPCT, per-CPU MPIDR, online state, and IPI target. The chronicle ring itself was not dumped in the normal log. A paper reconstruction from the ring alone was NOT PERFORMED. The debug log is enough to see that S11 fired and that three secondaries reached state 5. That is a console reconstruction, not a proof of the freeze format.

R22. Two fact sources with different addresses and the same semantics, at each stage. NOT EXECUTED. QEMU addresses and FVP candidate addresses differ (section 8). Only QEMU ran.

Closure section G repeats the unresolved questions: A3, EL2 cost, A12 versus big.LITTLE, native header, whether board facts should exist at all, whether the identity map is enough, whether any research name survives R1–R5, key custody, language. None of those was answered by editing a probe script.

## 8. FVP boundary, not a second kernel

The execution model that was already in the tree, and that this pass left alone:

```
NXU TCB
   │
   same foundation
   │
   ┌────────┴────────┐
   ▼                 ▼
 QEMU               FVP
   │                 │
 nxu.img           nxu.elf
   │                 │
 execute           execute
```

`probe/fvp/run.sh` resolves `$FVP`, then `$FVP_BIN`, then `probe/host/fvp/FVP_Base_RevC-2xAEMvA` (and two alternate file names), then those names on `PATH`. It passes `build-fvp/nxu.elf` to `-a cluster0.cpu0=`. It does not pass `nxu.img`. The model error `file format not recognized` is what a raw image produces. That error was the reported bug. The script now refuses that format before the model has to. This pass could not confirm the model accepts the ELF, because the model binary was not on the machine.

The script also sets `bp.secure_memory=0`, a default refcounter start, `cluster0.NUM_CORES=4`, untuned UART FIFOs off the telnet terminals, and visualization disabled. Those are model switches. They are not foundation policy. They do not belong in `foundation/`.

`board/fvp-base/facts.c` candidates, which are not architecture:

- RAM `0x80000000` size `0x80000000`
- GICD `0x2F000000` size `0x10000`
- GICR `0x2F100000` size `0x200000`
- UART `0x1C090000` size `0x1000`
- eight MPIDRs: `0, 1, 2, 3, 0x100, 0x101, 0x102, 0x103`
- PSCI SMC

S4 requires an exact range match when both the DTB and the board speak. If a future FVP DTB reports a different DRAM size, or a different GIC size, the boot will halt with `NXU_FAIL_FACT_MISMATCH`. That halt would be the contract. It would not be a reason to delete the check. It was NOT OBSERVED, because the model did not start.

CPU count: the present set is the DTB's CPU list, filtered by membership in the board list. Listing eight candidates does not force eight online if the DTB lists four. `cluster0.NUM_CORES=4` is a model switch that may produce a four-CPU DTB whose MPIDRs are inside the candidate list. That interaction is NOT VERIFIED. Changing either number without a log would be a guess. This pass does not guess.

QEMU continues to load `build-qemu/nxu.img`. The raw image is required by QEMU's `-kernel` for this boot protocol. The ELF is required by the Fast Model's load formats (ELF, S-record, Intel hex, Verilog hex). Same foundation. Different probe artifact. No second kernel was added.

## 9. Image contract that the probe depends on

`image/nxu.ld` sets `. = 0`. The header is `KEEP(*(.text.header))`. Text, rodata, and bss are split on page boundaries. The boot stack is 64KiB inside bss (`nxu_boot_stack` to `nxu_boot_stack_top`). `.got` is discarded. A raw binary has no loader to apply absolute relocations. A jump table or a pointer table of string addresses would point at the link address, not the load address. That fault was OBSERVED in an earlier pass, recorded in H9: a count-to-string pointer table printed a FAIL instead of the CPU sentence. The repair is a switch on string literals in `console.c`, plus `-fno-jump-tables`, which `probe/check.sh` requires. This pass's normal log prints `Four CPUs were discovered` and then S14. The repair held after `make clean`.

Load address `0x40200000` appears in the debug log as `pc`. It is not in the linker script. QEMU virt's `-kernel` load of an ARM64 image header is what placed it there. The foundation computes the footprint from the PC. That is why the same image text can be aimed at a different physical base without editing `nxu.ld`. FVP's base, if it ever runs, is a fact-and-loader question, not a second link script. NOT EXECUTED.

## 10. Three traces, file by file

A subsystem is documented when the source, the NXU MAP at the top of that source, and this history agree. The map stays in the file. This table is the history trace. It does not replace the map. "Agree" means the map's ownership sentence matches the functions in the file and the Genesis row in section 5. It does not mean every open experiment is done.

| File | Owns, as the map and the functions say | History |
|---|---|---|
| `silicon/aarch64/entry/start.S` | DAIF, NXU stack, residue, halt VBAR, secondary SP | §2.4, §5.1 |
| `silicon/aarch64/exception/vectors.S` | vector stubs, no handler table | §5.10 |
| `silicon/aarch64/uart/pl011.c` | putc at a parameter base | §2.9 |
| `silicon/aarch64/gicv3/gicv3.c` | distributor, redistributor, ICC | §5.18 |
| `silicon/aarch64/psci/psci.c` | CPU_ON convention | §5.12 |
| `silicon/aarch64/timer/timer.c` | CNTPCT, CNTFRQ, EL1/EL2 physical timer | §5.19 |
| `silicon/aarch64/translate/mmu.c` | table program and SCTLR.M | §5.7 |
| `image/image.c`, `image/nxu.ld` | footprint and VA 0 layout | §9 |
| `board/qemu-virt/facts.c` | QEMU candidates only | §2.9 |
| `board/fvp-base/facts.c` | FVP candidates only | §8 |
| `board/soc/facts.c` | present clear; no SoC described | §1.3, R11 |
| `foundation/enter.c` | call order S0–S14 then halt | §3 |
| `foundation/intake/s0.c` | footprint, MMU-on reject | §5.1 |
| `foundation/intake/intake.c` | residue record | §5.1 |
| `foundation/contract/contract.c` | header shape, not trust | §5.1 |
| `foundation/facts/fdt.c` | bounded decode, no policy | §5.2 |
| `foundation/facts/facts.c` | corroboration or halt | §5.2, §5.5 |
| `foundation/space/ownership.c` | owner classes | §5.6 |
| `foundation/space/mmu_policy.c` | what is mapped; first console lines | §5.7, §5.21 |
| `foundation/exception/exception.c` | vector policy, fault halt | §5.10 |
| `foundation/context/context.c` | bind one context under the TCB regime | §5.15 |
| `foundation/cpu/cpu.c` | present set, stacks, init | §5.11, §5.13 |
| `foundation/cpu/smp.c` | bring-up, occupy, timeout | §5.12 |
| `foundation/signal/signal.c` | TCB signals, S10, S13 | §5.16–§5.18 |
| `foundation/time/time.c` | one deadline, IRQ wait | §5.19, §2.8 |
| `foundation/observe/chronicle.c` | per-CPU ring | §5.21 |
| `foundation/observe/bbox.c` | bounded evidence, last failure | §5.21 |
| `foundation/observe/console.c` | sentences; debug behind `NXU_DEBUG` | §1.2, §9 |
| `foundation/observe/sink.c` | UART bind after acceptance | §5.21 |
| `foundation/observe/fail.c` | fail closed | §5.22 |
| `foundation/observe/freeze.c` | S14 checks, including 26 and 28 | §4 |
| `foundation/observe/halt.c` | mask and WFI | §5.22 |
| `probe/qemu/run.sh` | PTY capture, strict S14 | §1.1 |
| `probe/fvp/run.sh` | ELF, both env names, no home path | §8 |

Research names are not in that table's TCB rows. Promoting one would be a Genesis amendment, a measurement that could fail, and an allow-list change. A documentation pass is none of those.

## 11. Console, debug, and Black Box

They stay distinct. This pass's logs are the evidence.

Normal console: `[NXU][SUBSYSTEM]` and a sentence. No quotation marks. No physical address. The sentences are the list in section 1.2. They name what the stage is doing: loading, validating, translation, exceptions, discovery, interrupt control, timer, bring-up, IPI, freeze.

Debug: the same sentences, plus `[NXU][DBG][TAG]` and `key=0x...` with compact hex. `0x40200000` appears. `0x0000000040200000` does not. MPIDR, affinity as the mpidr value, stack pointers, GIC bases, IIDR, timer frequency, PPI, spin count, CNTPCT, online state, and IPI target are in the debug log. BSS initialization and redistributor association are not printed as their own lines. `[HISTORICAL DETAIL NOT RECOVERED]` is the wrong mark for that: the code may record them in the chronicle without printing them. A chronicle dump was not in the normal log. Say instead: those details are NOT in the debug console of this pass, even if a chronicle slot exists.

Black Box: not printed as a hex dump at halt on the success path. It remains the bounded machine record. It is not architectural authority. Replacing it with the sentences would make a timeout of the console look like a missing freeze, which is the H8 bug. The live S14 sentence exists so the probe can see freeze without waiting for a dump. The box still exists so a halt has a record if the console never bound.

CPU0 prints. Other CPUs do not take the console. That is `console_ok` in `console.c`. A secondary that fails does not narrate. Its state is what the boot CPU waits on, and what the chronicle on that CPU can hold.

## 12. What this pass refused

It did not add a stage between S0 and S14.

It did not rename `nxu_cpu_exec_context`.

It did not put Room, Wall, Edge, Fabric, Pulse, a scheduler, a process, a thread, or a task into the TCB.

It did not treat QEMU as architectural authority, and it did not treat a missing FVP binary as a failed foundation.

It did not delete the S14 check, and it did not write a fake S14 line into the log.

It did not hard-code `/workspace` or a home directory into the launcher or the Makefile.

It did not build a second FVP kernel or a second link script.

It did not change FVP RAM or CPU candidate numbers to chase a model that did not run.

It did not claim the negative header case, EL2, MMU-on reject, DTB overlap, wrap, redistributor mismatch, or timer timeout as results of this pass. Those paths are BUILT or previously noted. They were not re-measured here.

It did not claim real-hardware validation.

H1–H8 remain the short notes. H9 remains the stage reconstruction, with the invariant-25 error corrected. This file is the origin reading and the closure remainder. If a later reading of the public tree disagrees with a quotation here, the file that was fetched wins, and this file should be corrected. Research still does not win over Genesis or over the sources.
