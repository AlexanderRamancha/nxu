# H9 — Reconstruction of the current NXU architecture

**Status of this file:** research. Not linked. Not authority.

**Sources used:** `genesis.md` (identical to `genesis v2.md` in this tree), `GENESIS_V2_CLOSURE.md`, `research/history/H1` through `H8`, the current foundation/silicon/board/image/probe sources, and the QEMU evidence logs. H10 later read the public origin tree at `AlexanderRamancha/nxu` (commit `fb02f5f` on 2026-09-22, README rewrite). Where H9 says a public-tree detail was not re-read, H10 is the reading. Where a detail is still absent, it is marked `[HISTORICAL DETAIL NOT RECOVERED]`.

This reconstruction does not add stages, rename `nxu_cpu_exec_context`, or promote research names into the TCB.

## 1. How to read the labels

BUILT means the current tree contains the mechanism.

TESTED means a host command in this project exercised it and the result was recorded.

OBSERVED means a log or chronicle line shows the event.

MEASURED means a quantity was taken from the run, not assumed.

EXECUTED means the platform process actually ran NXU.

NOT EXECUTED means the binary or the hardware was not run.

NOT VERIFIED means the code exists and a stronger claim was not made.

ASSUMED means a working assumption from Genesis that an experiment has not closed.

OPEN means Genesis left it unresolved on purpose.

REJECTED means a design was written down and then refused.

QEMU success is not hardware validation. FVP success would not be either. Neither is claimed as architecture.

## 2. The line this tree is on

```
early public NXU
    ↓
custom-kernel experiments on QEMU
    ↓
privacy and explicit-authority principles kept
    ↓
Linux-shaped tree rejected as architecture
    ↓
Genesis v1 proposed
    ↓
Genesis v2 four-layer proposal
    ↓
closure C1–C18
    ↓
ACCEPT GENESIS V2
    ↓
S0 then S1–S14 on a new tree
    ↓
structural correction (exception, context, two artifacts)
    ↓
observe split (chronicle, Black Box, console)
    ↓
probe repair (PTY capture, FVP loads ELF)
```

The last arrow is a probe and compiler-contract repair. It does not change S0–S14.

## 3. Early public tree

H1 describes a public ARM64 tree aimed at explicit authority and isolation, laid out like Linux: `arch/`, `kernel/`, `drivers/`. The goal was stated as privacy by construction. The method was to bring a machine up on QEMU virt: UART, exceptions, DTB, GICv3, CPU topology, PSCI, generic timer, logging.

What was proposed there, and not carried forward as architecture:

- An interrupt manager plus a backend, with capability-based IRQ delivery. H1 says capabilities were not built.
- Three CPU states: OFFLINE, STARTING, ONLINE. The current model is present, initialized, available, starting, online, and failed. The extra states are not decoration. Present is not online. Initialized is not available. Available is a bring-up gate. Failed exists so a CPU that does not arrive is not left unnamed.
- A `boot_info` of affinity, DTB pointer, and flags. Current intake records a wider residue (EL, MPIDR, SCTLR, TTBR, TCR, PC, incoming SP, x0–x3, DAIF) and then refuses to inherit the stack or the tables.

What H1 records as built in that tree, and rejected as architecture here:

- Hardcoded QEMU RAM, GIC, and UART addresses in the architectural code. REJECTED. They now live only in `board/qemu-virt/facts.c` as candidates.
- GIC redistributor walk treated as the topology. REJECTED as policy. The walk remains a silicon operation. Foundation matches redistributors to the present set and halts on mismatch.
- `cpu_start(1)` and a single secondary stack symbol. REJECTED. Every present CPU gets a stack at initialize. The boot CPU iterates the available set.
- Function-pointer IRQ handlers. REJECTED. INTID class is handled in foundation without a handler table.
- Logging as a TCB subsystem. REJECTED. Chronicle and Black Box are bounded evidence. The console is an optional sink after ownership.
- Experiments left on the kernel main path. REJECTED. Negative cases live under `probe/`.

What H1 says was unfinished there: capabilities, userspace, a panic subsystem, persistent diagnostics, MMU. Those unfinished items were not silently completed by renaming them. MMU was later specified as foundation policy plus silicon operations. Capabilities, userspace, and persistent diagnostics are not in the current TCB. `[HISTORICAL DETAIL NOT RECOVERED]` for any later commit on that public tree after H1 was written.

H1's mistakes, kept as warnings:

- A non-zero DTB pointer was treated as boot validation. Current S2 checks header shape. S3 bounds the blob. S4 corroborates. A pointer is not acceptance.
- The DTB was parsed enough to look valid and then unused while addresses stayed compiled in. Current facts record source and grade. Disagreement halts.
- Secondary CPUs ran without the MMU, the timer, or a bound context. Current S12 freezes tables before CPU_ON. Secondaries occupy. They do not discover.
- UART happened before ownership. Current sink binds only after space is armed and the UART range is an accepted MMIO fact.
- Makefile `-smp 2` was used while claims said 4 CPUs. A later QEMU smp=2 run in this tree recorded present = online = freeze = 2, so N is measured from facts. The smp=4 freeze is a different measurement. Neither measurement is a license to hardcode 4.

Properties H1 says are worth keeping, and which the current sources still do:

- DAIF masked at entry. BUILT in `silicon/aarch64/entry/start.S`. TESTED by reaching S7 before unmask on QEMU.
- VBAR is NXU's before unmask. BUILT in S7. OBSERVED as the exception console line before the timer unmask.
- Wrap-safe physical membership. BUILT in range checks used by the DTB probe and ownership. NOT separately MEASURED with a crafted overflowing range in the latest run.
- Fail-closed WFI halt. BUILT in `foundation/observe/halt.c`.
- PSCI can start a secondary on virt. OBSERVED: bring-up complete with four CPUs, then S14.
- The generic-timer PPI can fire. OBSERVED: `The timer deadline was observed` before SMP.

The historical tree is evidence. Genesis says it is not migrated.

## 4. Privacy and explicit authority, without a Unix

The reason to leave the Linux-shaped tree was not that UART or PSCI are illegitimate. It was that the directory shape had become the architecture. `kernel/`, `arch/`, and `drivers/` import a scheduler, a current task, a driver model, and a handler table whether or not those words are used carefully.

Principles that survived into Genesis v2, as H2 and H3 record them:

- NXU is a machine-control substrate. It is not Unix, POSIX, or a filesystem.
- Intake is untrusted. Hardware enforcement is preferred over policy that hopes the caller was kind.
- Facts are platform data with a source and a grade, not a compiled board.
- Isolation vocabulary that does not name a new enforceable property stays in research.
- Rushby-style separation is a claim to be measured, not a slogan to print. Section 6 of Genesis leaves isolation claims as research questions. Status of those measurements: NOT EXECUTED.

REJECTED with that turn, and still absent from the TCB sources:

- Scheduler, timeslice, runqueue.
- Process, thread, task, and `current_task`.
- POSIX and a driver framework.
- Vendor verified boot as a silent default. Cryptographic boot stayed in research.
- 1-of-N interrupt delivery.
- Handler function pointers.

`[HISTORICAL DETAIL NOT RECOVERED]` for the exact conversation that first chose the word "foundation" over "kernel". H2 is the earliest note in this tree, dated 2026-09-22, and it already uses foundation.

## 5. Genesis v1, proposed and not accepted as the final text

H2: design only. No experiments. Sixteen-section architecture. Historical tree left untouched. No implementation until an explicit accept.

Proposed there:

- Ownership-phase boot, not a trust-the-firmware boot.
- Facts corroborated from more than one kind of source when two sources exist.
- Four CPU states plus failed.
- `nxu_cpu_exec_context` as the execution record.
- Signals instead of an irqchip object.
- Chronicle instead of a logging subsystem.
- Stay at the entry exception level.
- Stages S0–S14.
- Research names for isolation structure. Those names are not repeated in TCB sources. They were not implemented.
- Repository split: foundation, silicon, board, research, probe.

Decisions that were only proposed: 22 invariants, working assumptions A1–A10, structural boot contract in foundation, cryptographic boot in research.

Gaps H2 already names, later closed or restated by H4:

- Informal name "execution atom".
- Timer "typically PPI 30" colliding with EL2.
- MMU-on entry takeover colliding with "never use incoming tables".
- A shared chronicle after SMP.
- Present set closed before GIC corroboration.

Status of v1 as a document: superseded by v2 plus closure. It is not deleted. It is not authority by itself.

## 6. Genesis v2

H3: still design-only. The change from v1 is the four-layer import rule and a longer rejected-assumption list. Foundation is supposed to be solid, not merely small. Smallness that omits a check is not a virtue.

The four layers, still the current tree:

```
Hardware
    ↓
silicon/aarch64     operations, addresses as parameters
    ↓
board facts         candidates only
    ↓
foundation policy   S0–S14
    ↓
observe             chronicle, Black Box, optional console
```

Research sits beside this. It must not be linked. Probe sits on the host. It must not be linked.

Import rules that the current Makefile and `probe/check.sh` enforce:

- `research/` does not appear on the TCB source list.
- Foundation, silicon, image, and include do not mention `research/`.
- Board addresses that identify QEMU or FVP do not appear in those architectural trees.
- `kernel/`, `arch/`, and `drivers/` directories are rejected if present.
- `cpu_start(1)` and a single secondary stack symbol are rejected if present.
- Handler-pointer names from the historical shape are rejected if present.

A1–A12 are working assumptions in v2. Closure says several remain OPEN because they need experiments: cost of staying at EL2, heterogeneous CPUs, RAM identity versus a high window, whether a research isolation name ever names a new property, boot-key custody, secondary cache and TLB behavior, GICv3 security, language choice. None of those were closed by the S0–S14 implementation. Mark them OPEN or NOT VERIFIED, not decided.

v2 still sometimes glossed the execution record as an atom. Closure C16 dropped that as a type name. The C type in `include/nxu/context.h` is `nxu_cpu_exec_context`. Status: BUILT, name unchanged.

## 7. Closure, item by item

Closure is a delta. It is not a redesign. S0–S14 order is unchanged. The following is what the delta says and what the current sources do.

### X1 / C1 — unknown memory versus the DTB probe

Collision: invariant 4 said unknown physical memory is inaccessible, but the DTB must be read before a map exists.

Resolution: invariant 4 applies after space is armed. The bootstrap window is the image footprint plus a bounded DTB probe. That read is untrusted. It is not ownership.

Status: BUILT. `fdt.c` is the bounded read. `mmu_policy.c` arms translation afterward. TESTED on QEMU, where a DTB was accepted and translation then enabled.

### X2 / C2 — running versus waiting

Collision: one running context per online CPU, but secondaries wait after they come online.

Resolution: one bound context per online CPU. Life is running or waiting.

Status: BUILT. S14 checks life is one of those two, and that TTBR matches the TCB regime. OBSERVED by reaching S14 on four CPUs.

### X3 / C3 — MMU-on entry

Collision: "never use incoming page tables" versus a takeover of firmware tables when SCTLR.M is set.

Resolution: MMU-on entry rejects. No takeover. Intake still records SCTLR so the reject is visible.

Status: BUILT in S0. QEMU entry was OBSERVED with the MMU off, so the reject path was NOT EXECUTED as an injected case. NOT VERIFIED against a firmware that enters with the MMU on.

### X4 / C4 — timer PPI

Collision: stay at EL2, but text said the timer is typically PPI 30.

Resolution: the PPI follows the ARM generic timer for `control_el`. EL1 physical is 30. EL2 physical is 26. Facts may omit it and receive the ISA default. Facts may not contradict the ISA. It is not a QEMU constant.

Status: BUILT. QEMU at EL1 OBSERVED PPI 30 (`ppi=0x1e` in the debug log). EL2 path BUILT, NOT EXECUTED.

### X5 / C5 — when the present set freezes

Collision: topology looked closed at S8, but S10 can find a different redistributor count.

Resolution: the present set is provisional until the controller corroborates it. Freeze is after S10.

Status: BUILT. `nxu_cpu_present_frozen` is set at the end of S10. S14 requires it. QEMU matched 4 redistributors to 4 CPUs. A deliberate mismatch was NOT INJECTED.

### X6 / C6 — when MMIO may be touched

Collision: facts talk about an accepted controller before any MMIO is allowed.

Resolution: candidate addresses at facts time. IIDR and TYPER only after the region is owned and mapped. Grade may rise then.

Status: BUILT. S10 reads IIDR after S6. Debug showed an IIDR value. The grade upgrade is in the source. The numeric grade was not printed on the normal console. NOT MEASURED from the console; the code path is BUILT.

### X7 / C7 — chronicle and shared objects

Collision: a shared chronicle versus SMP without a lock, versus "no implicit shared mutable kernel objects".

Resolution: chronicle is per-CPU. Page tables, the fact table, and the ownership map are read-only before CPU_ON. Each CPU writes its own lifecycle state: the boot CPU marks starting, the target marks itself online or failed.

Status: BUILT. S12 sets `nxu_facts.frozen` and `nxu_space.frozen` before CPU_ON. Per-CPU chronicle arrays exist. A lock-freedom proof was NOT PRODUCED. The QEMU run did not show a corrupted freeze, which is not a proof.

### X8 / C8 / C9 — DTB bounds

The DTB range must not overlap the image. The probe cap is a contract constant (`NXU_DTB_PROBE_CAP`), not the board RAM size.

Status: BUILT. Overlap and oversize halt in the decoder. An injected overlap image was NOT EXECUTED in the latest pass. The happy path on QEMU accepted a DTB that fit.

### C10 — load-bearing versus optional

Load-bearing: RAM containing the image, boot MPIDR in the present set, control EL, observed timer frequency, enable method if more than one CPU, controller identity after the mapped probe. UART may be absent.

Status: BUILT. UART is optional in the sink. QEMU had a UART, so the absent-UART path was NOT EXECUTED. Frequency zero would fail S14. OBSERVED non-zero frequency in debug.

### C11 — silicon does not read board

Status: BUILT. Silicon functions take addresses as parameters. `probe/check.sh` rejects known board addresses in foundation, silicon, image, and include.

### C12 — FDT is not a fifth layer

Status: BUILT. The decoder is `foundation/facts/fdt.c`. It does not set policy beyond "this blob is well-formed enough to be a candidate".

### C13 — no bring-up poke

CPU_ON starts the secondary. S13 still proves a targeted SGI, for later TLB maintenance, not as the thing that starts the CPU.

Status: BUILT. QEMU OBSERVED CPU_ON in debug and, separately, `Inter-processor signal was delivered` on the normal console.

### C14 — one translation regime

The context's translate fields are the TCB regime. A second regime is research.

Status: BUILT. S14 compares TTBR. Divergence was NOT INJECTED.

### C15 — chronicle overflow

Per-CPU ring. Last-failure slot is not overwritten by ordinary records. Overflow does not fail open.

Status: BUILT in chronicle and Black Box. Overflow was NOT INJECTED. Cap is `NXU_CHRONICLE_CAP` / `NXU_BBOX_CAP`.

### C16 — do not rename the context

Status: BUILT. `include/nxu/exec.h` is absent. The type name remains.

### C17 — research firewall

Status: BUILT as a source check and a Makefile allow-list. The linker command does not list `research/`.

### C18 / M10 — available at freeze

`available` is a bring-up gate. At freeze, no CPU may still be available or starting. Each present CPU is online, or the boot has already halted. Failed during bring-up halts under the "all present CPUs online or halt" rule.

Status: BUILT in S14. QEMU freeze had four online. A timeout fail path exists and was NOT EXECUTED in the successful run.

### Removed complexity that stayed removed

- Firmware MMU takeover. REJECTED.
- Distributed abort IPI if the boot CPU fails after secondaries are online. REJECTED. Boot CPU halts. Secondaries stay waiting. No recovery plane.
- A compiled-in RAM map required on every boot. REJECTED. One RAM source plus image inside RAM is allowed at grade single. Two sources that disagree reject.
- A fifth layer for FDT. REJECTED.

## 8. Invariants as they stand in the sources

Numbering follows the closure restatement. Each line is the rule, then the implementation status. This is not a new invariant list.

1. DAIF stays masked until vectors and TCB signal bind are complete. BUILT. Unmask happens for the timer test and the IPI test, then mask returns. OBSERVED because those tests completed and S14 ran.

2. A broken invariant halts. It does not continue. BUILT in `nxu_fail`. The successful QEMU log has no `[NXU][FAIL]`.

3. No use before ownership, except the bootstrap window. BUILT by stage order in `enter.c`. UART bind is after S6.

4. After space is armed, unknown physical memory is inaccessible. BUILT as map policy: image plus accepted MMIO only. NOT VERIFIED by a deliberate unmapped load in a separate probe image.

5. Physical membership is wrap-safe. BUILT in range helpers. A wrap fixture was NOT EXECUTED.

6. Image is inside accepted RAM. DTB does not overlap the image. BUILT. QEMU happy path OBSERVED. Overlap fixture NOT EXECUTED.

7. After space is armed: MMU on, never write-and-execute, default deny. BUILT in map permissions. WX was not separately scanned in the latest log. NOT VERIFIED by an external page-table dump.

8. VBAR is NXU's before any unmask. BUILT. Console order shows exception install before the timer.

9. Present, initialized, available, and online are different. Present is provisional until the controller agrees. BUILT. S8 then S9 then S10 then S12 are separate functions.

10. Boot MPIDR is in the present set. BUILT. Missing boot CPU calls fail. QEMU boot MPIDR was 0 and was present.

11. Online CPUs share `control_el`. MMU-on entry rejects. Mixed ELs reject. BUILT as checks. Mixed EL NOT EXECUTED.

12. Each online CPU has one bound context, life running or waiting. BUILT. Checked at S14.

13. That context's stack is exclusive and bounded. SP outside the bound is a fault then halt. Stack bounds are BUILT and stored. An out-of-bounds SP fixture was NOT EXECUTED.

14. A signal has zero or one owner. Enabled implies one owner. BUILT for the timer PPI and the IPI SGI. A stolen-owner fixture was NOT EXECUTED.

15. A signal routes to one CPU. BUILT. S13 checks the non-target did not observe the targeted SGI. OBSERVED by reaching S14, which means that check did not halt.

16. Accepted facts do not contradict observations or each other. BUILT as corroboration. A disagreeing-RAM fixture was NOT EXECUTED. QEMU agreement was OBSERVED.

17. Secondaries do not discover. They occupy. BUILT. The secondary entry records a logical id and waits. It does not parse a DTB.

18. CPU_ON success is not online. BUILT. Online is a store by the secondary, waited on with a timeout. OBSERVED as separate debug lines.

19. Chronicle is per-CPU, with an immortal last-failure slot, and is never a reason to continue after a fault. BUILT. Overflow NOT INJECTED.

20. No ambient authority: no handler tables, no 1-of-N, no global current task. BUILT by absence. `probe/check.sh` searches for the historical names.

21. Architectural C has no board addresses and no board-named behavior. BUILT as a grep in `probe/check.sh`. Silicon takes addresses as parameters.

22. Research is not linked. BUILT as an allow-list.

23. Incoming SP is unused. Incoming page tables are unused. MMU-on entry rejects. BUILT. Incoming SP is captured in the entry sequence (`mov x23, sp` is required by the check script) and then replaced.

24. Facts carry source and grade. BUILT in the fact structures. Debug console does not print every grade. The fields are TESTED insofar as S14 requires a non-zero timer frequency and an armed space, which only exist after acceptance.

25. Region owners are explicit. Unknown is not mapped. BUILT in the ownership table. Classes in `include/nxu/config.h` are `NXU_OWNER_UNKNOWN`, `NXU_OWNER_FIRMWARE`, `NXU_OWNER_IMAGE`, `NXU_OWNER_NXU`, `NXU_OWNER_MMIO`, `NXU_OWNER_RESERVED`. Genesis names the MMIO class `mmio-accepted` and the reserved class `reserved-do-not-touch`. The numeric classes match. The longer names are the document's words, not extra types. QEMU recorded an owner step in earlier chronicle-based logs. The latest normal console does not print owner class numbers. Status of the table: BUILT. Status of a human listing of every region in the latest log: not printed. NOT a deletion of the table.

Closure restates three further invariants. An earlier draft of this section said the list stopped at 25. That sentence was wrong. `GENESIS_V2_CLOSURE.md` section C continues:

26. After space is armed, TCB translation is the only regime. All bound `nxu_cpu_exec_context` translate fields equal it. BUILT. S14 compares each context's `ttbr` to `nxu_mmu_ttbr()` and fails with invariant 26 if they differ. Divergence was NOT INJECTED.

27. After `CPU_ON` of the first secondary is issued, the fact table, the ownership map, and the page tables are read-only. Topology life-state fields have exclusive writers. BUILT as `nxu_facts.frozen` and `nxu_space.frozen` set in S12 before `CPU_ON`. A proof that no later writer exists was NOT PRODUCED. The QEMU freeze did not show a corrupted table, which is not a proof.

28. At freeze, no present CPU remains `available` or `starting`. BUILT. S14 fails with invariant 28 if either state remains, then also requires `NXU_CPU_ONLINE`. QEMU smp=4 reached freeze with four online. The timeout path that would halt earlier was NOT EXECUTED in that success run.

The numbers 26, 27, and 28 are closure's numbers. They are not a new invariant list.

## 9. Stages S0–S14

Order in `foundation/enter.c` is the authority for sequence. Meaning is Genesis plus closure. The notes below say what the file does and what was executed.

### S0 — intake of the image

File: `foundation/intake/s0.c`.

Owns the footprint from the PC and the MMU-on reject. Does not own the stack switch; entry already did that.

Status: BUILT. TESTED as part of every QEMU run that reaches later stages. A run that halts at S0 was not the latest success path.

### S1 — record the residue

File: `foundation/intake/intake.c`.

Owns the chronicle of EL, MPIDR, SCTLR, PC, early registers, DAIF. Does not trust them.

Status: BUILT. Values show up in debug (`el=0x1`, `pc=0x40200000`). OBSERVED.

### S2 — header shape

File: `foundation/contract/contract.c`.

Owns magic, flags, and size. The header is not a signature.

Status: BUILT. Happy path TESTED. Corrupted magic: previously OBSERVED to avoid S14 (`probe/cases/neg-header.sh`). That negative case was not repeated in the latest `make qemu` pass. Mark the latest pass NOT RE-RUN for the negative case. The earlier result remains in the evidence note, not as a new measurement.

### S3 — DTB probe

File: `foundation/facts/fdt.c`.

Owns a bounded untrusted parse. Produces candidates, not facts. PSCI `method` is stored on the node and applied at the node end so property order cannot drop the conduit. That fix is recorded in H6 after a real parse-order bug.

Status: BUILT. QEMU DTB path OBSERVED (`Device tree validation is complete`).

### S4 — corroboration

File: `foundation/facts/facts.c`.

Owns accept or halt. Board candidates that the DTB does not name do not become present CPUs.

Status: BUILT. smp=4 OBSERVED. smp=2 previously OBSERVED as N=2. The smp=2 log is an earlier artifact (`probe/evidence/qemu-virt-smp2.log`), not a rerun this pass.

### S5 — ownership

File: `foundation/space/ownership.c`.

Owns the table. RAM for NXU, image as image, DTB reserved, GIC and UART as MMIO when accepted.

Status: BUILT. Not itemized on the normal console. Required for S6 and for S14's armed check.

### S6 — translation

File: `foundation/space/mmu_policy.c`.

Owns which ranges are mapped. Enables the MMU. Binds the UART if one was accepted. The first human lines are printed here because there is no sink before ownership.

Normal lines: loading the image, validating boot information, device tree complete or absent, boot information accepted, enabling translation.

Status: BUILT. TESTED. Those lines are in `probe/evidence/qemu-virt.log`.

### S7 — vectors and the boot context

File: `foundation/exception/exception.c`, with stubs in `silicon/aarch64/exception/vectors.S` and bind in `foundation/context/context.c`.

Owns VBAR and the initial bind of `nxu_cpu_exec_context`.

Normal line: `Exception handling is installed`.

Status: BUILT. TESTED.

### S8 — present set

File: `foundation/cpu/cpu.c`.

Owns logical ids for CPUs the facts accepted. Boot MPIDR must be among them.

Normal lines: discovery is initializing; then a count sentence. Four CPUs on the smp=4 run. The words are console text. The count is the present-set size, not a constant in the sentence generator's input.

Status: BUILT. OBSERVED `Four CPUs were discovered`.

A first attempt to print that sentence used a table of string pointers. The image is linked at VA 0 and loaded elsewhere, so an absolute pointer table is not relocated. The bad pointer faulted, the fail path printed `Foundation halted` on the same line, and S14 did not happen. The fix is a direct literal per count, plus `-fno-jump-tables`, so the compiler cannot emit a table that assumes the link address. That is an image-contract fix, not a stage change. Status of the fault: OBSERVED during this pass, then corrected, then the same image reached S14.

### S9 — initialize

Same file.

Owns a stack and a bound context for every present CPU. State moves to initialized and then available. The boot CPU's context is running. Others are armed until they occupy.

Normal line: `CPU initialization is complete`.

Status: BUILT. TESTED.

### S10 — controller

File: `foundation/signal/signal.c`.

Owns redistributor match, CPU interface enable, and freezing the present set.

Normal lines: initializing interrupt control; initialization complete.

Status: BUILT. TESTED on QEMU GICv3.

### S11 — time

File: `foundation/time/time.c`.

Owns one deadline. Waits until `timer_fired` is set from the IRQ path. The flag is volatile. The wait uses a compiler barrier. A data synchronization barrier is issued before the wait so the store is not invisible.

Normal lines: configuring the timer; initialization complete; the deadline was observed.

Earlier bug, recorded in H6 and H8: the IRQ arrived (chronicle showed INTID 30) but a non-volatile load was hoisted and the wait never saw it. Header edits also failed to rebuild the waiter until `-MMD -MP`. The S14 check was not weakened to hide that. Status of the repair: the latest log shows the deadline line and then S14. OBSERVED.

### S12 — bring-up

File: `foundation/cpu/smp.c`.

Owns CPU_ON for every non-boot present CPU, then a timeout wait for self-publish. Tables are frozen first. One CPU skips PSCI and is simply online.

Normal lines: bringing CPUs online; bring-up complete. MPIDR and per-CPU state are debug.

Status: BUILT. smp=4 OBSERVED.

### S13 — targeted signal

Same signal file as S10.

Owns a TCB SGI to CPU 0 and then to CPU 1, and checks the wrong target did not take it.

Normal line: `Inter-processor signal was delivered`.

Status: BUILT. OBSERVED on smp=4. The single-CPU branch does not claim a cross-CPU delivery. That branch was NOT EXECUTED in the latest smp=4 run.

### S14 — freeze

File: `foundation/observe/freeze.c`.

Owns the invariant check, the freeze record, the sentence `NXU foundation is frozen`, and the boot CPU moving to waiting.

Status: BUILT. TESTED. `make qemu` fails if the line is absent. Latest result: `QEMU capture ok: S14 freeze observed (smp=4)`.

Then `nxu_halt`. Halt is not a stage. It is the end.

## 10. Structural correction

H7. After S0–S14 already froze on QEMU, the tree still had drift: `foundation/exec/`, one `build/` directory, and generic map files as the primary description.

What changed, without a stage redesign:

- Exception policy moved to `foundation/exception/`.
- Context bind moved to `foundation/context/`.
- The type name stayed.
- Artifacts split into `build-qemu/` and `build-fvp/` from one TCB core plus one board file.
- Maps live in the source files.

REJECTED again: copying `kernel/`, `arch/`, `drivers/`.

Status: BUILT. Still the tree.

## 11. Observe, console, Black Box

H8. A hex dump of the chronicle at halt was the only freeze evidence. A timeout could kill QEMU before the dump, and the capture looked like "no S14" even when the machine had frozen. The capture was then pointed at a live line. The S14 check stayed strict.

Three outputs, kept distinct:

- Console: sentences for a person. Normal mode does not print padded physical addresses.
- Debug: the same run plus compact values (`0x40200000`, not a 16-digit pad). Built with `-DNXU_DEBUG=1` into `build-debug/`.
- Black Box: bounded per-CPU records and a last-failure slot. It is not architectural authority. It is what you read after a halt. The normal console does not dump the ring. Debug can.

Status: BUILT. Normal and debug both EXECUTED to S14 in the latest full run.

## 12. Probe repair in this pass

This pass did not retune S0–S14.

QEMU. A direct `qemu-system-aarch64 -nographic -kernel build-qemu/nxu.img` shows a console because the standard streams are a terminal. `make qemu` captured through a pipe or through `script(1)`. On a host with no terminal, `script` recorded "not executed" and an empty body, and the S14 check correctly failed. The launcher now allocates a PTY, writes bytes to the log as they arrive, and also writes them to the parent so the console is not hidden. Empty log is still failure. `[NXU][FAIL]` is still failure. `[NXU][S14]` is still required.

Discovery: a repository-local QEMU is used only if `--version` actually runs. Otherwise PATH. `NXU_QEMU` overrides when it runs. No absolute workspace path is compiled in. The script locates itself from its own directory.

FVP. Two probe bugs, not two kernels.

- The launcher looked only at `FVP_BIN`. It now accepts `$FVP`, then `$FVP_BIN`, then a repository-local binary, then PATH. A home directory is not written into the script.
- `-a cluster0.cpu0=` was given `nxu.img`. Fast Models reject that format (`file format not recognized` is the reported model error). The launcher now passes `build-fvp/nxu.elf`. QEMU still uses `nxu.img`. `make fvp` builds both artifacts and does not execute. `make fvp-run` executes.

Latest environment result, verbatim in kind:

```
FVP: NOT EXECUTED
FVP binary available: no
FVP process started: no
NXU image loaded: no
NXU boot observed: no
S14 observed: no
```

That is not PASS. If a later host has the model on PATH or in `$FVP`, the same script is what should be run. This reconstruction does not invent an FVP log.

Image contract. Linked at VA 0 (`image/nxu.ld`). A raw binary has no loader to apply absolute relocations. `-fno-jump-tables` is in the Makefile and checked by `probe/check.sh`. Header dependencies remain `-MMD -MP`.

## 13. Three traces

A subsystem is documented when the source, the NXU MAP in that source, and this history agree. The map is in the file. This section is the history trace. It does not replace the map.

| Subsystem | Source | Map | History | Agree |
|---|---|---|---|---|
| Entry | `silicon/aarch64/entry/start.S` | residue, DAIF, NXU stack | §3, §9 S0 | yes |
| Intake | `foundation/intake/` | untrusted record | §9 S0 S1 | yes |
| Contract | `foundation/contract/contract.c` | header is not trust | §9 S2 | yes |
| Facts | `foundation/facts/` | candidates then grade | §7 C8–C12, §9 S3 S4 | yes |
| Space | `foundation/space/` | own, then map image and MMIO | §7 C1, §9 S5 S6 | yes |
| Exception | `foundation/exception/` | no handler table | §3, §9 S7 | yes |
| Context | `foundation/context/` | one bound record, TCB regime | §7 C2 C14 C16 | yes |
| CPU | `foundation/cpu/` | lifecycle, not CPU1 | §3, §9 S8 S9 S12 | yes |
| Signal | `foundation/signal/` | one owner, one CPU | §7 C5 C13, §9 S10 S13 | yes |
| Time | `foundation/time/` | ISA PPI, one deadline | §7 C4, §9 S11 | yes |
| Observe | `foundation/observe/` | chronicle, box, console, halt | §11 | yes |
| Silicon ops | `silicon/aarch64/*` | parameters, no policy | §6, C11 | yes |
| Board | `board/*` | candidates only | §3, §12 | yes |
| Image | `image/` | VA 0, PC-relative | §12 | yes |
| Probe | `probe/` | not TCB | §12 | yes |

Research names for isolation structure do not appear in the TCB column. They remain research. Promoting one would be a later architectural decision, not a documentation pass.

## 14. What is still open

These are OPEN or NOT EXECUTED. They are not quietly closed.

- Real ARM64 SoC. `board/soc/` present is 0. NOT EXECUTED.
- FVP in the environment that wrote the latest evidence. NOT EXECUTED.
- EL2 entry and the EL2 physical timer PPI. BUILT, NOT EXECUTED.
- MMU-on entry reject, injected. NOT EXECUTED.
- DTB overlap, wrap, disagreeing RAM, redistributor mismatch, timer timeout. Paths BUILT. Fixtures NOT EXECUTED in the latest pass.
- Unmapped access to prove ESR/FAR capture. Path BUILT. NOT EXECUTED as its own image.
- Secondary cache and TLB completeness. NOT MEASURED on hardware.
- GICv3 security model. NOT CLOSED.
- High virtual window for the TCB. Research. Not decided.
- Boot-key custody and cryptographic boot. Research. Not in the TCB.
- Heterogeneous CPUs. NOT TESTED.
- Language other than freestanding C and assembly. NOT CHOSEN. The current build is Zig's clang in freestanding mode, or an aarch64 ELF gcc if Zig is absent. That is a toolchain fact, not a language decision in Genesis.
- Isolation claims that would need a new enforceable property. OPEN. Not implemented.

## 15. What this reconstruction refuses

It does not treat QEMU's freeze as proof about hardware.

It does not treat a missing FVP binary as a failed architecture.

It does not treat a capture bug as a reason to delete the S14 check.

It does not rename `nxu_cpu_exec_context`.

It does not import a scheduler to explain SMP. SMP here is lifecycle and signals.

It does not fill `[HISTORICAL DETAIL NOT RECOVERED]` with a plausible story.

H1 through H8 remain the short notes. This file is the long reading of those notes against the sources. If they disagree, the Genesis documents and the sources win, and this file should be corrected. Research does not win.
