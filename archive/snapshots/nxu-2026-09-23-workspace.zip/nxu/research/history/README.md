# research/history/

Chronological evidence of substantial NXU design work.

H1–H8 stay short: context → reasoning → proposals → experiments → decisions →
rejected ideas → mistakes → architectural evolution.

H9 and H10 are the reconstruction. They are longer because the documentation
lock asked for the reasoning that produced the current tree, not a paragraph
per stage. They are still not a transcript, and they are still not authority.

Rules:

- Evidence of evolution, never architectural authority.
- Not compiled. Not imported by foundation/silicon/board.
- Do not treat a past proposal as current architecture because it is filed here.
- Do not invent a missing detail. Mark it `[HISTORICAL DETAIL NOT RECOVERED]`.
- `genesis.md` and `genesis v2.md` in this tree are the same text. Closure is the delta.
