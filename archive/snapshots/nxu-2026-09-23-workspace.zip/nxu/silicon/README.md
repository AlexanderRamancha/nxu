# silicon/

## Why

Hardware mechanisms are not policy. If silicon decides ownership or CPU count, the foundation is no longer the TCB.

## Layer

Silicon. ARM64 operations only.

## Ownership

Register access, calling conventions, and vector entry stubs. Addresses arrive as parameters.

## Dependencies

Called by foundation. Must not include `board/` or `research/`. May use `nxu/` types where an operation needs a bound.

## Direction

```
foundation policy → silicon operation → hardware
```

## Files

See `silicon/aarch64/`. This directory is the ISA container.

## Hardware

The operation set: entry, vectors, translation, GICv3, PSCI, generic timer, PL011.

## Forbidden

QEMU or FVP addresses. `if (qemu)`. Handler policy. Topology policy.

## Invariants

Operations only. A return code is not a lifecycle state.

## Evidence

The same silicon objects are linked into `build-qemu` and `build-fvp`. Only `board/*/facts.c` changes.

## History

Genesis split `arch/` plus `drivers/` into this layer so a new board does not fork the mechanisms.

## Status

BUILT. Exercised by the QEMU freeze path. FVP execution NOT EXECUTED.
