# silicon/aarch64/

## Why

The current foundation is specified against ARM64 mechanisms. The directory is the operation set, not a board.

## Layer

Silicon.

## Ownership

Entry, vectors, translation, GICv3, PSCI, generic timer, PL011.

## Dependencies

Headers are included as `<silicon/aarch64/...>`. Foundation passes physical addresses in.

## Direction

```
foundation → aarch64 operation → sysreg or MMIO
```

## Files

| Directory | Owns | Consumes | Produces |
|---|---|---|---|
| `entry/` | DAIF, stack, residue | hardware registers | `nxu_intake` |
| `exception/` | VBAR slots | none | call into foundation C |
| `translate/` | tables and SCTLR.M | ranges and perms | MMU on |
| `gicv3/` | distributor, redistributor, ICC | base addresses | IIDR, IAR, EOI, SGI |
| `psci/` | CPU_ON | conduit, MPIDR, entry | firmware status |
| `timer/` | counter and physical timer | tick count | ISTATUS |
| `uart/` | PL011 write | base address | characters |
| `sysreg.h` | register encodings | none | inline accessors |

## Hardware

AArch64 system registers and the devices named above.

## Forbidden

Board addresses. Policy. A jump table that assumes the link VA is the load VA. The image is linked at 0; the build passes `-fno-jump-tables`.

## Invariants

Incoming SP is not reused. SCTLR.M is observed. Unexpected vector classes do not return.

## Evidence

QEMU EL1 boot reached S14 using these operations.

## History

Kept from earlier experiments only as mechanisms: DAIF mask, VBAR before unmask, PSCI CPU_ON, generic-timer PPI. Not the historical tree's structure.

## Status

BUILT. TESTED under QEMU virt GICv3.
