# silicon/aarch64/entry/

## Why

The first instructions must not trust the caller. They mask interrupts, switch stacks, and record residue.

## Layer

Silicon entry.

## Ownership

ARM64 header shape at offset 0, DAIF mask, NXU stack, halt VBAR until S7, secondary stack switch.

## Dependencies

Branches to `nxu_foundation` after residue is stored. No board data.

## Direction

```
reset or CPU_ON → entry → foundation/enter.c
```

## Files

| File | Owns | Consumes | Produces |
|---|---|---|---|
| `start.S` | entry and secondary entry | registers, image stack | `nxu_intake`, NXU SP |

## Hardware

CurrentEL, MPIDR, SCTLR, TTBR, TCR, VBAR, DAIF, SP.

## Forbidden

Using incoming SP as the NXU stack. Firmware tables. Board load addresses.

## Invariants

Incoming SP is captured then unused. SCTLR.M is recorded, not adopted.

## Evidence

Debug line `pc=0x40200000` is the observed load, not a compiled constant.

## History

Image header is an intake shape shared with the boot contract, not a trust model.

## Status

BUILT. TESTED.
