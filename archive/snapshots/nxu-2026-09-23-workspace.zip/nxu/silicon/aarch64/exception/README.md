# silicon/aarch64/exception/

## Why

Vector slots are hardware. What they mean is foundation.

## Layer

Silicon.

## Ownership

Halt VBAR and the full VBAR. Register save and restore around IRQ. Branch to `nxu_exception` or `nxu_irq_c`.

## Dependencies

No policy. Foundation installs the address and handles the class.

## Direction

```
hardware vector → stub → foundation/exception
```

## Files

| File | Owns | Consumes | Produces |
|---|---|---|---|
| `vectors.S` | slot layout and save/restore | none | C entry |

## Hardware

VBAR slots at 0x80.

## Forbidden

Handler tables. Returning from an unexpected class.

## Invariants

The vectors in use after S7 are NXU's.

## Evidence

S7 console line is printed after VBAR is programmed. IRQ delivery was observed via the timer and the IPI.

## History

A halt vector exists so early faults do not fall into firmware.

## Status

BUILT. TESTED on the QEMU IRQ path.
