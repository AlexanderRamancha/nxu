# silicon/aarch64/gicv3/

## Why

GICv3 is a device the foundation may use. It is not the interrupt architecture.

## Layer

Silicon.

## Ownership

Distributor, redistributor, and CPU-interface register operations.

## Dependencies

Every base address is a parameter from foundation after the region is owned and mapped.

## Direction

```
foundation/signal → gicv3.c → MMIO / ICC
```

## Files

| File | Owns | Consumes | Produces |
|---|---|---|---|
| `gicv3.c` | register operations | physical addresses | IIDR, TYPER, IAR, EOI, SGI, wake |
| `gicv3.h` | prototypes and stride | none | the interface |

## Hardware

GICv3.

## Forbidden

Board addresses. CPU-count policy. Handler policy. ITS and LPI.

## Invariants

Silicon has no policy. A read of IIDR does not accept the controller.

## Evidence

QEMU GICv3 redistributors matched four present CPUs. S13 SGI was observed.

## History

Historical code walked redistributors as the topology. Here the walk is an operation; the match is foundation.

## Status

BUILT. TESTED on QEMU. Security model NOT CLOSED.
