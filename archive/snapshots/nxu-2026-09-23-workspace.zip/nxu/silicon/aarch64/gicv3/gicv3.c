/*
 * NXU MAP
 *
 *                   FOUNDATION SIGNAL
 *                           │
 *                           ▼
 *                 GICD / GICR / ICC OPS
 * Layer: silicon GICv3
 * Owns: distributor/redistributor/ICC register operations
 * Consumes: physical addresses as parameters
 * Produces: IIDR/TYPER, IAR, EOI, SGI, wake, enable
 * Hardware: GICv3
 * Forbidden: board addresses; CPU count policy; handler policy
 * Invariant: silicon has no policy
 * Architectural role: Performs GICv3 register operations at caller-supplied addresses.
 */
#include <silicon/aarch64/gicv3/gicv3.h>
#include <silicon/aarch64/sysreg.h>

nxu_u32
nxu_gic_r32(nxu_u64 base, nxu_u32 off)
{
	return *(volatile nxu_u32 *)(nxu_uptr)(base + (nxu_u64)off);
}

void
nxu_gic_w32(nxu_u64 base, nxu_u32 off, nxu_u32 v)
{
	*(volatile nxu_u32 *)(nxu_uptr)(base + (nxu_u64)off) = v;
}

nxu_u64
nxu_gic_r64(nxu_u64 base, nxu_u32 off)
{
	return *(volatile nxu_u64 *)(nxu_uptr)(base + (nxu_u64)off);
}

void
nxu_gic_icc_enable(nxu_u32 el)
{
	if (el == 2U)
		nxu_msr(S3_4_C12_C9_5, 7ULL); /* ICC_SRE_EL2 */
	nxu_msr(S3_0_C12_C12_5, 7ULL); /* ICC_SRE_EL1 */
	nxu_isb();
	nxu_msr(S3_0_C4_C6_0, 0xFFULL); /* ICC_PMR_EL1 */
	nxu_msr(S3_0_C12_C12_3, 0ULL); /* ICC_BPR1_EL1 */
	nxu_msr(S3_0_C12_C12_7, 1ULL); /* ICC_IGRPEN1_EL1 */
	nxu_isb();
}

nxu_u32
nxu_gic_iar(void)
{
	return (nxu_u32)nxu_mrs(S3_0_C12_C12_0); /* ICC_IAR1_EL1 */
}

void
nxu_gic_eoi(nxu_u32 intid)
{
	nxu_msr(S3_0_C12_C12_1, (nxu_u64)intid); /* ICC_EOIR1_EL1 */
	nxu_isb();
}

void
nxu_gic_sgi(nxu_u32 intid, nxu_u64 mpidr)
{
	nxu_u64 aff0;
	nxu_u64 aff1;
	nxu_u64 aff2;
	nxu_u64 aff3;
	nxu_u64 v;

	aff0 = mpidr & 0xFFULL;
	aff1 = (mpidr >> 8) & 0xFFULL;
	aff2 = (mpidr >> 16) & 0xFFULL;
	aff3 = (mpidr >> 32) & 0xFFULL;
	v = (aff3 << 48) | (aff2 << 32) | (aff1 << 16) |
	    ((nxu_u64)intid << 24) | (1ULL << aff0);
	nxu_dsb();
	nxu_msr(S3_0_C12_C11_5, v); /* ICC_SGI1R_EL1 */
	nxu_isb();
}

void
nxu_gicd_enable(nxu_u64 gicd)
{
	nxu_gic_w32(gicd, 0U, (1U << 1) | (1U << 4));
}

void
nxu_gicr_enable_ppi(nxu_u64 gicr, nxu_u32 intid)
{
	nxu_u64 sgi = gicr + 0x10000ULL;
	nxu_u32 pri_off;
	nxu_u32 pri;

	nxu_gic_w32(sgi, 0x80U, 0xFFFFFFFFU);
	pri_off = 0x400U + (intid & ~3U);
	pri = nxu_gic_r32(sgi, pri_off);
	pri &= ~(0xFFU << ((intid & 3U) * 8U));
	pri |= (0x80U << ((intid & 3U) * 8U));
	nxu_gic_w32(sgi, pri_off, pri);
	nxu_gic_w32(sgi, 0x100U, (1U << intid));
}

void
nxu_gicr_wake(nxu_u64 gicr)
{
	nxu_u32 w;
	nxu_u32 spins = 0U;

	w = nxu_gic_r32(gicr, 0x14U);
	w &= ~1U;
	nxu_gic_w32(gicr, 0x14U, w);
	do {
		w = nxu_gic_r32(gicr, 0x14U);
		spins++;
		if (spins > 1000000U)
			return;
	} while ((w & 2U) != 0U);
}

void
nxu_gicr_enable_sgi(nxu_u64 gicr, nxu_u32 intid)
{
	nxu_gicr_enable_ppi(gicr, intid);
}

nxu_u64
nxu_gicr_typer(nxu_u64 gicr)
{
	return nxu_gic_r64(gicr, 0x08U);
}

nxu_u32
nxu_gicd_iidr(nxu_u64 gicd)
{
	return nxu_gic_r32(gicd, 0x08U);
}

nxu_u32
nxu_gicd_typer(nxu_u64 gicd)
{
	return nxu_gic_r32(gicd, 0x04U);
}
