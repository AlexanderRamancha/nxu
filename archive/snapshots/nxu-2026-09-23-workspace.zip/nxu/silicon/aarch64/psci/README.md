# silicon/aarch64/psci/

## Why

Starting a CPU is a firmware call. Online is a later observation by that CPU.

## Layer

Silicon adapter.

## Ownership

CPU_ON calling convention for HVC or SMC.

## Dependencies

Conduit, MPIDR, entry, and context id are parameters from foundation.

## Direction

```
foundation/cpu/smp.c → psci.c → HVC or SMC
```

## Files

| File | Owns | Consumes | Produces |
|---|---|---|---|
| `psci.c` | the call | conduit and arguments | firmware return code |
| `psci.h` | prototypes | none | the interface |

## Hardware

HVC or SMC.

## Forbidden

Treating the return as online. Board CPU numbers. Discovering topology.

## Invariants

Adapter only.

## Evidence

QEMU debug shows `CPU_ON issued` and later `CPU online` as separate facts. S14 requires the online state.

## History

Closure: CPU_ON success is not online (invariant 18).

## Status

BUILT. TESTED on QEMU (HVC). FVP SMC path BUILT, NOT EXECUTED.
