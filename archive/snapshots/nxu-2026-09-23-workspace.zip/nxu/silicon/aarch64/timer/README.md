# silicon/aarch64/timer/

## Why

The generic timer is an operation. Which PPI and which deadline are foundation.

## Layer

Silicon.

## Ownership

CNTPCT, CNTFRQ, and the EL1 or EL2 physical timer enable, status, and mask.

## Dependencies

Tick count is a parameter. Foundation chooses EL1 versus EL2.

## Direction

```
foundation/time → timer.c → CNTP or CNTHP
```

## Files

| File | Owns | Consumes | Produces |
|---|---|---|---|
| `timer.c` | counter and timer ops | tick count | counter, ISTATUS, arm or mask |
| `timer.h` | prototypes | none | the interface |

## Hardware

ARM generic timer.

## Forbidden

PPI policy. UART delays. A tick rate.

## Invariants

Operations only.

## Evidence

QEMU observed a deadline fire on the EL1 physical PPI.

## History

Kept as a mechanism after earlier PPI experiments. The PPI number is not stored here.

## Status

BUILT. EL1 TESTED. EL2 NOT EXECUTED.
