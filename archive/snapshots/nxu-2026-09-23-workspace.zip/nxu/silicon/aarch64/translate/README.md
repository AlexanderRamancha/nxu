# silicon/aarch64/translate/

## Why

Page-table programming is a mechanism. Which pages exist is foundation policy.

## Layer

Silicon.

## Ownership

Stage-1 table writes, TLBI, TCR/MAIR/TTBR, SCTLR.M enable.

## Dependencies

Consumes physical ranges and permissions from foundation space. Does not read the ownership table.

## Direction

```
foundation/space → mmu.c → registers
```

## Files

| File | Owns | Consumes | Produces |
|---|---|---|---|
| `mmu.c` | table programming and enable | PA, size, perm | TTBR programmed, MMU on |
| `mmu.h` | operation prototypes | none | the interface |

## Hardware

Stage-1 tables and TLB maintenance.

## Forbidden

Board addresses. Ownership decisions. Mapping policy.

## Invariants

Operations only. Foundation checks WX and default deny before the call.

## Evidence

QEMU reached translation-on and later S14 with the TCB TTBR stored in each context.

## History

Identity map of the image and accepted MMIO only. High virtual window is research, not this directory.

## Status

BUILT. TESTED on QEMU EL1.
