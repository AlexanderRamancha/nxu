# silicon/aarch64/uart/

## Why

A console needs a byte sink. The sink is optional and is not time, not policy, and not evidence authority.

## Layer

Silicon.

## Ownership

PL011 transmit.

## Dependencies

Base address is a parameter from the foundation sink after ownership.

## Direction

```
foundation/observe/sink.c → pl011.c → UART
```

## Files

| File | Owns | Consumes | Produces |
|---|---|---|---|
| `pl011.c` | putc and write | base address | characters |
| `pl011.h` | prototypes | none | the interface |

## Hardware

PL011.

## Forbidden

Compiled QEMU or FVP UART addresses. Using the UART as a clock.

## Invariants

Operations only. If foundation never binds, this code is not called.

## Evidence

QEMU console lines are these writes. Halt does not require them.

## History

Early trees printed before ownership and treated UART output as the boot clock. Both were rejected.

## Status

BUILT. TESTED as an optional sink on QEMU.
