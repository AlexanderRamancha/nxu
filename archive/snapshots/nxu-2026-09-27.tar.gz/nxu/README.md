# NXU

Machine-control and isolation substrate. Not Linux. Genesis v2 is the authority.

## Workflow

```
make clean
make
make qemu
make debug
make fvp
```

`make` builds `build-qemu/nxu.img`.
`make qemu` executes QEMU virt GICv3 and requires the live line `[NXU] NXU kernel execution established`.
`make debug` builds `build-debug/nxu.img` with extra `[nxu] note debug` lines and runs QEMU the same way.
`make fvp` builds `build-fvp/nxu.img`. If no FVP binary is present it reports `FVP: NOT EXECUTED`. That is not PASS.

## Include model

Every compilation uses `-Iinclude -I.` from the Makefile.

- `<nxu/...>` public TCB types and prototypes
- `<silicon/...>` hardware operation headers

Do not add per-file relative include paths.

## Tree

```
foundation/     Genesis policy and S0–S14
silicon/        ARM64 hardware operations (addresses as parameters)
board/          platform candidate facts only
image/          image format and linker layout
include/nxu/    public interfaces
probe/          host-side build, run, check
research/       history only; never linked
```

## Layers

```
Hardware
   │
   ▼
Silicon mechanisms
   │
   ▼
Board facts
   │
   ▼
Foundation validation / policy
   │
   ▼
S0–S14
   │
   ▼
Observation / Black Box / Console
```
