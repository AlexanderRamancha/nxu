build-fvp/board/fvp-base/facts.c.o: board/fvp-base/facts.c \
 include/nxu/board.h include/nxu/types.h include/nxu/config.h \
 include/nxu/range.h
include/nxu/board.h:
include/nxu/types.h:
include/nxu/config.h:
include/nxu/range.h:
