build-fvp/foundation/intake/s0.c.o: foundation/intake/s0.c \
 include/nxu/s0.h include/nxu/intake.h include/nxu/types.h \
 include/nxu/chronicle.h include/nxu/config.h include/nxu/fail.h \
 include/nxu/image.h
include/nxu/s0.h:
include/nxu/intake.h:
include/nxu/types.h:
include/nxu/chronicle.h:
include/nxu/config.h:
include/nxu/fail.h:
include/nxu/image.h:
