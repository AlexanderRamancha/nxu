build-fvp/foundation/observe/fail.c.o: foundation/observe/fail.c \
 include/nxu/fail.h include/nxu/types.h include/nxu/chronicle.h \
 include/nxu/config.h include/nxu/log.h include/nxu/bbox.h \
 include/nxu/halt.h
include/nxu/fail.h:
include/nxu/types.h:
include/nxu/chronicle.h:
include/nxu/config.h:
include/nxu/log.h:
include/nxu/bbox.h:
include/nxu/halt.h:
