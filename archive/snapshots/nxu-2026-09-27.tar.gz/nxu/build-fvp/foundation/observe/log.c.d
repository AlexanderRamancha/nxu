build-fvp/foundation/observe/log.c.o: foundation/observe/log.c \
 include/nxu/log.h include/nxu/types.h include/nxu/chronicle.h \
 include/nxu/config.h include/nxu/console.h include/nxu/cpu.h \
 include/nxu/context.h
include/nxu/log.h:
include/nxu/types.h:
include/nxu/chronicle.h:
include/nxu/config.h:
include/nxu/console.h:
include/nxu/cpu.h:
include/nxu/context.h:
