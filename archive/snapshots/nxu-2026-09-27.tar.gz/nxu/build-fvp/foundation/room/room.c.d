build-fvp/foundation/room/room.c.o: foundation/room/room.c \
 include/nxu/room.h include/nxu/types.h include/nxu/log.h \
 include/nxu/fail.h include/nxu/facts.h include/nxu/config.h \
 include/nxu/range.h include/nxu/image.h include/nxu/time.h \
 include/nxu/cpu.h include/nxu/context.h silicon/aarch64/timer/timer.h \
 include/nxu/chronicle.h silicon/aarch64/translate/mmu.h \
 silicon/aarch64/sysreg.h silicon/aarch64/gicv3/gicv3.h
include/nxu/room.h:
include/nxu/types.h:
include/nxu/log.h:
include/nxu/fail.h:
include/nxu/facts.h:
include/nxu/config.h:
include/nxu/range.h:
include/nxu/image.h:
include/nxu/time.h:
include/nxu/cpu.h:
include/nxu/context.h:
silicon/aarch64/timer/timer.h:
include/nxu/chronicle.h:
silicon/aarch64/translate/mmu.h:
silicon/aarch64/sysreg.h:
silicon/aarch64/gicv3/gicv3.h:
