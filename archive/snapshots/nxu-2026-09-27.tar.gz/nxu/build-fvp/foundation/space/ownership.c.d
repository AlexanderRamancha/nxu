build-fvp/foundation/space/ownership.c.o: foundation/space/ownership.c \
 include/nxu/space.h include/nxu/types.h include/nxu/config.h \
 include/nxu/range.h include/nxu/facts.h include/nxu/image.h \
 include/nxu/chronicle.h include/nxu/fail.h
include/nxu/space.h:
include/nxu/types.h:
include/nxu/config.h:
include/nxu/range.h:
include/nxu/facts.h:
include/nxu/image.h:
include/nxu/chronicle.h:
include/nxu/fail.h:
