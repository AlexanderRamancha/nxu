build-fvp/foundation/time/time.c.o: foundation/time/time.c \
 include/nxu/time.h include/nxu/types.h include/nxu/facts.h \
 include/nxu/config.h include/nxu/range.h include/nxu/signal.h \
 include/nxu/cpu.h include/nxu/context.h include/nxu/intake.h \
 include/nxu/chronicle.h include/nxu/fail.h include/nxu/console.h \
 include/nxu/log.h include/nxu/space.h silicon/aarch64/timer/timer.h \
 silicon/aarch64/gicv3/gicv3.h silicon/aarch64/translate/mmu.h \
 silicon/aarch64/sysreg.h
include/nxu/time.h:
include/nxu/types.h:
include/nxu/facts.h:
include/nxu/config.h:
include/nxu/range.h:
include/nxu/signal.h:
include/nxu/cpu.h:
include/nxu/context.h:
include/nxu/intake.h:
include/nxu/chronicle.h:
include/nxu/fail.h:
include/nxu/console.h:
include/nxu/log.h:
include/nxu/space.h:
silicon/aarch64/timer/timer.h:
silicon/aarch64/gicv3/gicv3.h:
silicon/aarch64/translate/mmu.h:
silicon/aarch64/sysreg.h:
