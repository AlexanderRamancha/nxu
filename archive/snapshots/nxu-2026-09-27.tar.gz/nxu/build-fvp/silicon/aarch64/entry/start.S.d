build-fvp/silicon/aarch64/entry/start.S.o: silicon/aarch64/entry/start.S
