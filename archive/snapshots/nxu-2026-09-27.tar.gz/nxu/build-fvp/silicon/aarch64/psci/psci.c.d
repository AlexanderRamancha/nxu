build-fvp/silicon/aarch64/psci/psci.c.o: silicon/aarch64/psci/psci.c \
 silicon/aarch64/psci/psci.h include/nxu/types.h
silicon/aarch64/psci/psci.h:
include/nxu/types.h:
