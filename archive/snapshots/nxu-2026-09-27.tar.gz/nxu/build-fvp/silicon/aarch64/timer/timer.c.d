build-fvp/silicon/aarch64/timer/timer.c.o: silicon/aarch64/timer/timer.c \
 silicon/aarch64/timer/timer.h include/nxu/types.h \
 silicon/aarch64/sysreg.h
silicon/aarch64/timer/timer.h:
include/nxu/types.h:
silicon/aarch64/sysreg.h:
