build-fvp/silicon/aarch64/translate/mmu.c.o: \
 silicon/aarch64/translate/mmu.c silicon/aarch64/translate/mmu.h \
 include/nxu/types.h silicon/aarch64/sysreg.h include/nxu/config.h \
 include/nxu/range.h include/nxu/image.h include/nxu/fail.h \
 include/nxu/chronicle.h
silicon/aarch64/translate/mmu.h:
include/nxu/types.h:
silicon/aarch64/sysreg.h:
include/nxu/config.h:
include/nxu/range.h:
include/nxu/image.h:
include/nxu/fail.h:
include/nxu/chronicle.h:
