build-fvp/silicon/aarch64/uart/pl011.c.o: silicon/aarch64/uart/pl011.c \
 silicon/aarch64/uart/pl011.h include/nxu/types.h
silicon/aarch64/uart/pl011.h:
include/nxu/types.h:
