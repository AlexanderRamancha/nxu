build-qemu/board/qemu-virt/facts.c.o: board/qemu-virt/facts.c \
 include/nxu/board.h include/nxu/types.h include/nxu/config.h \
 include/nxu/range.h
include/nxu/board.h:
include/nxu/types.h:
include/nxu/config.h:
include/nxu/range.h:
