build-qemu/foundation/context/context.c.o: foundation/context/context.c \
 include/nxu/context.h include/nxu/types.h include/nxu/config.h \
 include/nxu/cpu.h include/nxu/intake.h silicon/aarch64/translate/mmu.h
include/nxu/context.h:
include/nxu/types.h:
include/nxu/config.h:
include/nxu/cpu.h:
include/nxu/intake.h:
silicon/aarch64/translate/mmu.h:
