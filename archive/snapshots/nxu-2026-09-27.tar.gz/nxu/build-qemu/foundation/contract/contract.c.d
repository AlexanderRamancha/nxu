build-qemu/foundation/contract/contract.c.o: \
 foundation/contract/contract.c include/nxu/s0.h include/nxu/intake.h \
 include/nxu/types.h include/nxu/image.h include/nxu/chronicle.h \
 include/nxu/config.h include/nxu/fail.h
include/nxu/s0.h:
include/nxu/intake.h:
include/nxu/types.h:
include/nxu/image.h:
include/nxu/chronicle.h:
include/nxu/config.h:
include/nxu/fail.h:
