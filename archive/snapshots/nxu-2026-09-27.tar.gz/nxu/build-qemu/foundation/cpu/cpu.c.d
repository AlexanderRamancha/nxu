build-qemu/foundation/cpu/cpu.c.o: foundation/cpu/cpu.c include/nxu/cpu.h \
 include/nxu/types.h include/nxu/config.h include/nxu/context.h \
 include/nxu/facts.h include/nxu/range.h include/nxu/intake.h \
 include/nxu/image.h include/nxu/chronicle.h include/nxu/fail.h \
 include/nxu/console.h include/nxu/log.h silicon/aarch64/sysreg.h \
 silicon/aarch64/translate/mmu.h
include/nxu/cpu.h:
include/nxu/types.h:
include/nxu/config.h:
include/nxu/context.h:
include/nxu/facts.h:
include/nxu/range.h:
include/nxu/intake.h:
include/nxu/image.h:
include/nxu/chronicle.h:
include/nxu/fail.h:
include/nxu/console.h:
include/nxu/log.h:
silicon/aarch64/sysreg.h:
silicon/aarch64/translate/mmu.h:
