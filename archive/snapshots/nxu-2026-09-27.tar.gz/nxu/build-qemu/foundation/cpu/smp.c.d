build-qemu/foundation/cpu/smp.c.o: foundation/cpu/smp.c include/nxu/cpu.h \
 include/nxu/types.h include/nxu/config.h include/nxu/context.h \
 include/nxu/facts.h include/nxu/range.h include/nxu/space.h \
 include/nxu/intake.h include/nxu/chronicle.h include/nxu/fail.h \
 include/nxu/time.h include/nxu/signal.h include/nxu/console.h \
 include/nxu/log.h silicon/aarch64/psci/psci.h silicon/aarch64/sysreg.h \
 silicon/aarch64/translate/mmu.h silicon/aarch64/gicv3/gicv3.h \
 silicon/aarch64/timer/timer.h
include/nxu/cpu.h:
include/nxu/types.h:
include/nxu/config.h:
include/nxu/context.h:
include/nxu/facts.h:
include/nxu/range.h:
include/nxu/space.h:
include/nxu/intake.h:
include/nxu/chronicle.h:
include/nxu/fail.h:
include/nxu/time.h:
include/nxu/signal.h:
include/nxu/console.h:
include/nxu/log.h:
silicon/aarch64/psci/psci.h:
silicon/aarch64/sysreg.h:
silicon/aarch64/translate/mmu.h:
silicon/aarch64/gicv3/gicv3.h:
silicon/aarch64/timer/timer.h:
