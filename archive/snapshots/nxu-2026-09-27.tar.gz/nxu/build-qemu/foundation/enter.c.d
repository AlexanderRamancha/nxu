build-qemu/foundation/enter.c.o: foundation/enter.c include/nxu/s0.h \
 include/nxu/intake.h include/nxu/types.h include/nxu/facts.h \
 include/nxu/config.h include/nxu/range.h include/nxu/space.h \
 include/nxu/exception.h include/nxu/cpu.h include/nxu/context.h \
 include/nxu/signal.h include/nxu/time.h include/nxu/halt.h \
 include/nxu/room.h
include/nxu/s0.h:
include/nxu/intake.h:
include/nxu/types.h:
include/nxu/facts.h:
include/nxu/config.h:
include/nxu/range.h:
include/nxu/space.h:
include/nxu/exception.h:
include/nxu/cpu.h:
include/nxu/context.h:
include/nxu/signal.h:
include/nxu/time.h:
include/nxu/halt.h:
include/nxu/room.h:
