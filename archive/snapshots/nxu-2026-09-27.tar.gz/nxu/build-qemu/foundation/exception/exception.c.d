build-qemu/foundation/exception/exception.c.o: \
 foundation/exception/exception.c include/nxu/exception.h \
 include/nxu/types.h include/nxu/context.h include/nxu/config.h \
 include/nxu/cpu.h include/nxu/intake.h include/nxu/chronicle.h \
 include/nxu/fail.h include/nxu/signal.h include/nxu/console.h \
 include/nxu/log.h silicon/aarch64/sysreg.h silicon/aarch64/gicv3/gicv3.h
include/nxu/exception.h:
include/nxu/types.h:
include/nxu/context.h:
include/nxu/config.h:
include/nxu/cpu.h:
include/nxu/intake.h:
include/nxu/chronicle.h:
include/nxu/fail.h:
include/nxu/signal.h:
include/nxu/console.h:
include/nxu/log.h:
silicon/aarch64/sysreg.h:
silicon/aarch64/gicv3/gicv3.h:
