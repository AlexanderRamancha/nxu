build-qemu/foundation/facts/facts.c.o: foundation/facts/facts.c \
 include/nxu/facts.h include/nxu/types.h include/nxu/config.h \
 include/nxu/range.h include/nxu/fdt.h include/nxu/board.h \
 include/nxu/intake.h include/nxu/image.h include/nxu/chronicle.h \
 include/nxu/fail.h silicon/aarch64/timer/timer.h
include/nxu/facts.h:
include/nxu/types.h:
include/nxu/config.h:
include/nxu/range.h:
include/nxu/fdt.h:
include/nxu/board.h:
include/nxu/intake.h:
include/nxu/image.h:
include/nxu/chronicle.h:
include/nxu/fail.h:
silicon/aarch64/timer/timer.h:
