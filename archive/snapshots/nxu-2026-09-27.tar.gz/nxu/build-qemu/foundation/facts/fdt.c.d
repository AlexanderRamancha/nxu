build-qemu/foundation/facts/fdt.c.o: foundation/facts/fdt.c \
 include/nxu/facts.h include/nxu/types.h include/nxu/config.h \
 include/nxu/range.h include/nxu/fdt.h include/nxu/intake.h \
 include/nxu/image.h include/nxu/chronicle.h include/nxu/fail.h \
 include/nxu/board.h
include/nxu/facts.h:
include/nxu/types.h:
include/nxu/config.h:
include/nxu/range.h:
include/nxu/fdt.h:
include/nxu/intake.h:
include/nxu/image.h:
include/nxu/chronicle.h:
include/nxu/fail.h:
include/nxu/board.h:
