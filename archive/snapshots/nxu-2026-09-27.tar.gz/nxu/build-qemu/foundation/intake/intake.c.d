build-qemu/foundation/intake/intake.c.o: foundation/intake/intake.c \
 include/nxu/intake.h include/nxu/types.h include/nxu/chronicle.h \
 include/nxu/config.h include/nxu/fail.h
include/nxu/intake.h:
include/nxu/types.h:
include/nxu/chronicle.h:
include/nxu/config.h:
include/nxu/fail.h:
