build-qemu/foundation/observe/bbox.c.o: foundation/observe/bbox.c \
 include/nxu/bbox.h include/nxu/types.h include/nxu/config.h \
 include/nxu/cpu.h include/nxu/context.h include/nxu/sink.h
include/nxu/bbox.h:
include/nxu/types.h:
include/nxu/config.h:
include/nxu/cpu.h:
include/nxu/context.h:
include/nxu/sink.h:
