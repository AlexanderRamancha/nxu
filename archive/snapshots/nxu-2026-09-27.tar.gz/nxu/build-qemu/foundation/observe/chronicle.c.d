build-qemu/foundation/observe/chronicle.c.o: \
 foundation/observe/chronicle.c include/nxu/chronicle.h \
 include/nxu/types.h include/nxu/config.h include/nxu/cpu.h \
 include/nxu/context.h include/nxu/bbox.h
include/nxu/chronicle.h:
include/nxu/types.h:
include/nxu/config.h:
include/nxu/cpu.h:
include/nxu/context.h:
include/nxu/bbox.h:
