build-qemu/foundation/observe/console.c.o: foundation/observe/console.c \
 include/nxu/console.h include/nxu/types.h include/nxu/log.h \
 include/nxu/sink.h include/nxu/cpu.h include/nxu/config.h \
 include/nxu/context.h
include/nxu/console.h:
include/nxu/types.h:
include/nxu/log.h:
include/nxu/sink.h:
include/nxu/cpu.h:
include/nxu/config.h:
include/nxu/context.h:
