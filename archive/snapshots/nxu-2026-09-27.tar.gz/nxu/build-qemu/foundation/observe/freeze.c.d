build-qemu/foundation/observe/freeze.c.o: foundation/observe/freeze.c \
 include/nxu/s0.h include/nxu/cpu.h include/nxu/types.h \
 include/nxu/config.h include/nxu/context.h include/nxu/space.h \
 include/nxu/range.h include/nxu/facts.h include/nxu/intake.h \
 include/nxu/signal.h include/nxu/chronicle.h include/nxu/fail.h \
 include/nxu/console.h include/nxu/log.h silicon/aarch64/translate/mmu.h
include/nxu/s0.h:
include/nxu/cpu.h:
include/nxu/types.h:
include/nxu/config.h:
include/nxu/context.h:
include/nxu/space.h:
include/nxu/range.h:
include/nxu/facts.h:
include/nxu/intake.h:
include/nxu/signal.h:
include/nxu/chronicle.h:
include/nxu/fail.h:
include/nxu/console.h:
include/nxu/log.h:
silicon/aarch64/translate/mmu.h:
