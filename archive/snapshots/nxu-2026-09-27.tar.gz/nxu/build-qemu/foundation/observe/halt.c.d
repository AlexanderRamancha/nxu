build-qemu/foundation/observe/halt.c.o: foundation/observe/halt.c \
 include/nxu/halt.h
include/nxu/halt.h:
