build-qemu/foundation/observe/sink.c.o: foundation/observe/sink.c \
 include/nxu/sink.h include/nxu/types.h silicon/aarch64/uart/pl011.h
include/nxu/sink.h:
include/nxu/types.h:
silicon/aarch64/uart/pl011.h:
