build-qemu/foundation/room/room_entry.S.o: foundation/room/room_entry.S
