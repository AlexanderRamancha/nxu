build-qemu/foundation/signal/signal.c.o: foundation/signal/signal.c \
 include/nxu/signal.h include/nxu/types.h include/nxu/config.h \
 include/nxu/cpu.h include/nxu/context.h include/nxu/facts.h \
 include/nxu/range.h include/nxu/chronicle.h include/nxu/fail.h \
 include/nxu/time.h include/nxu/intake.h include/nxu/console.h \
 include/nxu/log.h silicon/aarch64/gicv3/gicv3.h silicon/aarch64/sysreg.h
include/nxu/signal.h:
include/nxu/types.h:
include/nxu/config.h:
include/nxu/cpu.h:
include/nxu/context.h:
include/nxu/facts.h:
include/nxu/range.h:
include/nxu/chronicle.h:
include/nxu/fail.h:
include/nxu/time.h:
include/nxu/intake.h:
include/nxu/console.h:
include/nxu/log.h:
silicon/aarch64/gicv3/gicv3.h:
silicon/aarch64/sysreg.h:
