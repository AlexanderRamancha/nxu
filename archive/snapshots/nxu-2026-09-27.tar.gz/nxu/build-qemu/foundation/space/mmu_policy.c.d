build-qemu/foundation/space/mmu_policy.c.o: foundation/space/mmu_policy.c \
 include/nxu/space.h include/nxu/types.h include/nxu/config.h \
 include/nxu/range.h include/nxu/image.h include/nxu/facts.h \
 include/nxu/intake.h include/nxu/chronicle.h include/nxu/fail.h \
 include/nxu/sink.h include/nxu/console.h include/nxu/log.h \
 silicon/aarch64/translate/mmu.h
include/nxu/space.h:
include/nxu/types.h:
include/nxu/config.h:
include/nxu/range.h:
include/nxu/image.h:
include/nxu/facts.h:
include/nxu/intake.h:
include/nxu/chronicle.h:
include/nxu/fail.h:
include/nxu/sink.h:
include/nxu/console.h:
include/nxu/log.h:
silicon/aarch64/translate/mmu.h:
