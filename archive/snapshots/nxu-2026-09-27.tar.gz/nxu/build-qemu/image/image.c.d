build-qemu/image/image.c.o: image/image.c include/nxu/image.h \
 include/nxu/types.h
include/nxu/image.h:
include/nxu/types.h:
