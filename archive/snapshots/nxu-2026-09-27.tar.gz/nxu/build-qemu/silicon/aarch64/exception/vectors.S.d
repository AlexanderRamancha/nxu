build-qemu/silicon/aarch64/exception/vectors.S.o: \
 silicon/aarch64/exception/vectors.S
