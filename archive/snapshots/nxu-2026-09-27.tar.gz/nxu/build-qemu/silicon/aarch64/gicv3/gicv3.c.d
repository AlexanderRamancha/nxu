build-qemu/silicon/aarch64/gicv3/gicv3.c.o: silicon/aarch64/gicv3/gicv3.c \
 silicon/aarch64/gicv3/gicv3.h include/nxu/types.h \
 silicon/aarch64/sysreg.h
silicon/aarch64/gicv3/gicv3.h:
include/nxu/types.h:
silicon/aarch64/sysreg.h:
